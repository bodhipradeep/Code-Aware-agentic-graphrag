"""Admin endpoints — memory, graph stats, and data management."""

import logging
from fastapi import APIRouter, HTTPException

from .models import MemoryTTLRequest
from .dependencies import (
    memory, graph_store, vector_store,
    get_db_connection,
)
from Knowledge_Graph.graph_builder import build_graph_from_chunks

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/admin", tags=["admin"])


@router.delete("/clear-db")
def clear_vector_db():
    """Clear all data from vector store."""
    try:
        success = vector_store.delete_all()
        if not success:
            raise HTTPException(status_code=500, detail="Failed to clear vector store")
        return {"message": "All data cleared successfully"}
    except Exception as e:
        logger.error(f"Error clearing DB: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/clear-memory")
def clear_agent_memory():
    """Clear agent learning memory."""
    try:
        memory.clear()
        return {"message": "Agent memory cleared successfully"}
    except Exception as e:
        logger.error(f"Error clearing memory: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/memory-ttl")
def set_memory_ttl(request: MemoryTTLRequest):
    """Set memory TTL for auto-expiry."""
    try:
        result = {}
        if request.delete_before:
            deleted = memory.delete_before_date(request.delete_before)
            result["deleted_before"] = {
                "cutoff_date": request.delete_before,
                "records_deleted": deleted,
            }
        if request.ttl_years is not None:
            days = int(request.ttl_years * 365)
            updated = memory.set_ttl_days(days)
            result["ttl_updated"] = {
                "ttl_years": request.ttl_years,
                "ttl_days": days,
                "records_updated": updated,
            }
        elif request.ttl_days is not None:
            updated = memory.set_ttl_days(request.ttl_days)
            result["ttl_updated"] = {
                "ttl_days": request.ttl_days,
                "records_updated": updated,
            }
        if not result:
            raise HTTPException(
                status_code=400, detail="Provide ttl_years, ttl_days, or delete_before"
            )
        return {"message": "Memory TTL updated", **result}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error setting memory TTL: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/memory-cleanup")
def cleanup_memory():
    """Run TTL cleanup — delete all expired memory records."""
    try:
        deleted = memory.cleanup_expired()
        return {"message": f"Cleaned up {deleted} expired records", "deleted": deleted}
    except Exception as e:
        logger.error(f"Error cleaning memory: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/memory-stats")
def get_memory_stats():
    """Get agent memory statistics."""
    try:
        return memory.get_stats()
    except Exception as e:
        logger.error(f"Error getting memory stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/graph-stats")
def get_graph_stats():
    """Get knowledge graph statistics from Neo4j."""
    try:
        return graph_store.get_stats()
    except Exception as e:
        logger.error(f"Error getting graph stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


def _load_chunks_from_pgvector(vs):
    """Load all chunks from PGVector for graph rebuild."""
    import psycopg2
    from langchain_core.documents import Document as LCDoc
    import json

    conn = psycopg2.connect(vs.connection_string)
    cur = conn.cursor()
    cur.execute(f"SELECT document, cmetadata FROM {vs.table_name}")
    rows = cur.fetchall()
    cur.close()
    conn.close()

    chunks = []
    source_texts = {}
    for content, metadata in rows:
        meta = json.loads(metadata) if isinstance(metadata, str) else metadata
        chunks.append(LCDoc(page_content=content, metadata=meta))
        rpath = meta.get("relative_path", "")
        if rpath and meta.get("chunk_type") in ("class", "full_file"):
            source_texts[rpath] = content
    return chunks, source_texts


@router.delete("/graph-rebuild")
def rebuild_graph():
    """Rebuild the knowledge graph from current vector store chunks."""
    try:
        chunks, source_texts = _load_chunks_from_pgvector(vector_store)
        if not chunks:
            return {"message": "No chunks in vector store to build graph from", "stats": {}}
        graph_store.clear_all()
        stats = build_graph_from_chunks(chunks, graph_store, source_texts)
        return {"message": "Graph rebuilt", "stats": stats}
    except Exception as e:
        logger.error(f"Error rebuilding graph: {e}")
        raise HTTPException(status_code=500, detail=str(e))
