"""Shared dependencies for all API routers.

Single-import module that provides shared infrastructure (vector store, graph store,
memory, workflow graph) and utility functions (DB connection, session management,
pipeline logging) to all routers.
"""

import os
import sys
import json
import logging
import threading
from io import StringIO
from typing import Dict, List, Optional
from datetime import datetime, timedelta

import redis
from Config.settings import CONFIG

logger = logging.getLogger(__name__)

# === Shared infrastructure (initialized once at import time) ===

from Vector_Store.store import CodeVectorStore
from Retriever.retriever import CodeRetriever
from Memory.agent_memory import AgentMemory
from Knowledge_Graph.graph_store import CodeGraphStore
from Graph.agent_workflow import create_agentic_workflow

vector_store = CodeVectorStore().load_or_create()
retriever = CodeRetriever(vector_store)
memory = AgentMemory()
graph_store = CodeGraphStore()
graph, checkpointer = create_agentic_workflow(vector_store, memory, graph_store)

# === Session state ===

workflow_logs: Dict[str, List[str]] = {}
workflow_logs_lock = threading.Lock()
session_lock = threading.Lock()

# === Redis ===

try:
    redis_client = redis.Redis(
        host=CONFIG["redis_host"],
        port=CONFIG["redis_port"],
        decode_responses=True,
        socket_connect_timeout=1,
        socket_timeout=1,
    )
    redis_client.ping()
    logger.info(f"Connected to Redis at {CONFIG['redis_host']}:{CONFIG['redis_port']}")
except Exception as e:
    logger.warning(f"Redis connection failed: {e}. Falling back to in-memory sessions.")
    redis_client = None


# === Database utility ===

def get_db_connection():
    """Get a PostgreSQL connection for direct queries."""
    import psycopg2
    return psycopg2.connect(
        host=os.getenv("PGVECTOR_HOST", "localhost"),
        port=int(os.getenv("PGVECTOR_PORT", 5432)),
        database=os.getenv("PGVECTOR_DB", "rag"),
        user=os.getenv("PGVECTOR_USER", "postgres"),
        password=os.getenv("PGVECTOR_PASSWORD", "admin"),
    )


# === Pipeline refresh ===

def refresh_pipeline():
    """Refresh RAG pipeline components after indexing/sync changes."""
    global retriever, graph, checkpointer
    retriever = CodeRetriever(vector_store)
    graph, checkpointer = create_agentic_workflow(vector_store, memory, graph_store)


# === Session management ===

class SessionData:
    def __init__(self, query: str, user_id: str = "anonymous",
                 error: Optional[str] = None, file_hint: Optional[str] = None):
        self.query = query
        self.user_id = user_id
        self.error = error
        self.file_hint = file_hint
        self.created_at = datetime.now()


query_sessions: Dict[str, SessionData] = {}


def save_session_to_redis(thread_id: str, session_data: SessionData):
    if redis_client:
        try:
            data = {
                "query": session_data.query,
                "user_id": session_data.user_id,
                "error": session_data.error,
                "file_hint": session_data.file_hint,
                "created_at": session_data.created_at.isoformat(),
            }
            redis_client.setex(
                f"session:{thread_id}",
                CONFIG.get("redis_ttl", 7200),
                json.dumps(data),
            )
        except Exception as e:
            logger.error(f"Redis save failed: {e}")


def get_session_from_redis(thread_id: str) -> Optional[SessionData]:
    if redis_client:
        try:
            data = redis_client.get(f"session:{thread_id}")
            if data:
                parsed = json.loads(str(data))
                session = SessionData(
                    query=parsed["query"],
                    user_id=parsed.get("user_id", "anonymous"),
                    error=parsed.get("error"),
                    file_hint=parsed.get("file_hint"),
                )
                session.created_at = datetime.fromisoformat(parsed["created_at"])
                return session
        except Exception as e:
            logger.error(f"Redis get failed: {e}")
    return query_sessions.get(thread_id)


def cleanup_expired_sessions():
    with session_lock:
        ttl_hours = CONFIG.get("session_ttl_hours", 2)
        cutoff = datetime.now() - timedelta(hours=ttl_hours)
        expired = [k for k, v in query_sessions.items() if v.created_at < cutoff]
        for k in expired:
            del query_sessions[k]
            if k in workflow_logs:
                del workflow_logs[k]


# === Pipeline logging ===

def save_pipeline_log(
    pipeline_type: str,
    user_email: str,
    model: str,
    status: str,
    input_text: str,
    output_text: str,
    jira_key: Optional[str] = None,
    refiner_model: Optional[str] = None,
    query_refined: bool = False,
    verifier_score: Optional[int] = None,
    human_approved: Optional[bool] = None,
    iterations: Optional[int] = None,
    snippets: list = [],
    feedback: Optional[str] = None,
    reasoning: Optional[str] = None,
):
    try:
        from psycopg2.extras import RealDictCursor
        conn = get_db_connection()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute(
            """INSERT INTO pipeline_logs
            (type, jira_key, user_email, model, refiner_model, query_refined, status,
             verifier_score, human_approved, iterations, input_text, output_text,
             snippets, feedback, reasoning)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            RETURNING id""",
            (pipeline_type, jira_key, user_email, model, refiner_model,
             query_refined, status, verifier_score, human_approved, iterations,
             input_text, output_text, json.dumps(snippets), feedback, reasoning),
        )
        result = cur.fetchone()
        conn.commit()
        cur.close()
        conn.close()
        if result:
            logger.info(f"Pipeline log created with ID: {result['id']}")
            return result["id"]
    except Exception as e:
        logger.error(f"Failed to save pipeline log: {e}")
    return None


# === Stdout capture context manager ===

class CaptureOutput:
    """Context manager to capture stdout during workflow execution."""

    def __init__(self):
        self.captured = ""
        self._old_stdout = None
        self._capture = None

    def __enter__(self):
        self._old_stdout = sys.stdout
        self._capture = StringIO()
        sys.stdout = self._capture
        return self

    def __exit__(self, *exc):
        sys.stdout = self._old_stdout
        self.captured = self._capture.getvalue()
        return False
