"""Index management endpoints — index files, clear, list classes."""

import os
import logging

from fastapi import APIRouter, HTTPException

from Chunker.ast_chunker import chunk_documents
from Utils.chunk_saver import save_chunks_to_json
from Knowledge_Graph.graph_builder import build_graph_from_chunks

from .models import IndexRequest
from .dependencies import (
    vector_store, graph_store, refresh_pipeline,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["index"])


@router.post("/index")
def index_files(request: IndexRequest):
    """Index files from a directory or single file path."""
    try:
        path = request.path.strip()
        if not path or len(path) > 500:
            raise HTTPException(status_code=400, detail="Invalid path length")
        if not os.path.exists(path):
            raise HTTPException(status_code=400, detail=f"Path does not exist: {path}")

        from File_loader.loader import load_code_files
        documents = load_code_files(path)
        if not documents:
            raise HTTPException(status_code=400, detail="No supported files found (Java/TypeScript)")

        chunked_docs = chunk_documents(documents)
        if not chunked_docs:
            raise HTTPException(status_code=400, detail="Failed to chunk documents")

        save_chunks_to_json(chunked_docs)
        vector_store.add_documents(chunked_docs)
        vector_store.save()

        graph_stats = None
        try:
            source_texts = {
                doc.metadata.get("relative_path", ""): doc.page_content
                for doc in documents if doc.metadata.get("relative_path")
            }
            graph_stats = build_graph_from_chunks(chunked_docs, graph_store, source_texts)
        except Exception as ge:
            logger.error(f"Graph build failed (non-blocking): {ge}")

        refresh_pipeline()

        return {
            "message": f"Successfully indexed {len(chunked_docs)} chunks from {len(documents)} file(s)",
            "stats": vector_store.get_stats(),
            "graph_stats": graph_stats,
        }

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.delete("/index")
def clear_index():
    """Clear the entire vector store index."""
    try:
        from Vector_Store.store import CodeVectorStore
        from .dependencies import vector_store as vs
        # Reinitialize
        new_vs = CodeVectorStore().load_or_create()
        import API.dependencies as deps
        deps.vector_store = new_vs
        refresh_pipeline()
        return {"message": "Index cleared successfully", "stats": new_vs.get_stats()}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.delete("/clear")
async def clear_vector_store():
    """Delete all documents from the vector store."""
    try:
        success = vector_store.delete_all()
        if not success:
            raise HTTPException(status_code=500, detail="Failed to clear vector store")
        return {
            "message": "Vector store cleared successfully",
            "success": True,
            "stats": vector_store.get_stats(),
        }
    except Exception as exc:
        logger.error(f"Error clearing vector store: {exc}")
        raise HTTPException(status_code=500, detail=str(exc))


@router.get("/classes")
def list_classes():
    """List all indexed class names."""
    try:
        if not vector_store.vectorstore:
            return {"classes": [], "count": 0}

        import psycopg2
        conn = psycopg2.connect(vector_store.connection_string)
        cursor = conn.cursor()
        cursor.execute(
            f"""SELECT DISTINCT cmetadata->>'class_name'
                FROM {vector_store.table_name}
                WHERE cmetadata->>'class_name' IS NOT NULL
                ORDER BY cmetadata->>'class_name'"""
        )
        class_names = [row[0] for row in cursor.fetchall()]
        cursor.close()
        conn.close()

        return {"classes": class_names, "count": len(class_names)}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
