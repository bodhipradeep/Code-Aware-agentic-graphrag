"""JIRA proxy endpoint — forwards requests to JIRA API to avoid CORS."""

import os
import base64
import logging

import httpx
from fastapi import APIRouter, HTTPException
from dotenv import load_dotenv

from .models import JiraRequest
from .dependencies import get_db_connection

logger = logging.getLogger(__name__)

router = APIRouter(tags=["jira"])


def _get_jira_config():
    """Get JIRA configuration from database with fallback to environment."""
    try:
        from psycopg2.extras import RealDictCursor
        conn = get_db_connection()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute(
            """SELECT config_key, config_value FROM system_config
               WHERE config_key IN ('jira_base_url', 'jira_email', 'jira_api_token')"""
        )
        rows = cur.fetchall()
        cur.close()
        conn.close()
        config = {row["config_key"]: row["config_value"] for row in rows}
        return {
            "base_url": config.get("jira_base_url") or os.getenv("JIRA_BASE_URL", ""),
            "email": config.get("jira_email") or os.getenv("JIRA_EMAIL", ""),
            "api_token": config.get("jira_api_token") or os.getenv("JIRA_API_TOKEN", ""),
        }
    except Exception as e:
        logger.warning(f"Failed to load JIRA config from database: {e}")
        load_dotenv(override=True)
        return {
            "base_url": os.getenv("JIRA_BASE_URL", ""),
            "email": os.getenv("JIRA_EMAIL", ""),
            "api_token": os.getenv("JIRA_API_TOKEN", ""),
        }


@router.api_route("/jira-proxy", methods=["POST", "OPTIONS"])
async def jira_proxy(request: JiraRequest):
    """Proxy requests to JIRA API to avoid CORS issues."""
    config = _get_jira_config()
    if not config["base_url"] or not config["email"] or not config["api_token"]:
        raise HTTPException(status_code=500, detail="JIRA configuration not set")

    base_url = config["base_url"].rstrip("/")
    credentials = f"{config['email']}:{config['api_token']}"
    auth = f"Basic {base64.b64encode(credentials.encode()).decode()}"
    headers = {
        "Authorization": auth,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            if request.action == "test":
                response = await client.get(f"{base_url}/rest/api/3/myself", headers=headers)
                response.raise_for_status()
                data = response.json()
                return {"displayName": data.get("displayName"), "emailAddress": data.get("emailAddress")}

            elif request.action == "getProjects":
                response = await client.get(f"{base_url}/rest/api/3/project", headers=headers)
                response.raise_for_status()
                return response.json()

            elif request.action == "getIssues":
                jql = (
                    f'project = "{request.projectKey}" ORDER BY updated DESC'
                    if request.projectKey
                    else "updated >= -30d ORDER BY updated DESC"
                )
                body = {
                    "jql": jql,
                    "maxResults": 100,
                    "fields": ["summary", "status", "priority", "assignee",
                               "issuetype", "description", "created", "updated"],
                }
                response = await client.post(
                    f"{base_url}/rest/api/3/search/jql", headers=headers, json=body
                )
                response.raise_for_status()
                data = response.json()
                return {"issues": data.get("issues", []), "total": data.get("total", 0)}

            elif request.action == "getIssue" and request.issueKey:
                response = await client.get(
                    f"{base_url}/rest/api/3/issue/{request.issueKey}", headers=headers
                )
                response.raise_for_status()
                return response.json()

            else:
                raise HTTPException(status_code=400, detail=f"Unknown action: {request.action}")

    except httpx.HTTPStatusError as e:
        logger.error(f"JIRA API error: {e.response.status_code} - {e.response.text}")
        raise HTTPException(status_code=e.response.status_code, detail=e.response.text)
    except Exception as e:
        logger.error(f"JIRA proxy error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
