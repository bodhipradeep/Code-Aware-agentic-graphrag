"""Pydantic request/response models for all API endpoints."""

from typing import Optional
from pydantic import BaseModel


class QueryRequest(BaseModel):
    query: str
    user_id: Optional[str] = None
    jira_key: Optional[str] = None
    error: Optional[str] = None
    error_message: Optional[str] = None
    log_content: Optional[str] = None
    file_hint: Optional[str] = None


class ResumeRequest(BaseModel):
    thread_id: str
    human: str
    feedback: Optional[str] = None
    user_id: Optional[str] = None
    jira_key: Optional[str] = None


class IndexRequest(BaseModel):
    path: str


class MemoryTTLRequest(BaseModel):
    ttl_years: Optional[float] = None
    ttl_days: Optional[int] = None
    delete_before: Optional[str] = None


class JiraRequest(BaseModel):
    action: str
    projectKey: Optional[str] = None
    issueKey: Optional[str] = None
    jql: Optional[str] = None
