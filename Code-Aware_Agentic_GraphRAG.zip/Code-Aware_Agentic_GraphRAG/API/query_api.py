"""Query and resume endpoints — the core agentic pipeline API."""

import json
import random
import string
import logging

from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import StreamingResponse
from langgraph.types import Command
from Config.settings import CONFIG

from .models import QueryRequest, ResumeRequest
from .dependencies import (
    graph, workflow_logs, workflow_logs_lock, session_lock,
    SessionData, query_sessions, save_session_to_redis,
    get_session_from_redis, save_pipeline_log, CaptureOutput,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["query"])

NODE_TO_STEP = {
    "memory_check": -1,
    "cache_hit": -1,
    "investigation_planner": 0,
    "hierarchical_localizer": 1,
    "evidence_collector": 2,
    "root_cause_analyzer": 3,
    "fix_generator": 4,
    "fix_verifier": 5,
    "developer_review": 6,
    "feedback_capture": 0,
    "finalize": 6,
    "end_not_relevant": 6,
}


@router.post("/query")
def query_code(request: QueryRequest):
    """Submit a bug query to the 6-phase agentic pipeline."""
    try:
        thread_id = request.user_id if request.user_id else "".join(
            random.choices(string.ascii_uppercase + string.digits, k=5)
        )
        config = {"configurable": {"thread_id": thread_id}}

        with session_lock:
            session = SessionData(
                query=request.query,
                user_id=request.user_id or "anonymous",
                error=request.error,
                file_hint=request.file_hint,
            )
            query_sessions[thread_id] = session
            save_session_to_redis(thread_id, session)

        full_query = request.query
        if request.error:
            full_query += f" | Error: {request.error}"
        if request.file_hint:
            full_query += f" | File: {request.file_hint}"

        with workflow_logs_lock:
            workflow_logs[thread_id] = []

        capture = CaptureOutput()
        with capture:
            initial_state = {
                "original_query": full_query,
                "question": full_query,
                "user_id": request.user_id or "anonymous",
                "investigation_plan": None,
                "candidate_locations": [],
                "investigation_round": 0,
                "code_evidence": "",
                "call_chain_evidence": "",
                "root_cause": None,
                "documents": [],
                "graph_context": "",
                "guided_file_paths": [],
                "generation": "",
                "generation_attempts": 0,
                "query_transform_count": 0,
                "human": None,
                "feedback": None,
                "feedback_count": 0,
                "feedback_history": [],
                "memory_hit": False,
                "cached_response": None,
                "final_report": None,
            }
            result = graph.invoke(initial_state, config=config)

        with workflow_logs_lock:
            workflow_logs[thread_id] = capture.captured.split("\n") if capture.captured else []

        output = result.get("final_report") or result.get("generation", "")
        is_cache_hit = result.get("memory_hit", False)
        status = "cache_hit" if is_cache_hit else (
            "completed" if result.get("final_report") else "needs_review"
        )
        query_transform_count = result.get("query_transform_count", 0)

        save_pipeline_log(
            pipeline_type="query",
            jira_key=request.jira_key,
            user_email=request.user_id or "anonymous",
            model=CONFIG.get("llm_model", "llama3.1:8b"),
            refiner_model=CONFIG.get("refiner_model", "llama3.1:8b"),
            query_refined=(query_transform_count > 0),
            status=status,
            input_text=full_query[:5000],
            output_text=output[:10000],
            iterations=query_transform_count,
            snippets=[],
            reasoning="\n".join(workflow_logs.get(thread_id, [])),
        )

        return {
            "thread_id": thread_id,
            "query": request.query,
            "answer": output,
            "query_transforms": query_transform_count,
            "status": status,
            "logs": workflow_logs.get(thread_id, []) if not workflow_logs_lock.locked() else [],
        }

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/query/stream")
def query_code_stream(request: QueryRequest):
    """SSE streaming endpoint — yields progress events as each pipeline phase completes."""

    thread_id = request.user_id if request.user_id else "".join(
        random.choices(string.ascii_uppercase + string.digits, k=5)
    )
    config = {"configurable": {"thread_id": thread_id}}

    with session_lock:
        session = SessionData(
            query=request.query,
            user_id=request.user_id or "anonymous",
            error=request.error,
            file_hint=request.file_hint,
        )
        query_sessions[thread_id] = session
        save_session_to_redis(thread_id, session)

    full_query = request.query
    if request.error:
        full_query += f" | Error: {request.error}"
    if request.file_hint:
        full_query += f" | File: {request.file_hint}"

    with workflow_logs_lock:
        workflow_logs[thread_id] = []

    initial_state = {
        "original_query": full_query,
        "question": full_query,
        "user_id": request.user_id or "anonymous",
        "investigation_plan": None,
        "candidate_locations": [],
        "investigation_round": 0,
        "code_evidence": "",
        "call_chain_evidence": "",
        "root_cause": None,
        "documents": [],
        "graph_context": "",
        "guided_file_paths": [],
        "generation": "",
        "generation_attempts": 0,
        "query_transform_count": 0,
        "human": None,
        "feedback": None,
        "feedback_count": 0,
        "feedback_history": [],
        "memory_hit": False,
        "cached_response": None,
        "final_report": None,
    }

    def event_generator():
        yield f"data: {json.dumps({'type': 'start', 'thread_id': thread_id})}\n\n"

        all_logs = []
        result = {}
        hit_interrupt = False
        capture = CaptureOutput()

        try:
            with capture:
                for event in graph.stream(initial_state, config=config, stream_mode="updates"):
                    for node_name, updates in event.items():
                        # LangGraph yields __interrupt__ when a node calls interrupt()
                        if node_name == "__interrupt__":
                            hit_interrupt = True
                            continue

                        step = NODE_TO_STEP.get(node_name, -1)

                        current_output = capture._capture.getvalue() if capture._capture else ""
                        new_lines = current_output.split("\n")
                        new_logs = new_lines[len(all_logs):]
                        all_logs = new_lines

                        log_lines = [l for l in new_logs if l.strip()]

                        evt = {
                            "type": "phase",
                            "node": node_name,
                            "step": step,
                            "logs": log_lines,
                        }

                        if node_name == "memory_check" and isinstance(updates, dict) and updates.get("memory_hit"):
                            evt["type"] = "cache_hit"
                        if node_name == "end_not_relevant":
                            evt["type"] = "not_relevant"

                        yield f"data: {json.dumps(evt)}\n\n"

                        if isinstance(updates, dict):
                            result.update(updates)

        except Exception as exc:
            yield f"data: {json.dumps({'type': 'error', 'message': str(exc)})}\n\n"
            return

        # Flush remaining stdout
        final_output = capture._capture.getvalue() if capture._capture else ""
        remaining_lines = final_output.split("\n")[len(all_logs):]
        remaining_logs = [l for l in remaining_lines if l.strip()]
        if remaining_logs:
            yield f"data: {json.dumps({'type': 'phase', 'node': 'developer_review', 'step': 6, 'logs': remaining_logs})}\n\n"

        with workflow_logs_lock:
            workflow_logs[thread_id] = final_output.split("\n") if final_output else []

        output = result.get("final_report") or result.get("generation", "")
        is_cache_hit = result.get("memory_hit", False)

        if hit_interrupt:
            status = "needs_review"
        elif is_cache_hit:
            status = "cache_hit"
        elif result.get("final_report"):
            status = "completed"
        else:
            status = "needs_review"

        query_transform_count = result.get("query_transform_count", 0)

        save_pipeline_log(
            pipeline_type="query",
            jira_key=request.jira_key,
            user_email=request.user_id or "anonymous",
            model=CONFIG.get("llm_model", "llama3.1:8b"),
            refiner_model=CONFIG.get("refiner_model", "llama3.1:8b"),
            query_refined=(query_transform_count > 0),
            status=status,
            input_text=full_query[:5000],
            output_text=output[:10000],
            iterations=query_transform_count,
            snippets=[],
            reasoning="\n".join(workflow_logs.get(thread_id, [])),
        )

        yield f"data: {json.dumps({'type': 'complete', 'thread_id': thread_id, 'answer': output, 'status': status, 'query_transforms': query_transform_count, 'logs': workflow_logs.get(thread_id, [])})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/resume")
def resume_analysis(request: ResumeRequest):
    """Resume workflow with developer approval or feedback."""
    try:
        session_data = get_session_from_redis(request.thread_id)
        if not session_data:
            raise HTTPException(status_code=404, detail="Session not found")

        config = {"configurable": {"thread_id": request.thread_id}}
        current_state = graph.get_state(config)

        if not current_state or not current_state.next:
            raise HTTPException(
                status_code=400,
                detail="No active workflow to resume. This query has already completed.",
            )

        updated_state = {}
        if request.human == "feedback" and request.feedback:
            if current_state and current_state.values:
                updated_state["feedback"] = request.feedback
                current_feedback_count = current_state.values.get("feedback_count", 0)
                updated_state["feedback_count"] = current_feedback_count + 1
                existing_history = list(current_state.values.get("feedback_history", []) or [])
                existing_history.append(request.feedback)
                updated_state["feedback_history"] = existing_history

        capture = CaptureOutput()
        with capture:
            result = graph.invoke(
                Command(resume=request.human, update=updated_state), config=config
            )

        with workflow_logs_lock:
            if request.thread_id not in workflow_logs:
                workflow_logs[request.thread_id] = []
            workflow_logs[request.thread_id].extend(
                capture.captured.split("\n") if capture.captured else []
            )

        answer = result.get("final_report") or result.get("generation", "")
        feedback_count = result.get("feedback_count", 0)

        save_pipeline_log(
            pipeline_type="resume",
            jira_key=request.jira_key,
            user_email=session_data.user_id,
            model=CONFIG.get("llm_model", "llama3.1:8b"),
            refiner_model=CONFIG.get("refiner_model", "llama3.1:8b"),
            query_refined=False,
            status="completed" if request.human == "approved" else "reanalyzed",
            input_text=session_data.query[:5000],
            output_text=answer[:10000],
            human_approved=(request.human == "approved"),
            iterations=feedback_count,
            feedback=request.feedback,
            snippets=[],
            reasoning="\n".join(workflow_logs.get(request.thread_id, [])),
        )

        return {
            "thread_id": request.thread_id,
            "answer": answer,
            "status": "completed" if request.human == "approved" else "reanalyzed",
            "attempt": feedback_count if request.human == "feedback" else 0,
            "logs": workflow_logs.get(request.thread_id, []),
        }

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Resume error: {str(exc)}")


@router.get("/state/{thread_id}")
def get_state(thread_id: str):
    """Get current workflow state for a thread."""
    try:
        config = {"configurable": {"thread_id": thread_id}}
        state = graph.get_state(config)
        return {
            "thread_id": thread_id,
            "original_query": state.values.get("original_query", ""),
            "current_question": state.values.get("question", ""),
            "query_transforms": state.values.get("query_transform_count", 0),
            "feedback_count": state.values.get("feedback_count", 0),
            "final_report": state.values.get("final_report", ""),
            "human": state.values.get("human"),
            "is_approved": state.values.get("is_approved"),
            "next_nodes": list(state.next) if state.next else [],
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/refine-query")
async def refine_query(request: QueryRequest):
    """Refine a JIRA bug description into a focused query. Auto-extracts errors from logs."""
    from Utils.model_loader import create_llm
    from Prompt_lib.query_refiner import QUERY_REFINER_PROMPT, ERROR_EXTRACTOR_PROMPT

    try:
        refiner_llm = create_llm(
            provider="ollama",
            model=CONFIG["refiner_model"],
            base_url=CONFIG.get("ollama_base_url", "http://localhost:11434"),
            temperature=0.3,
        )

        extracted_error = None
        if request.log_content and not request.error_message:
            try:
                error_prompt = ERROR_EXTRACTOR_PROMPT.format(log_content=request.log_content)
                error_response = refiner_llm.invoke(error_prompt)
                extracted_error = str(error_response.content).strip() if hasattr(error_response, "content") else ""
                if extracted_error.lower() == "(none)":
                    extracted_error = None
            except Exception as e:
                logger.warning(f"Failed to extract error from logs: {e}")

        jira_desc = request.query or "(empty)"
        error_msg = request.error_message or extracted_error or "(none)"

        prompt = QUERY_REFINER_PROMPT.format(
            jira_description=jira_desc, error_message=error_msg
        )
        response = refiner_llm.invoke(prompt)
        refined_query = str(response.content).strip() if hasattr(response, "content") else ""

        prefixes_to_remove = [
            "here is the refined query:", "here is a refined query:",
            "refined query:", "here's the refined query:", "here's a refined query:",
        ]
        refined_lower = refined_query.lower()
        for prefix in prefixes_to_remove:
            if refined_lower.startswith(prefix):
                refined_query = refined_query[len(prefix):].strip()
                break

        if (refined_query.startswith('"') and refined_query.endswith('"')) or \
           (refined_query.startswith("'") and refined_query.endswith("'")):
            refined_query = refined_query[1:-1].strip()

        return {
            "original_query": request.query,
            "refined_query": refined_query,
            "extracted_error": extracted_error,
            "status": "success",
        }

    except Exception as e:
        logger.error(f"Query refinement error: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to refine query: {str(e)}")
