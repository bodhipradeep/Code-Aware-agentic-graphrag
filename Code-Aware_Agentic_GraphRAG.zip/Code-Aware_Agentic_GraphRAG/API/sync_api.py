"""GitLab sync endpoints — SSE streaming for backend/frontend codebase sync."""

import os
import json
import logging

from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from Config.settings import CONFIG
from Chunker.ast_chunker import chunk_documents
from Utils.chunk_saver import save_chunks_to_json, delete_chunks_by_paths
from Knowledge_Graph.graph_builder import build_graph_from_chunks

from .dependencies import (
    vector_store, graph_store, get_db_connection, refresh_pipeline,
)
from .admin_api import _load_chunks_from_pgvector

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/admin", tags=["admin"])


def _get_last_sync_commit(label: str):
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT config_value FROM system_config WHERE config_key = %s",
            (f"last_sync_commit_{label}",),
        )
        row = cur.fetchone()
        cur.close()
        conn.close()
        return row[0] if row else None
    except Exception as e:
        logger.warning(f"Could not read last sync commit for {label}: {e}")
        return None


def _save_last_sync_commit(label: str, commit_sha: str):
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO system_config (config_key, config_value, updated_at)
               VALUES (%s, %s, NOW())
               ON CONFLICT (config_key)
               DO UPDATE SET config_value = EXCLUDED.config_value, updated_at = NOW()""",
            (f"last_sync_commit_{label}", commit_sha),
        )
        conn.commit()
        cur.close()
        conn.close()
    except Exception as e:
        logger.error(f"Could not save last sync commit for {label}: {e}")


def _gitlab_sync_stream(label: str, project_key: str, branch_key: str, git_dir_key: str = ""):
    """Generator that streams SSE events for GitLab sync + ingestion pipeline."""

    def generate():
        try:
            from Gitlab.gitlab_api import (
                get_latest_commit, fetch_all_files_as_documents,
                fetch_changed_files_as_documents,
            )

            gitlab_url = (CONFIG.get("gitlab_url") or "").rstrip("/")
            token = CONFIG.get("gitlab_token") or ""
            project = CONFIG.get(project_key, "")
            branch = CONFIG.get(branch_key, "") or "main"
            git_dir = CONFIG.get(git_dir_key, "") if git_dir_key else ""

            if not gitlab_url or not token or not project:
                yield f"data: {json.dumps({'phase': 'error', 'message': 'GitLab URL, token, or project not configured'})}\n\n"
                return

            yield f"data: {json.dumps({'phase': 'syncing', 'message': f'Fetching {label} from GitLab API...'})}\n\n"

            latest_commit = get_latest_commit(gitlab_url, token, project, branch)
            if not latest_commit:
                yield f"data: {json.dumps({'phase': 'error', 'message': 'Could not fetch latest commit from GitLab'})}\n\n"
                return

            previous_commit = _get_last_sync_commit(label)
            repo_has_chunks = vector_store.has_chunks_for_label(label)

            if not previous_commit or not repo_has_chunks:
                sync_type = "full"
            elif previous_commit == latest_commit:
                sync_type = "no_changes"
            else:
                sync_type = "incremental"

            yield f"data: {json.dumps({'phase': 'synced', 'message': f'GitLab API fetch complete ({sync_type})', 'sync_type': sync_type})}\n\n"

            # No changes
            if sync_type == "no_changes":
                stats = vector_store.get_stats()
                try:
                    g_stats = graph_store.get_stats()
                    graph_files = g_stats.get("files", 0)
                    vector_files = stats.get("unique_files", 0)
                    if vector_files > 0 and graph_files < vector_files * 0.5:
                        yield f"data: {json.dumps({'phase': 'graph_build', 'message': f'Graph underpopulated ({graph_files} vs {vector_files} files). Rebuilding...'})}\n\n"
                        chunks, src_texts = _load_chunks_from_pgvector(vector_store)
                        if chunks:
                            graph_store.clear_all()
                            g_result = build_graph_from_chunks(chunks, graph_store, src_texts)
                            g_msg = f"Graph rebuilt: {g_result['files']} files, {g_result['classes']} classes"
                        yield f"data: {json.dumps({'phase': 'graph_built', 'message': g_msg, 'graph_stats': g_result})}\n\n"
                        yield f"data: {json.dumps({'phase': 'done', 'message': 'Code up-to-date, graph rebuilt', 'stats': stats})}\n\n"
                        return
                except Exception as ge:
                    logger.warning(f"Graph rebuild check failed: {ge}")

                yield f"data: {json.dumps({'phase': 'done', 'message': 'Repository already up-to-date', 'chunks': 0, 'files': 0, 'stats': stats})}\n\n"
                return

            # Incremental sync
            if sync_type == "incremental":
                yield f"data: {json.dumps({'phase': 'loading', 'message': 'Fetching changed files since last sync...'})}\n\n"
                documents, paths_to_upsert, paths_to_delete = fetch_changed_files_as_documents(
                    gitlab_url, token, project, branch, previous_commit, latest_commit, git_dir
                )

                if documents is None:
                    yield f"data: {json.dumps({'phase': 'synced', 'message': 'Too many changes, switching to full sync...'})}\n\n"
                    sync_type = "full"
                else:
                    total_changed = len(paths_to_upsert) + len(paths_to_delete)
                    yield f"data: {json.dumps({'phase': 'synced', 'message': f'Found {total_changed} changed file(s)', 'files_added': len(paths_to_upsert), 'files_deleted': len(paths_to_delete)})}\n\n"

                    if paths_to_delete:
                        yield f"data: {json.dumps({'phase': 'deleting', 'message': f'Removing {len(paths_to_delete)} deleted file(s)...'})}\n\n"
                        vector_store._delete_by_relative_paths(paths_to_delete)
                        delete_chunks_by_paths(paths_to_delete)

                    if not documents:
                        _save_last_sync_commit(label, latest_commit)
                        stats = vector_store.get_stats()
                        yield f"data: {json.dumps({'phase': 'done', 'message': 'No supported files to add/update', 'stats': stats})}\n\n"
                        return

                    yield from _chunk_embed_graph(documents, paths_to_upsert, paths_to_delete, label)

            # Full sync
            if sync_type == "full":
                yield f"data: {json.dumps({'phase': 'loading', 'message': f'Fetching all {label} files from GitLab API...'})}\n\n"
                documents = fetch_all_files_as_documents(
                    gitlab_url, token, project, branch, git_dir
                )
                if not documents:
                    yield f"data: {json.dumps({'phase': 'done', 'message': 'No supported files found'})}\n\n"
                    return
                yield f"data: {json.dumps({'phase': 'loaded', 'message': f'Fetched {len(documents)} files', 'files': len(documents)})}\n\n"

                yield from _chunk_embed_graph(documents, None, None, label)

            _save_last_sync_commit(label, latest_commit)

            yield f"data: {json.dumps({'phase': 'refreshing', 'message': 'Refreshing RAG pipeline...'})}\n\n"
            refresh_pipeline()

            stats = vector_store.get_stats()
            yield f"data: {json.dumps({'phase': 'done', 'message': 'Pipeline refreshed', 'stats': stats})}\n\n"

        except Exception as e:
            logger.error(f"{label} GitLab sync error: {e}")
            yield f"data: {json.dumps({'phase': 'error', 'message': str(e)})}\n\n"

    return generate


def _chunk_embed_graph(documents, paths_to_upsert, paths_to_delete, label):
    """Shared chunking → embedding → graph pipeline for both sync types."""
    yield f"data: {json.dumps({'phase': 'chunking', 'message': f'Chunking {len(documents)} file(s)...'})}\n\n"
    chunked_docs = chunk_documents(documents)
    if not chunked_docs:
        yield f"data: {json.dumps({'phase': 'done', 'message': 'Chunking produced no results'})}\n\n"
        return

    total_chunks = len(chunked_docs)
    yield f"data: {json.dumps({'phase': 'chunked', 'message': f'Created {total_chunks} chunks', 'total_chunks': total_chunks})}\n\n"

    save_chunks_to_json(chunked_docs)

    if paths_to_upsert is not None:
        vector_store._delete_by_relative_paths(paths_to_upsert)
    else:
        all_paths = set(doc.metadata.get("relative_path", "unknown") for doc in chunked_docs)
        vector_store._delete_by_relative_paths(all_paths)

    BATCH_SIZE = 100
    for i in range(0, total_chunks, BATCH_SIZE):
        batch = chunked_docs[i:i + BATCH_SIZE]
        done = min(i + BATCH_SIZE, total_chunks)
        yield f"data: {json.dumps({'phase': 'embedding', 'message': f'Embedding {done}/{total_chunks}', 'embedded': done, 'total_chunks': total_chunks})}\n\n"
        vector_store.add_documents(batch, replace_files=False)

    vector_store.save()

    yield f"data: {json.dumps({'phase': 'graph_build', 'message': 'Building knowledge graph...'})}\n\n"
    try:
        if paths_to_delete:
            for dp in paths_to_delete:
                graph_store.clear_by_file(dp)
        if paths_to_upsert:
            for up in paths_to_upsert:
                graph_store.clear_by_file(up)
        else:
            all_paths = set(doc.metadata.get("relative_path", "unknown") for doc in chunked_docs)
            for p in all_paths:
                graph_store.clear_by_file(p)

        source_texts = {
            doc.metadata.get("relative_path", ""): doc.page_content
            for doc in documents if doc.metadata.get("relative_path")
        }
        g_stats = build_graph_from_chunks(chunked_docs, graph_store, source_texts)
        g_msg = f"Graph: {g_stats['files']} files, {g_stats['classes']} classes, {g_stats['methods']} methods"
        yield f"data: {json.dumps({'phase': 'graph_built', 'message': g_msg, 'graph_stats': g_stats})}\n\n"
    except Exception as ge:
        logger.error(f"Graph build failed (non-blocking): {ge}")
        yield f"data: {json.dumps({'phase': 'graph_warning', 'message': f'Graph build failed: {str(ge)}'})}\n\n"


@router.post("/gitlab-sync/backend")
def sync_backend_gitlab():
    """Sync backend codebase from GitLab (SSE stream)."""
    gen = _gitlab_sync_stream("backend", "backend_project", "backend_branch")
    return StreamingResponse(gen(), media_type="text/event-stream")


@router.post("/gitlab-sync/frontend")
def sync_frontend_gitlab():
    """Sync frontend codebase from GitLab (SSE stream)."""
    gen = _gitlab_sync_stream("frontend", "frontend_project", "frontend_branch", "frontend_git_dir")
    return StreamingResponse(gen(), media_type="text/event-stream")
