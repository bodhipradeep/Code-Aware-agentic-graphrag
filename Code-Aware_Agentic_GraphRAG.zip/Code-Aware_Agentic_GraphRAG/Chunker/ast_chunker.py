"""
AST-based Chunker for Java and Angular/TypeScript files.
Uses tree-sitter for accurate code parsing.
"""

from typing import List, Dict
import logging
from langchain_core.documents import Document
from tree_sitter import Language, Parser
import tree_sitter_java as tsjava
import tree_sitter_typescript as ts_typescript
import re

logger = logging.getLogger(__name__)


# ==================== HELPER FUNCTIONS ====================

def find_nodes_by_type(node, node_type):
    """Recursively find all nodes of a specific type."""
    results = []
    if node.type == node_type:
        results.append(node)
    for child in node.children:
        results.extend(find_nodes_by_type(child, node_type))
    return results


def extract_method_signature(method_node, source_code):
    """Extract method signature from a method node."""
    try:
        modifiers, return_type, name, params = [], "", "unknown", []
        for child in method_node.children:
            if child.type == 'modifiers':
                for mod in child.children:
                    if mod.type not in ('marker_annotation', 'annotation'):
                        modifiers.append(source_code[mod.start_byte:mod.end_byte])
            elif child.type in ('type', 'type_identifier', 'void_type', 'generic_type'):
                if not return_type:
                    return_type = source_code[child.start_byte:child.end_byte].strip()
            elif child.type == 'identifier':
                if name == "unknown":
                    name = source_code[child.start_byte:child.end_byte]
            elif child.type == 'formal_parameters':
                params.append(source_code[child.start_byte:child.end_byte])
        signature = f"{' '.join(modifiers)} {return_type} {name}({', '.join(params)})".strip()
        return {"signature": re.sub(r'\s+', ' ', signature), "name": name, "return_type": return_type}
    except:
        return {"signature": "unknown", "name": "unknown", "return_type": ""}


def extract_preceding_comments(node, source_code):
    """Extract comments preceding a node."""
    lines_before = source_code[:node.start_byte].split('\n')
    comment_lines = []
    for line in reversed(lines_before):
        stripped = line.strip()
        if stripped.startswith('//'):
            comment_lines.insert(0, line)
        elif stripped.endswith('*/'):
            comment_lines.insert(0, line)
        elif '/*' in stripped and not stripped.endswith('*/'):
            comment_lines.insert(0, line)
            break
        elif comment_lines and (stripped.startswith('*') or not stripped):
            comment_lines.insert(0, line)
        elif stripped and not comment_lines:
            break
        elif comment_lines:
            break
    return '\n'.join(comment_lines) if comment_lines else None


def extract_field_declarations(class_node, source_code):
    """Extract field declarations from a class."""
    fields = []
    class_body = None
    for child in class_node.children:
        if child.type == 'class_body':
            class_body = child
            break
    if not class_body:
        return fields
    for child in class_body.children:
        if child.type == 'field_declaration':
            field_text = source_code[child.start_byte:child.end_byte]
            comments = extract_preceding_comments(child, source_code)
            if comments:
                field_text = comments + '\n' + field_text
            fields.append(field_text)
    return fields


# ==================== JAVA AST CHUNKER ====================

def chunk_java_ast(source_text: str, filename: str, relative_path: str = None) -> List[Dict]:
    """Chunk Java source code using AST parsing."""
    parser = Parser(Language(tsjava.language()))
    tree = parser.parse(bytes(source_text, "utf8"))
    root = tree.root_node
    chunks = []
    
    # Package
    package_name = None
    for pkg in find_nodes_by_type(root, 'package_declaration'):
        for child in pkg.children:
            if child.type in ('scoped_identifier', 'identifier'):
                package_name = source_text[child.start_byte:child.end_byte]
                break
    
    # Imports
    imports = []
    for imp in find_nodes_by_type(root, 'import_declaration'):
        for child in imp.children:
            if child.type in ('scoped_identifier', 'identifier'):
                imports.append(source_text[child.start_byte:child.end_byte])
                break
    
    # Class name
    class_name = "UnknownClass"
    class_nodes = find_nodes_by_type(root, 'class_declaration')
    if class_nodes:
        for child in class_nodes[0].children:
            if child.type == 'identifier':
                class_name = source_text[child.start_byte:child.end_byte]
                break
    
    # Fields
    fields = extract_field_declarations(class_nodes[0], source_text) if class_nodes else []
    
    # Class synopsis chunk
    synopsis = []
    if package_name:
        synopsis.append(f"package {package_name};")
    if imports:
        synopsis.append("imports: " + ", ".join(imports))
    synopsis.append(f"class {class_name}")
    if fields:
        synopsis.append("\n// Fields:")
        synopsis.extend(fields)
    
    chunks.append({
        "text": "\n".join(synopsis),
        "metadata": {
            "file_name": filename,
            "relative_path": relative_path,
            "package": package_name,
            "class_name": class_name,
            "method": None,
            "chunk_type": "class_synopsis",
            "language": "java"
        }
    })
    
    # Methods
    for method_node in find_nodes_by_type(root, 'method_declaration'):
        try:
            comments = extract_preceding_comments(method_node, source_text)
            method_text = source_text[method_node.start_byte:method_node.end_byte]
            sig_info = extract_method_signature(method_node, source_text)
            start_line = source_text.count('\n', 0, method_node.start_byte) + 1
            end_line = source_text.count('\n', 0, method_node.end_byte) + 1
            
            chunk_text = f"// File: {filename}\n"
            if package_name:
                chunk_text += f"// Package: {package_name}\n"
            chunk_text += f"// Class: {class_name}\n"
            chunk_text += f"// Method: {sig_info['signature']}\n"
            chunk_text += f"// Lines: {start_line}-{end_line}\n\n"
            if comments:
                chunk_text += comments + '\n'
            chunk_text += method_text
            
            chunks.append({
                "text": chunk_text,
                "metadata": {
                    "file_name": filename,
                    "relative_path": relative_path,
                    "package": package_name,
                    "class_name": class_name,
                    "method": sig_info['name'],
                    "signature": sig_info['signature'],
                    "start_line": start_line,
                    "end_line": end_line,
                    "chunk_type": "method",
                    "language": "java"
                }
            })
        except Exception as e:
            print(f"Error parsing method in {filename}: {e}")
    
    # Constructors
    for cons_node in find_nodes_by_type(root, 'constructor_declaration'):
        try:
            comments = extract_preceding_comments(cons_node, source_text)
            cons_text = source_text[cons_node.start_byte:cons_node.end_byte]
            start_line = source_text.count('\n', 0, cons_node.start_byte) + 1
            end_line = source_text.count('\n', 0, cons_node.end_byte) + 1
            
            chunk_text = f"// File: {filename}\n// Class: {class_name}\n// Constructor\n// Lines: {start_line}-{end_line}\n\n"
            if comments:
                chunk_text += comments + '\n'
            chunk_text += cons_text
            
            chunks.append({
                "text": chunk_text,
                "metadata": {
                    "file_name": filename,
                    "relative_path": relative_path,
                    "class_name": class_name,
                    "method": class_name,
                    "chunk_type": "constructor",
                    "language": "java"
                }
            })
        except Exception as e:
            logger.warning(f"Error parsing constructor in {filename}: {e}")
    
    return chunks


# ==================== ANGULAR/TYPESCRIPT AST CHUNKER ====================

def chunk_angular_ast(source_text: str, filename: str, relative_path: str = None) -> List[Dict]:
    """Chunk Angular/TypeScript source code using AST parsing."""
    parser = Parser(Language(ts_typescript.language_typescript()))
    tree = parser.parse(bytes(source_text, "utf8"))
    root = tree.root_node
    chunks = []
    
    # Determine file type
    file_type = "unknown"
    if ".component." in filename:
        file_type = "component"
    elif ".service." in filename:
        file_type = "service"
    elif ".module." in filename:
        file_type = "module"
    elif ".directive." in filename:
        file_type = "directive"
    elif ".pipe." in filename:
        file_type = "pipe"
    
    # Extract imports
    imports = []
    for imp in find_nodes_by_type(root, 'import_statement'):
        imports.append(source_text[imp.start_byte:imp.end_byte])
    
    # Extract class name
    class_name = "UnknownClass"
    class_nodes = find_nodes_by_type(root, 'class_declaration')
    if class_nodes:
        for child in class_nodes[0].children:
            if child.type == 'type_identifier':
                class_name = source_text[child.start_byte:child.end_byte]
                break
    
    # Extract decorator
    decorator = None
    for dec in find_nodes_by_type(root, 'decorator'):
        decorator = source_text[dec.start_byte:dec.end_byte]
        break
    
    # Class synopsis chunk
    synopsis = []
    if imports:
        synopsis.append("// Imports:")
        synopsis.extend(imports[:5])
        if len(imports) > 5:
            synopsis.append(f"// ... and {len(imports) - 5} more imports")
    if decorator:
        synopsis.append(f"\n{decorator}")
    synopsis.append(f"export class {class_name}")
    
    chunks.append({
        "text": "\n".join(synopsis),
        "metadata": {
            "file_name": filename,
            "relative_path": relative_path,
            "class_name": class_name,
            "file_type": file_type,
            "chunk_type": "class_synopsis",
            "language": "angular"
        }
    })
    
    # Extract methods
    for method_node in find_nodes_by_type(root, 'method_definition'):
        try:
            method_text = source_text[method_node.start_byte:method_node.end_byte]
            
            method_name = "unknown"
            for child in method_node.children:
                if child.type == 'property_identifier':
                    method_name = source_text[child.start_byte:child.end_byte]
                    break
            
            start_line = source_text.count('\n', 0, method_node.start_byte) + 1
            end_line = source_text.count('\n', 0, method_node.end_byte) + 1
            
            chunk_text = f"// File: {filename}\n"
            chunk_text += f"// Class: {class_name}\n"
            chunk_text += f"// Method: {method_name}\n"
            chunk_text += f"// Lines: {start_line}-{end_line}\n\n"
            chunk_text += method_text
            
            chunks.append({
                "text": chunk_text,
                "metadata": {
                    "file_name": filename,
                    "relative_path": relative_path,
                    "class_name": class_name,
                    "method": method_name,
                    "file_type": file_type,
                    "start_line": start_line,
                    "end_line": end_line,
                    "chunk_type": "method",
                    "language": "angular"
                }
            })
        except Exception as e:
            logger.warning(f"Error parsing method in {filename}: {e}")
    
    # Extract fields
    if class_nodes:
        class_body = None
        for child in class_nodes[0].children:
            if child.type == 'class_body':
                class_body = child
                break
        
        if class_body:
            for child in class_body.children:
                if child.type in ('public_field_definition', 'field_definition'):
                    field_text = source_text[child.start_byte:child.end_byte]
                    chunks.append({
                        "text": f"// File: {filename}\n// Class: {class_name}\n// Field\n\n{field_text}",
                        "metadata": {
                            "file_name": filename,
                            "relative_path": relative_path,
                            "class_name": class_name,
                            "file_type": file_type,
                            "chunk_type": "field",
                            "language": "angular"
                        }
                    })
    
    return chunks


# ==================== MAIN CHUNKER ====================

def chunk_documents(documents: List[Document]) -> List[Document]:
    """
    Process documents using AST-based chunking based on language.
    
    Args:
        documents: List of Document objects with 'language' in metadata
        
    Returns:
        List of chunked Document objects
    """
    docs = []
    
    for idx, document in enumerate(documents):
        file_name = document.metadata.get("file_name", f"Unknown_{idx}")
        source_text = document.page_content
        relative_path = document.metadata.get("relative_path", file_name)
        language = document.metadata.get("language", "java")
        
        try:
            if language == "java":
                ast_chunks = chunk_java_ast(source_text, file_name, relative_path)
            else:
                ast_chunks = chunk_angular_ast(source_text, file_name, relative_path)
            
            for chunk in ast_chunks:
                doc = Document(page_content=chunk["text"], metadata=chunk["metadata"])
                docs.append(doc)
            
            if (idx + 1) % 10 == 0:
                logger.info(f"Processed {idx + 1}/{len(documents)} files...")
        
        except Exception as e:
            logger.error(f"Error processing {file_name}: {e}")
            document.metadata["language"] = language
            docs.append(document)
    
    logger.info(f"Created {len(docs)} AST chunks from {len(documents)} files")
    return docs
