from typing import List, Optional, Set
import logging
from pathlib import Path
from langchain_core.documents import Document
from langchain_community.document_loaders import TextLoader

logger = logging.getLogger(__name__)


def detect_language(file_path: Path) -> Optional[str]:
    """Detect language from file extension."""
    if file_path.suffix == ".java":
        return "java"
    elif file_path.suffix == ".ts" and ".spec." not in file_path.name:
        return "angular"
    return None


def _load_single_file(file_path: Path, relative_path: str) -> List[Document]:
    """Load a single code file and return Document(s) with metadata."""
    language = detect_language(file_path)
    if not language:
        return []
    # Normalize to forward slashes so paths are consistent across OS and git
    relative_path = relative_path.replace("\\", "/")
    try:
        loader = TextLoader(str(file_path), encoding="utf-8")
        file_docs = loader.load()
        for doc in file_docs:
            doc.metadata["file_name"] = file_path.name
            doc.metadata["relative_path"] = relative_path
            doc.metadata["language"] = language
        return file_docs
    except Exception as e:
        logger.warning(f"Skipping {file_path}: {e}")
        return []


def load_code_files(root_path: str) -> List[Document]:
    """
    Load Java and Angular/TypeScript files from a directory or single file.
    Auto-detects language based on file extension.
    """
    root = Path(root_path)
    documents = []

    if not root.exists():
        logger.error(f"{root} does not exist")
        raise FileNotFoundError(f"{root} does not exist")

    # Single file
    if root.is_file():
        docs = _load_single_file(root, root.name)
        if docs:
            logger.info(f"Loaded 1 file: {root.name}")
        else:
            logger.warning(f"Unsupported file type: {root.name}")
        return docs

    # Directory - find all java and ts files
    java_files = list(root.rglob("*.java"))
    ts_files = [f for f in root.rglob("*.ts") if ".spec." not in f.name]
    all_files = java_files + ts_files

    if not all_files:
        logger.warning(f"No Java or TypeScript files found in {root}")
        return documents

    for file_path in all_files:
        rel = str(file_path.relative_to(root))
        documents.extend(_load_single_file(file_path, rel))

    java_count = sum(1 for d in documents if d.metadata.get("language") == "java")
    angular_count = sum(1 for d in documents if d.metadata.get("language") == "angular")
    logger.info(f"Loaded {len(documents)} files (Java: {java_count}, Angular: {angular_count})")
    return documents


def load_changed_files(
    repo_dir: str,
    changed_files: List[dict],
) -> tuple[List[Document], Set[str], Set[str]]:
    """
    Load only the files that actually changed according to git diff.

    Args:
        repo_dir: Root path of the git repository.
        changed_files: List of dicts from gitlab_sync with keys:
            path, full_path, status (added/modified/deleted), exists.

    Returns:
        (documents_to_upsert, paths_to_upsert, paths_to_delete)
        - documents_to_upsert: Documents for files that are added or modified.
        - paths_to_upsert: relative_path values of those documents.
        - paths_to_delete: relative_path values of files that were deleted.
    """
    root = Path(repo_dir)
    documents: List[Document] = []
    paths_to_upsert: Set[str] = set()
    paths_to_delete: Set[str] = set()

    for finfo in changed_files:
        rel_path = finfo["path"].replace("\\", "/")
        full_path = Path(finfo["full_path"])
        status = finfo["status"]

        if status == "deleted":
            paths_to_delete.add(rel_path)
            continue

        # added, modified, renamed, copied → load the file
        if not full_path.exists():
            logger.warning(f"Changed file missing on disk, skipping: {rel_path}")
            continue

        language = detect_language(full_path)
        if not language:
            continue  # not a supported file type

        docs = _load_single_file(full_path, rel_path)
        if docs:
            documents.extend(docs)
            paths_to_upsert.add(rel_path)

    logger.info(
        f"Changed files: {len(paths_to_upsert)} to upsert, "
        f"{len(paths_to_delete)} to delete"
    )
    return documents, paths_to_upsert, paths_to_delete
