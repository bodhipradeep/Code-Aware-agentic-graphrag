"""
GitLab REST API client for fetching repository files directly
without cloning to local disk.
"""

import logging
import urllib.parse
from typing import List, Dict, Optional, Set, Tuple
from pathlib import PurePosixPath

import requests
import urllib3
from langchain_core.documents import Document

# Suppress InsecureRequestWarning for internal GitLab with self-signed certs
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {".java", ".ts"}
EXCLUDED_PATTERNS = {".spec."}


def _is_supported_file(path: str) -> bool:
    """Check if a file path is a supported code file."""
    p = PurePosixPath(path)
    if p.suffix not in SUPPORTED_EXTENSIONS:
        return False
    return not any(pat in p.name for pat in EXCLUDED_PATTERNS)


def _detect_language(path: str) -> Optional[str]:
    if path.endswith(".java"):
        return "java"
    if path.endswith(".ts") and ".spec." not in path:
        return "angular"
    return None


def _encode_project(project: str) -> str:
    """URL-encode a project path for GitLab API."""
    return urllib.parse.quote(project, safe="")


def _api_headers(token: str) -> dict:
    return {"PRIVATE-TOKEN": token}


def get_latest_commit(
    gitlab_url: str, token: str, project: str, branch: str
) -> Optional[str]:
    """Get the latest commit SHA for a branch."""
    url = f"{gitlab_url}/api/v4/projects/{_encode_project(project)}/repository/commits"
    resp = requests.get(
        url,
        headers=_api_headers(token),
        params={"ref_name": branch, "per_page": 1},
        timeout=30,
        verify=False,
    )
    resp.raise_for_status()
    commits = resp.json()
    return commits[0]["id"] if commits else None


def list_repo_tree(
    gitlab_url: str,
    token: str,
    project: str,
    branch: str,
    git_dir: str = "",
) -> List[str]:
    """List all supported files in the repository tree (paginated)."""
    encoded = _encode_project(project)
    all_files = []
    page = 1
    per_page = 100

    while True:
        url = f"{gitlab_url}/api/v4/projects/{encoded}/repository/tree"
        params = {
            "ref": branch,
            "recursive": "true",
            "per_page": per_page,
            "page": page,
        }
        if git_dir:
            params["path"] = git_dir

        resp = requests.get(
            url, headers=_api_headers(token), params=params, timeout=30, verify=False
        )
        resp.raise_for_status()
        items = resp.json()
        if not items:
            break

        for item in items:
            if item["type"] == "blob" and _is_supported_file(item["path"]):
                all_files.append(item["path"])

        if len(items) < per_page:
            break
        page += 1

    return all_files


def get_file_content(
    gitlab_url: str, token: str, project: str, file_path: str, branch: str
) -> Optional[str]:
    """Download raw file content from GitLab."""
    encoded_project = _encode_project(project)
    encoded_path = urllib.parse.quote(file_path, safe="")
    url = (
        f"{gitlab_url}/api/v4/projects/{encoded_project}"
        f"/repository/files/{encoded_path}/raw"
    )
    resp = requests.get(
        url,
        headers=_api_headers(token),
        params={"ref": branch},
        timeout=30,
        verify=False,
    )
    if resp.status_code == 404:
        return None
    resp.raise_for_status()
    return resp.text


def fetch_all_files_as_documents(
    gitlab_url: str,
    token: str,
    project: str,
    branch: str,
    git_dir: str = "",
) -> List[Document]:
    """Fetch all supported files from GitLab API and return as Documents."""
    file_paths = list_repo_tree(gitlab_url, token, project, branch, git_dir)
    logger.info("Found %d supported files in %s", len(file_paths), project)

    documents = []
    for fp in file_paths:
        content = get_file_content(gitlab_url, token, project, fp, branch)
        if content is None:
            logger.warning("Could not fetch %s, skipping", fp)
            continue

        language = _detect_language(fp)
        if not language:
            continue

        doc = Document(
            page_content=content,
            metadata={
                "file_name": PurePosixPath(fp).name,
                "relative_path": fp,
                "language": language,
                "source": fp,
            },
        )
        documents.append(doc)

    java_count = sum(1 for d in documents if d.metadata.get("language") == "java")
    angular_count = sum(
        1 for d in documents if d.metadata.get("language") == "angular"
    )
    logger.info(
        "Fetched %d files via API (Java: %d, Angular: %d)",
        len(documents),
        java_count,
        angular_count,
    )
    return documents


def compare_commits(
    gitlab_url: str, token: str, project: str, from_sha: str, to_sha: str
) -> List[Dict]:
    """Compare two commits and return changed files with status."""
    encoded = _encode_project(project)
    url = f"{gitlab_url}/api/v4/projects/{encoded}/repository/compare"
    resp = requests.get(
        url,
        headers=_api_headers(token),
        params={"from": from_sha, "to": to_sha},
        timeout=60,
        verify=False,
    )
    resp.raise_for_status()
    data = resp.json()

    # If GitLab timed out computing the diff, return None to signal full sync needed
    if data.get("compare_timeout") or data.get("overflow"):
        logger.warning(
            "GitLab compare timed out or overflowed (%s→%s), falling back to full sync",
            from_sha[:8], to_sha[:8],
        )
        return None

    changed = []
    for diff in data.get("diffs", []):
        path = diff.get("new_path") or diff.get("old_path", "")
        if diff.get("new_file"):
            status = "added"
        elif diff.get("deleted_file"):
            status = "deleted"
        elif diff.get("renamed_file"):
            status = "renamed"
        else:
            status = "modified"
        changed.append({
            "path": path,
            "old_path": diff.get("old_path", ""),
            "status": status,
        })
    return changed


def fetch_changed_files_as_documents(
    gitlab_url: str,
    token: str,
    project: str,
    branch: str,
    from_sha: str,
    to_sha: str,
    git_dir: str = "",
) -> Tuple[List[Document], Set[str], Set[str]]:
    """
    Fetch only changed files between two commits.

    Returns:
        (documents_to_upsert, paths_to_upsert, paths_to_delete)
    """
    changes = compare_commits(gitlab_url, token, project, from_sha, to_sha)

    # If compare timed out/overflowed, return None to signal caller to do full sync
    if changes is None:
        return None, None, None

    documents: List[Document] = []
    paths_to_upsert: Set[str] = set()
    paths_to_delete: Set[str] = set()

    for change in changes:
        path = change["path"]
        status = change["status"]

        # Filter by git_dir if specified
        if git_dir and not path.startswith(git_dir + "/"):
            continue

        if status == "deleted":
            if _is_supported_file(path):
                paths_to_delete.add(path)
            continue

        if not _is_supported_file(path):
            continue

        # For renamed files, also delete the old path
        if status == "renamed" and change.get("old_path"):
            old_path = change["old_path"]
            if _is_supported_file(old_path):
                paths_to_delete.add(old_path)

        content = get_file_content(gitlab_url, token, project, path, branch)
        if content is None:
            logger.warning("Could not fetch changed file %s, skipping", path)
            continue

        language = _detect_language(path)
        if not language:
            continue

        doc = Document(
            page_content=content,
            metadata={
                "file_name": PurePosixPath(path).name,
                "relative_path": path,
                "language": language,
                "source": path,
            },
        )
        documents.append(doc)
        paths_to_upsert.add(path)

    logger.info(
        "Changed files: %d to upsert, %d to delete",
        len(paths_to_upsert),
        len(paths_to_delete),
    )
    return documents, paths_to_upsert, paths_to_delete
