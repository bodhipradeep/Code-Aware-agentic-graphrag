"""
Agentic nodes for the Code-Aware Agentic GraphRAG pipeline.
Each node performs one step of the structured investigation.
LangGraph controls flow; the LLM makes decisions at each step.
"""

import json
import logging
from langgraph.types import interrupt
from .state import AgentState
from Prompt_lib.prompts import (
    INVESTIGATION_PLANNER_PROMPT,
    HIERARCHICAL_LOCALIZER_PROMPT,
    ROOT_CAUSE_ANALYZER_PROMPT,
    FIX_GENERATOR_PROMPT,
    FIX_VERIFIER_PROMPT,
    NOT_RELEVANT_REPORT,
)
from Utils.model_loader import get_llm

logger = logging.getLogger(__name__)


def _parse_json_response(text: str) -> dict:
    """Parse JSON from LLM response, handling markdown fences and extra text."""
    text = text.strip()
    if "```" in text:
        parts = text.split("```")
        for part in parts:
            part = part.strip()
            if part.startswith("json"):
                part = part[4:].strip()
            if part.startswith("{"):
                text = part
                break
    start = text.find("{")
    end = text.rfind("}") + 1
    if start >= 0 and end > start:
        try:
            return json.loads(text[start:end])
        except json.JSONDecodeError:
            pass
    return {}


# ==================== PHASE 1: INVESTIGATION PLANNER ====================

def investigation_planner_node(state: AgentState):
    """Phase 1: LLM reads the bug report and creates a structured investigation plan."""
    print("---🔍 PHASE 1: INVESTIGATION PLANNER---")
    query = state.get("original_query", "")
    feedback = state.get("feedback")
    feedback_history = state.get("feedback_history", [])

    feedback_section = ""
    if feedback:
        feedback_section = f"\nPrevious analysis was rejected. Developer feedback: {feedback}"
        if feedback_history:
            feedback_section += f"\nAll previous feedback: {' | '.join(feedback_history)}"
        feedback_section += "\nAdjust your investigation plan based on this feedback."

    prompt = INVESTIGATION_PLANNER_PROMPT.format(
        query=query,
        feedback_section=feedback_section
    )

    print(f"   Query: {query[:120]}")
    if feedback:
        print(f"   Feedback: {feedback[:100]}")

    response = get_llm().invoke([{"role": "user", "content": prompt}])
    plan = _parse_json_response(response.content)

    if not plan:
        logger.warning("Investigation planner returned invalid JSON, using defaults")
        plan = {
            "symptom": query[:200],
            "symptom_type": "unknown",
            "likely_layers": ["service", "controller"],
            "search_entities": {
                "class_names": [],
                "method_names": [],
                "api_paths": [],
                "error_types": [],
                "keywords": query.split()[:5]
            },
            "likely_flow": "Unknown — needs investigation",
            "investigation_priority": ["Search for relevant classes"]
        }

    print(f"   Symptom: {plan.get('symptom', 'unknown')[:100]}")
    print(f"   Likely layers: {plan.get('likely_layers', [])}")
    entities = plan.get("search_entities", {})
    print(f"   Search: classes={entities.get('class_names', [])}, "
          f"methods={entities.get('method_names', [])}, "
          f"api_paths={entities.get('api_paths', [])}")
    print(f"   Flow: {plan.get('likely_flow', 'unknown')[:120]}")

    return {
        "investigation_plan": plan,
        "feedback": None,
    }


# ==================== PHASE 2: HIERARCHICAL LOCALIZER ====================

def hierarchical_localizer_node(state: AgentState, toolkit):
    """Phase 2: Query the knowledge graph to find candidate bug locations,
    then have LLM rank them by likelihood."""
    print("---📍 PHASE 2: HIERARCHICAL LOCALIZER---")
    query = state.get("original_query", "")
    plan = state.get("investigation_plan", {})
    entities = plan.get("search_entities", {})

    candidates_text_parts = []
    all_class_names = set()

    class_names = entities.get("class_names", [])
    if class_names:
        matched = toolkit.search_classes(class_names)
        if matched:
            candidates_text_parts.append("CLASSES FOUND BY NAME:")
            for cls in matched:
                name = cls.get("name", "?")
                all_class_names.add(name)
                loc = []
                if cls.get("feature"):
                    loc.append(f"feature={cls['feature']}")
                if cls.get("layer_type"):
                    loc.append(f"layer={cls['layer_type']}")
                if cls.get("file_path"):
                    loc.append(cls["file_path"])
                candidates_text_parts.append(f"  - {name} [{' | '.join(loc)}]")
            print(f"   Found {len(matched)} classes by name")

    method_names = entities.get("method_names", [])
    if method_names:
        matched = toolkit.search_methods(method_names)
        if matched:
            candidates_text_parts.append("\nMETHODS FOUND BY NAME:")
            for m in matched:
                cls = m.get("class_name", "?")
                all_class_names.add(cls)
                layer = f" (layer={m['layer_type']})" if m.get("layer_type") else ""
                candidates_text_parts.append(
                    f"  - {cls}.{m.get('method_name', '?')}(){layer} in {m.get('file_path', '?')}"
                )
            print(f"   Found {len(matched)} methods by name")

    api_paths = entities.get("api_paths", [])
    for path in api_paths:
        endpoints = toolkit.find_api_endpoints(path)
        if endpoints:
            candidates_text_parts.append(f"\nAPI ENDPOINTS matching '{path}':")
            for ep in endpoints:
                cls = ep.get("handler_class", "?")
                all_class_names.add(cls)
                candidates_text_parts.append(
                    f"  - {ep.get('http_method', '?')} {ep.get('api_path', '?')} → "
                    f"{cls}.{ep.get('handler_method', '?')}() [{ep.get('layer', '?')}]"
                )
            print(f"   Found {len(endpoints)} API endpoints for '{path}'")

    keywords = entities.get("keywords", [])
    for kw in keywords[:3]:
        kw_results = toolkit.search_by_keyword(kw)
        if kw_results:
            candidates_text_parts.append(f"\nCLASSES matching keyword '{kw}':")
            for cls in kw_results[:5]:
                name = cls.get("name", "?")
                all_class_names.add(name)
                loc = []
                if cls.get("feature"):
                    loc.append(f"feature={cls['feature']}")
                if cls.get("layer_type"):
                    loc.append(f"layer={cls['layer_type']}")
                candidates_text_parts.append(f"  - {name} [{' | '.join(loc)}]")

    # API chain tracing — trace REST endpoints to full call chain
    for path in api_paths:
        api_chain = toolkit.trace_api_chain(path)
        if api_chain:
            candidates_text_parts.append(f"\nAPI CHAIN for '{path}':")
            for ac in api_chain[:10]:
                dc = ac.get("downstream_class", "?")
                if dc and dc != "?" and dc not in all_class_names:
                    all_class_names.add(dc)
                candidates_text_parts.append(
                    f"  {ac.get('controller_class', '?')}.{ac.get('controller_method', '?')}()"
                    f" → {dc}.{ac.get('downstream_method', '?')}()"
                    f" [{ac.get('downstream_layer', '?')}]"
                )
            print(f"   Found {len(api_chain)} API chain steps for '{path}'")

    all_class_names.discard(None)
    all_class_names.discard("")
    all_class_names.discard("?")

    # Interface implementor lookup — find concrete classes for interfaces
    for cls_name in list(all_class_names):
        if cls_name and cls_name.startswith("I") and cls_name[1:2].isupper():
            implementors = toolkit.find_implementors(cls_name)
            if implementors:
                candidates_text_parts.append(f"\nIMPLEMENTORS of {cls_name}:")
                for impl in implementors:
                    impl_name = impl.get("class_name", "?")
                    all_class_names.add(impl_name)
                    candidates_text_parts.append(
                        f"  - {impl_name} [{impl.get('layer_type', '?')}] {impl.get('file_path', '')}"
                    )

    # MULTI-STRATEGY FALLBACK when graph search finds nothing
    if not candidates_text_parts:
        print("   ⚠️ No graph candidates — trying multi-strategy fallback")

        # Strategy 1: Semantic search
        semantic_docs = toolkit.search_code(query, k=10)
        if semantic_docs:
            candidates_text_parts.append("SEMANTIC SEARCH RESULTS (fallback):")
            seen_classes = set()
            for doc in semantic_docs:
                cls = doc.metadata.get("class_name", "")
                fp = doc.metadata.get("relative_path", "")
                method = doc.metadata.get("method", "")
                if cls and cls not in seen_classes:
                    seen_classes.add(cls)
                    all_class_names.add(cls)
                    candidates_text_parts.append(
                        f"  - {cls}" + (f".{method}()" if method else "") + f" [{fp}]"
                    )

        # Strategy 2: Grep for key terms from the query
        if not candidates_text_parts:
            for kw in keywords[:5]:
                grep_results = toolkit.grep_code(kw, k=5)
                if grep_results:
                    candidates_text_parts.append(f"\nGREP RESULTS for '{kw}':")
                    seen_classes2 = set()
                    for doc in grep_results:
                        cls = doc.metadata.get("class_name", "")
                        fp = doc.metadata.get("relative_path", "")
                        if cls and cls not in seen_classes2:
                            seen_classes2.add(cls)
                            all_class_names.add(cls)
                            candidates_text_parts.append(f"  - {cls} [{fp}]")
                    if candidates_text_parts:
                        print(f"   Found candidates via grep for '{kw}'")

    candidates_text = "\n".join(candidates_text_parts)

    if not candidates_text.strip():
        print("   ❌ No candidates found at all")
        return {
            "candidate_locations": [],
            "graph_context": "",
            "guided_file_paths": []
        }

    prompt = HIERARCHICAL_LOCALIZER_PROMPT.format(
        query=query,
        symptom=plan.get("symptom", "unknown"),
        likely_layers=", ".join(plan.get("likely_layers", [])),
        likely_flow=plan.get("likely_flow", "unknown"),
        candidates=candidates_text
    )

    response = get_llm().invoke([{"role": "user", "content": prompt}])
    result = _parse_json_response(response.content)

    ranked = result.get("ranked_locations", [])
    if not ranked:
        logger.warning("Localizer returned no ranked locations, using all candidates")
        ranked = [{"file": "", "class": c, "method": "", "confidence": 0.5, "reason": "found in graph"}
                  for c in list(all_class_names)[:5]]

    from Config.settings import CONFIG
    max_candidates = CONFIG.get("max_candidate_locations", 5)
    ranked = ranked[:max_candidates]

    print(f"   📊 Ranked {len(ranked)} candidate locations:")
    for i, loc in enumerate(ranked):
        print(f"      {i+1}. {loc.get('class', '?')}"
              f".{loc.get('method', '?')}() "
              f"[conf={loc.get('confidence', 0):.0%}] — {loc.get('reason', '')[:60]}")

    guided_paths = list(toolkit.get_related_files(list(all_class_names)[:10], depth=1))

    return {
        "candidate_locations": ranked,
        "graph_context": candidates_text,
        "guided_file_paths": guided_paths
    }


# ==================== PHASE 3: EVIDENCE COLLECTOR ====================

def evidence_collector_node(state: AgentState, toolkit):
    """Phase 3: Collect code chunks, call chains, and related classes
    for the top candidate locations. ALSO traces across layers to find
    all files in the execution path (component → service → controller → repository)."""
    print("---📦 PHASE 3: EVIDENCE COLLECTOR (cross-layer)---")
    candidates = state.get("candidate_locations", [])
    current_round = state.get("investigation_round", 0)
    previous_evidence = state.get("code_evidence", "")
    previous_chains = state.get("call_chain_evidence", "")
    root_cause = state.get("root_cause", {})

    if root_cause and root_cause.get("needs_more_context"):
        additional = root_cause.get("additional_context_needed", [])
        if additional:
            print(f"   Round {current_round + 1}: Collecting additional context for: {additional}")
            extra_candidates = []
            for item in additional:
                cls_name = item.rsplit(".", 1)[0] if "." in item else item
                found = toolkit.search_classes([cls_name])
                for f in found:
                    extra_candidates.append({
                        "file": f.get("file_path", ""),
                        "class": f.get("name", cls_name),
                        "method": item.rsplit(".", 1)[1] if "." in item else "",
                        "confidence": 0.7,
                        "reason": "requested by root cause analyzer"
                    })
            candidates = extra_candidates + candidates

    all_evidence_parts = []
    all_chain_parts = []
    all_docs = []
    investigated_classes = set()

    if previous_evidence:
        all_evidence_parts.append(previous_evidence)
    if previous_chains:
        all_chain_parts.append(previous_chains)

    from Config.settings import CONFIG
    chunks_per_file = CONFIG.get("evidence_chunks_per_file", 8)

    # Step 1: Collect evidence for direct candidates
    for loc in candidates[:5]:
        cls_name = loc.get("class", "")
        method_name = loc.get("method", "")
        file_path = loc.get("file", "")

        if not cls_name and not file_path:
            continue
        if cls_name in investigated_classes:
            continue
        investigated_classes.add(cls_name)

        print(f"   📄 Collecting: {cls_name}"
              + (f".{method_name}()" if method_name else "")
              + (f" [{file_path}]" if file_path else ""))

        evidence = toolkit.collect_evidence_for_location(file_path, cls_name, method_name)
        evidence_text = toolkit.format_evidence_as_text(evidence)
        all_evidence_parts.append(evidence_text)

        for chunk in evidence.get("code_chunks", [])[:chunks_per_file]:
            all_docs.append(chunk)

        chain = evidence.get("call_chain", [])
        if chain:
            chain_text = toolkit.format_call_chain_as_text(chain)
            all_chain_parts.append(f"Call chain for {cls_name}.{method_name}():\n{chain_text}")

            # Step 2: CROSS-LAYER TRACING — follow call chain to related classes
            for c in chain:
                for target_cls in [c.get("from", "").split(".")[0], c.get("to", "").split(".")[0]]:
                    if (target_cls and target_cls != "?" and
                            target_cls not in investigated_classes and
                            len(investigated_classes) < 8):
                        investigated_classes.add(target_cls)
                        target_method = ""
                        if c.get("direction") == "outgoing":
                            target_method = c.get("to", "").split(".")[-1] if "." in c.get("to", "") else ""
                        else:
                            target_method = c.get("from", "").split(".")[-1] if "." in c.get("from", "") else ""

                        # Find the file for this cross-layer class
                        found = toolkit.search_classes([target_cls])
                        target_file = found[0].get("file_path", "") if found else ""
                        target_layer = found[0].get("layer_type", "") if found else ""

                        if target_file or target_cls:
                            print(f"   🔗 Cross-layer: {target_cls}"
                                  + (f".{target_method}()" if target_method else "")
                                  + (f" [{target_layer}]" if target_layer else ""))

                            cross_evidence = toolkit.collect_evidence_for_location(
                                target_file, target_cls, target_method
                            )
                            cross_text = toolkit.format_evidence_as_text(cross_evidence)
                            all_evidence_parts.append(cross_text)

                            for chunk in cross_evidence.get("code_chunks", [])[:chunks_per_file // 2]:
                                all_docs.append(chunk)

    code_evidence = "\n\n".join(all_evidence_parts)
    call_chain_evidence = "\n\n".join(all_chain_parts)

    print(f"   📊 Total: {len(investigated_classes)} classes investigated, "
          f"{len(all_docs)} code chunks, "
          f"{len(all_chain_parts)} call chains, "
          f"evidence: {len(code_evidence)} chars")

    return {
        "code_evidence": code_evidence,
        "call_chain_evidence": call_chain_evidence,
        "documents": all_docs,
        "investigation_round": current_round + 1,
    }


# ==================== PHASE 4: ROOT CAUSE ANALYZER ====================

def root_cause_analyzer_node(state: AgentState):
    """Phase 4: LLM analyzes the collected evidence to find the root cause.
    Now supports multi-file bugs: returns affected_files list, not just one location."""
    print("---🔬 PHASE 4: ROOT CAUSE ANALYZER (multi-file)---")
    query = state.get("original_query", "")
    plan = state.get("investigation_plan", {})
    code_evidence = state.get("code_evidence", "")
    call_chain_evidence = state.get("call_chain_evidence", "")
    round_num = state.get("investigation_round", 0)

    if not code_evidence:
        print("   ❌ No code evidence collected")
        return {
            "root_cause": {
                "root_cause_found": False,
                "root_cause": "No code evidence was found for the bug report",
                "needs_more_context": False,
                "confidence": 0,
                "affected_files": []
            }
        }

    max_evidence = 15000
    if len(code_evidence) > max_evidence:
        code_evidence = code_evidence[:max_evidence] + "\n\n... (evidence truncated)"

    prompt = ROOT_CAUSE_ANALYZER_PROMPT.format(
        query=query,
        symptom=plan.get("symptom", "unknown"),
        likely_flow=plan.get("likely_flow", "unknown"),
        code_evidence=code_evidence,
        call_chain_evidence=call_chain_evidence if call_chain_evidence else "(No call chain data)"
    )

    print(f"   Round {round_num}: Analyzing {len(code_evidence)} chars of evidence...")

    response = get_llm().invoke([{"role": "user", "content": prompt}])
    result = _parse_json_response(response.content)

    if not result:
        logger.warning("Root cause analyzer returned invalid JSON")
        result = {
            "root_cause_found": False,
            "root_cause": response.content[:500],
            "needs_more_context": False,
            "confidence": 30,
            "affected_files": []
        }

    # Backward compat: convert old single buggy_location to affected_files
    if "buggy_location" in result and "affected_files" not in result:
        loc = result["buggy_location"]
        result["affected_files"] = [{
            "file": loc.get("file", ""),
            "class": loc.get("class", ""),
            "method": loc.get("method", ""),
            "layer": loc.get("layer", ""),
            "issue": result.get("root_cause", ""),
            "fix_needed": ""
        }]

    found = result.get("root_cause_found", False)
    needs_more = result.get("needs_more_context", False)
    affected = result.get("affected_files", [])

    # Compute confidence from rubric (deterministic, not LLM-generated)
    eq = result.get("evidence_quality", {})
    if eq:
        rubric_score = sum([
            eq.get("exact_line_found", False),
            eq.get("code_quoted", False),
            eq.get("all_flow_files_found", False),
            eq.get("explains_all_symptoms", False),
            eq.get("fix_is_clear", False),
        ])
        confidence_map = {5: 95, 4: 88, 3: 78, 2: 65, 1: 50, 0: 30}
        confidence = confidence_map.get(rubric_score, 50)
        result["confidence"] = confidence
        print(f"   📊 Evidence rubric: {rubric_score}/5 → {confidence}%")
        print(f"      exact_line={eq.get('exact_line_found')}, code_quoted={eq.get('code_quoted')}, "
              f"all_files={eq.get('all_flow_files_found')}, explains_all={eq.get('explains_all_symptoms')}, "
              f"fix_clear={eq.get('fix_is_clear')}")
    else:
        confidence = result.get("confidence", 50)
        print(f"   📊 Confidence (LLM-provided): {confidence}%")

    if found:
        print(f"   ✅ Root cause FOUND (confidence={confidence}%)")
        print(f"   Cause: {result.get('root_cause', '?')[:150]}")
        print(f"   📁 Affected files: {len(affected)}")
        for i, af in enumerate(affected):
            layer_tag = f" [{af.get('layer', '?')}]" if af.get('layer') else ""
            print(f"      {i+1}. {af.get('class', '?')}.{af.get('method', '?')}(){layer_tag}"
                  f" — {af.get('issue', '')[:80]}")
        if result.get("execution_flow"):
            print(f"   Flow: {result['execution_flow'][:120]}")
    elif needs_more:
        additional = result.get("additional_context_needed", [])
        print(f"   🔄 Needs more context: {additional}")
    else:
        print(f"   ⚠️ Could not determine root cause (confidence={confidence}%)")

    return {"root_cause": result}


# ==================== PHASE 5: FIX GENERATOR ====================

def _extract_relevant_evidence(full_evidence: str, affected_files: list) -> str:
    """Extract only code evidence relevant to the affected files.
    Two-pass: first grab exact matches for affected files, then fill remaining
    budget with related sections. Ensures fix generator sees actual method bodies."""
    if not affected_files or not full_evidence:
        return full_evidence[:8000] if full_evidence else ""

    target_names = set()
    for af in affected_files:
        if af.get("class"):
            target_names.add(af["class"].lower())
        if af.get("method"):
            target_names.add(af["method"].lower())
        if af.get("file"):
            fname = af["file"].lower().rsplit("/", 1)[-1]
            target_names.add(fname.replace(".java", "").replace(".ts", ""))

    sections = full_evidence.split("\n\n")
    max_chars = 12000

    # Pass 1: sections that match affected file names/classes (high priority)
    primary = []
    primary_chars = 0
    secondary = []
    for section in sections:
        section_lower = section.lower()
        if any(name in section_lower for name in target_names):
            if primary_chars + len(section) < max_chars:
                primary.append(section)
                primary_chars += len(section)
        else:
            secondary.append(section)

    # Pass 2: fill remaining budget with related sections (call chains, imports)
    remaining = max_chars - primary_chars
    for section in secondary:
        if remaining <= 0:
            break
        if len(section) <= remaining:
            primary.append(section)
            remaining -= len(section)

    if not primary:
        return full_evidence[:8000]
    return "\n\n".join(primary)


def fix_generator_node(state: AgentState):
    """Phase 5: Generate the complete MULTI-FILE fix report.
    Token-optimized: only sends code for affected files, not full evidence."""
    print("---🔧 PHASE 5: FIX GENERATOR (multi-file)---")
    query = state.get("original_query", "")
    root_cause = state.get("root_cause", {})
    code_evidence = state.get("code_evidence", "")
    generation_attempts = state.get("generation_attempts", 0)

    rc_text = root_cause.get("root_cause", "Unknown")
    confidence = root_cause.get("confidence", 50)
    affected_files = root_cause.get("affected_files", [])
    execution_flow = root_cause.get("execution_flow", "")

    affected_lines = []
    for i, af in enumerate(affected_files):
        layer_tag = f" [{af.get('layer', '')}]" if af.get('layer') else ""
        affected_lines.append(
            f"  {i+1}. {af.get('class', '?')}.{af.get('method', '?')}(){layer_tag} "
            f"in {af.get('file', '?')}\n"
            f"     Issue: {af.get('issue', 'unknown')}\n"
            f"     Fix needed: {af.get('fix_needed', 'TBD')}"
        )
    affected_files_summary = "\n".join(affected_lines) if affected_lines else "(single file)"

    relevant_evidence = _extract_relevant_evidence(code_evidence, affected_files)
    saved = len(code_evidence) - len(relevant_evidence)
    if saved > 0:
        print(f"   💡 Token savings: {saved} chars trimmed from evidence ({saved * 100 // max(len(code_evidence), 1)}% reduction)")

    prompt = FIX_GENERATOR_PROMPT.format(
        root_cause=rc_text,
        execution_flow=execution_flow if execution_flow else "(not traced)",
        confidence=confidence,
        affected_files_summary=affected_files_summary,
        code_evidence=relevant_evidence,
        query=query,
    )

    print(f"   Generating fix (attempt {generation_attempts + 1})...")
    print(f"   Root cause: {rc_text[:100]}")
    print(f"   Affected files: {len(affected_files)}")
    for af in affected_files:
        print(f"      - {af.get('class', '?')}.{af.get('method', '?')}() [{af.get('layer', '?')}]")

    response = get_llm().invoke([{"role": "user", "content": prompt}])
    generation = response.content

    print(f"   Generated multi-file fix report ({len(generation)} chars)")

    return {
        "generation": generation,
        "generation_attempts": generation_attempts + 1
    }


# ==================== PHASE 6: FIX VERIFIER ====================

def fix_verifier_node(state: AgentState):
    """Phase 6: LLM verifies its own fix — catches hallucinated methods,
    missing files, and root cause mismatches before human review."""
    print("---✅ PHASE 6: FIX VERIFIER---")
    query = state.get("original_query", "")
    root_cause = state.get("root_cause", {})
    generation = state.get("generation", "")
    code_evidence = state.get("code_evidence", "")

    if not generation or len(generation) < 100:
        print("   ⚠️ No fix to verify, passing through")
        return {}

    rc_text = root_cause.get("root_cause", "Unknown")
    execution_flow = root_cause.get("execution_flow", "")

    evidence_for_verify = code_evidence[:8000] if len(code_evidence) > 8000 else code_evidence

    prompt = FIX_VERIFIER_PROMPT.format(
        query=query,
        root_cause=rc_text,
        execution_flow=execution_flow or "(not traced)",
        proposed_fix=generation[:3000],
        code_evidence=evidence_for_verify,
    )

    response = get_llm().invoke([{"role": "user", "content": prompt}])
    result = _parse_json_response(response.content)

    if not result:
        print("   ⚠️ Verifier returned invalid JSON — passing fix through")
        return {}

    verdict = result.get("verdict", "pass")
    issues = result.get("issues", [])
    hallucinated = result.get("hallucinated_methods", [])
    missing = result.get("missing_files", [])
    placeholder = result.get("placeholder_code", [])
    suggested_conf = result.get("suggested_confidence", 0)
    confidence_adj = result.get("confidence_adjustment", 0)

    print(f"   Verdict: {verdict.upper()}")
    if issues:
        for issue in issues[:3]:
            print(f"   ⚠️ Issue: {issue[:100]}")
    if hallucinated:
        print(f"   🚫 Hallucinated methods: {hallucinated}")
    if placeholder:
        print(f"   📋 Placeholder code found: {placeholder}")
    if missing:
        print(f"   📁 Missing files: {missing}")
    if suggested_conf:
        print(f"   📊 Suggested confidence: {suggested_conf}%")

    if verdict == "pass":
        print("   ✅ Fix verified — proceeding to developer review")
        return {}
    elif verdict == "regenerate":
        print("   🔄 Fix rejected by verifier — will regenerate")
        generation_attempts = state.get("generation_attempts", 0)
        if generation_attempts >= 2:
            print("   ⚠️ Max generation attempts — passing to developer anyway")
            return {}
        return {"generation": "", "generation_attempts": generation_attempts}
    else:
        hints = result.get("improved_fix_hints", "")
        if hints:
            print(f"   💡 Hint: {hints[:100]}")
        return {}


# ==================== SHARED NODES (kept from original) ====================

def memory_check_node(state: AgentState, memory):
    """Check agent memory for cached approved response."""
    print("---🧠 MEMORY CHECK---")
    query = state.get("original_query", "")

    cached = memory.get_cached_response(query)
    if cached:
        print(f"   ✅ CACHE HIT (similarity={cached['similarity']:.3f})")
        return {"memory_hit": True, "cached_response": cached["response"]}

    print("   ❌ No cache hit — running agentic pipeline")
    return {"memory_hit": False, "cached_response": None}


def human_review_node(state: AgentState):
    """HITL checkpoint — pauses workflow for developer review."""
    print("---👤 AWAITING DEVELOPER REVIEW---")
    final_report = state.get("generation", "")

    options = ("approved", "feedback")
    response = interrupt(options)

    return {"final_report": final_report, "human": response}


def finalize_node(state: AgentState, memory):
    """Save approved response to memory and finalize."""
    result = state.get("final_report", "")
    user_id = state.get("user_id", "anonymous")

    if not state.get("memory_hit", False):
        feedback_list = state.get("feedback_history", [])
        feedback_text = " | ".join(feedback_list) if feedback_list else None

        memory.add_success(
            user_id=user_id,
            query=state["original_query"],
            result=result if result else "",
            feedback_history=feedback_text
        )
        print("\n✅ Approved & saved to memory!")
        if feedback_text:
            print(f"   📝 Feedback history saved: {len(feedback_list)} rejection(s)")
    else:
        print("\n✅ Served from memory cache!")
    return {}


def end_not_relevant_node(state: AgentState):
    """End when investigation fails to find relevant code."""
    print("---❌ INVESTIGATION FAILED - END---")
    return {
        "final_report": NOT_RELEVANT_REPORT.format(
            transform_count=state.get("investigation_round", 0),
            original_query=state["original_query"],
            final_query=state["question"]
        )
    }
