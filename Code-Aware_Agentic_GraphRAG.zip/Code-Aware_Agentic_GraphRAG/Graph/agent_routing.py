"""
Routing logic for the Code-Aware Agentic GraphRAG workflow.
"""

from .state import AgentState
from Config.settings import CONFIG


def after_memory_check(state: AgentState):
    """Route after memory check: cache hit → finalize, miss → investigation."""
    if state.get("memory_hit", False):
        print("   → Memory cache HIT → SKIP pipeline")
        return "cache_hit"
    print("   → Memory cache MISS → Start investigation")
    return "cache_miss"


def after_root_cause_analysis(state: AgentState):
    """Route after root cause analysis:
    - root_cause_found → fix_generator
    - needs_more_context (and under round limit) → evidence_collector
    - otherwise → fix_generator (best effort)"""
    root_cause = state.get("root_cause", {})
    current_round = state.get("investigation_round", 0)
    max_rounds = CONFIG.get("max_investigation_rounds", 3)

    found = root_cause.get("root_cause_found", False)
    needs_more = root_cause.get("needs_more_context", False)

    if found:
        print(f"   → Root cause FOUND → Generate fix")
        return "fix"

    if needs_more and current_round < max_rounds:
        additional = root_cause.get("additional_context_needed", [])
        print(f"   → Needs more context (round {current_round}/{max_rounds}) → Collect more evidence")
        print(f"     Looking for: {additional}")
        return "more_evidence"

    print(f"   → Best effort (round {current_round}/{max_rounds}) → Generate fix with available evidence")
    return "fix"


def after_human_review(state: AgentState):
    """Route after developer review: approve or send back with feedback."""
    human_value = state.get("human", "")
    feedback_count = state.get("feedback_count", 0)
    max_feedback = CONFIG.get("max_feedback_attempts", 3)

    if human_value == "approved":
        print("   → APPROVED → Finalize")
        return "finalize"

    if feedback_count >= max_feedback:
        print(f"   → Max feedback attempts ({max_feedback}) reached → Finalize anyway")
        return "finalize"

    print(f"   → FEEDBACK (attempt {feedback_count + 1}/{max_feedback}) → Re-investigate")
    return "reinvestigate"


def after_localization(state: AgentState):
    """Route after localization: found candidates → collect evidence, none → end."""
    candidates = state.get("candidate_locations", [])
    if not candidates:
        print("   → No candidates found → End")
        return "no_candidates"
    print(f"   → {len(candidates)} candidates → Collect evidence")
    return "has_candidates"


def should_skip_verification(state: AgentState) -> bool:
    """Skip Phase 6 (verifier) when rubric confidence is high enough."""
    root_cause = state.get("root_cause", {})
    eq = root_cause.get("evidence_quality", {})
    if not eq:
        return False
    rubric_score = sum([
        eq.get("exact_line_found", False),
        eq.get("code_quoted", False),
        eq.get("all_flow_files_found", False),
        eq.get("explains_all_symptoms", False),
        eq.get("fix_is_clear", False),
    ])
    return rubric_score >= 3


def after_fix_generation(state: AgentState):
    """Route after fix generation: skip verifier if confidence is high."""
    if should_skip_verification(state):
        confidence = state.get("root_cause", {}).get("confidence", 0)
        print(f"   → High confidence ({confidence}%) → Skip verifier → Developer review")
        return "skip_verify"
    print("   → Sending to verifier")
    return "verify"


def after_fix_verification(state: AgentState):
    """Route after fix verification: verified → developer_review, regenerate → fix_generator."""
    generation = state.get("generation", "")
    generation_attempts = state.get("generation_attempts", 0)

    if not generation or len(generation) < 100:
        if generation_attempts >= 2:
            print("   → Max generation attempts — passing empty fix to review")
            return "verified"
        print("   → Fix rejected by verifier → Regenerate")
        return "regenerate"

    print("   → Fix verified → Developer review")
    return "verified"
