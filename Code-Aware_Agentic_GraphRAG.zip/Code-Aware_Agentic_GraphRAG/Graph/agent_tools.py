"""
Agent tools for the agentic code-aware pipeline.
These are NOT LangChain tools — they are plain functions called by LangGraph nodes
to query the knowledge graph and vector store during investigation.

All methods are wrapped with error handling to prevent pipeline crashes.
"""

import logging
from typing import List, Dict, Optional, Set

logger = logging.getLogger(__name__)


def _safe(default=None):
    """Decorator that catches exceptions in tool methods and returns a default."""
    def decorator(fn):
        def wrapper(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except Exception as e:
                logger.error(f"Tool {fn.__name__} failed: {e}")
                return default() if callable(default) else default
        wrapper.__name__ = fn.__name__
        return wrapper
    return decorator


class AgentToolkit:
    """Provides investigation tools to LangGraph nodes."""

    def __init__(self, graph_store, vector_store):
        self.graph = graph_store
        self.vector = vector_store

    # ==================== GRAPH TOOLS ====================

    @_safe(default=list)
    def search_classes(self, names: List[str]) -> List[Dict]:
        """Find classes by name with full hierarchy context."""
        if not names:
            return []
        return self.graph.find_classes_by_name(names)

    @_safe(default=list)
    def search_methods(self, names: List[str]) -> List[Dict]:
        """Find methods by name with class and layer context."""
        if not names:
            return []
        return self.graph.find_methods_by_name(names)

    @_safe(default=list)
    def search_by_keyword(self, keyword: str) -> List[Dict]:
        """Broad search for classes matching a keyword."""
        if not keyword:
            return []
        return self.graph.search_classes_by_keyword(keyword)

    @_safe(default=list)
    def get_call_chain(self, class_name: str, method_name: str,
                       direction: str = "both", depth: int = 2) -> List[Dict]:
        """Trace call chain from/to a method."""
        return self.graph.get_call_chain(class_name, method_name, direction, depth)

    @_safe(default=dict)
    def get_class_context(self, class_name: str) -> Dict:
        """Get full context: hierarchy, imports, methods, callers, callees."""
        return self.graph.get_class_context(class_name)

    @_safe(default=dict)
    def get_feature_tree(self, feature_name: str) -> Dict:
        """Get directory tree for a microservice/module."""
        return self.graph.get_feature_tree(feature_name)

    @_safe(default=list)
    def get_all_features(self) -> List[Dict]:
        """List all microservices and modules."""
        return self.graph.get_all_features()

    @_safe(default=list)
    def search_by_layer(self, feature_name: str, layer_type: str) -> List[Dict]:
        """Find classes in a specific architecture layer of a feature."""
        return self.graph.search_by_layer(feature_name, layer_type)

    @_safe(default=list)
    def find_api_endpoints(self, pattern: str) -> List[Dict]:
        """Find REST API endpoints matching a URL pattern."""
        if not pattern:
            return []
        return self.graph.find_api_endpoints_by_pattern(pattern)

    @_safe(default=set)
    def get_related_files(self, class_names: List[str], depth: int = 2) -> Set[str]:
        """Get file paths related to given classes."""
        if not class_names:
            return set()
        return self.graph.get_related_file_paths(class_names, depth)

    # ==================== NEW GRAPH TOOLS (agentic RCA) ====================

    @_safe(default=list)
    def find_implementors(self, interface_name: str) -> List[Dict]:
        """Find all classes that implement a given interface.
        Critical for Spring DI chains where @Autowired points to an interface."""
        if not interface_name:
            return []
        return self.graph.find_implementors(interface_name)

    @_safe(default=dict)
    def find_class_dependencies(self, class_name: str) -> Dict:
        """Get full dependency map: what this class imports/uses and what uses it."""
        if not class_name:
            return {}
        return self.graph.find_class_dependencies(class_name)

    @_safe(default=list)
    def trace_api_chain(self, api_pattern: str) -> List[Dict]:
        """Trace REST API → Controller → Service → Repository chain.
        The key tool for cross-layer bug tracing."""
        if not api_pattern:
            return []
        return self.graph.trace_api_to_repository(api_pattern)

    # ==================== VECTOR TOOLS ====================

    @_safe(default=list)
    def search_code(self, query: str, k: int = 10) -> List:
        """Semantic search in code chunks."""
        return self.vector.search(query, k=k)

    @_safe(default=list)
    def search_in_files(self, query: str, file_paths: List[str], k: int = 10) -> List:
        """Search within specific files only."""
        if not file_paths:
            return []
        return self.vector.search_by_paths(query, file_paths, k=k)

    @_safe(default=list)
    def grep_code(self, pattern: str, k: int = 10) -> List:
        """Text search (LIKE) in code chunks."""
        if not pattern:
            return []
        return self.vector.grep_code(pattern, k=k)

    @_safe(default=list)
    def get_file_code(self, relative_path: str) -> List:
        """Get all code chunks from a specific file."""
        if not relative_path:
            return []
        return self.vector.get_file_chunks(relative_path)

    # ==================== NEW VECTOR TOOLS (metadata search) ====================

    @_safe(default=list)
    def search_by_class_name(self, class_name: str, k: int = 10) -> List:
        """Find all code chunks belonging to a class (exact metadata match).
        Faster and more precise than semantic search when you know the class name."""
        if not class_name:
            return []
        return self.vector.search_by_class(class_name, k=k)

    @_safe(default=list)
    def search_by_method_name(self, class_name: str, method_name: str) -> List:
        """Find the exact code chunk for a class.method() (metadata match)."""
        if not class_name or not method_name:
            return []
        return self.vector.search_by_method(class_name, method_name)

    @_safe(default=str)
    def get_full_file(self, relative_path: str) -> str:
        """Get complete file content by reconstructing from all chunks.
        Use for top suspect files to ensure the LLM sees ALL code."""
        if not relative_path:
            return ""
        return self.vector.get_full_file(relative_path)

    @_safe(default=list)
    def search_in_microservice(self, microservice: str, query: str, k: int = 10) -> List:
        """Search within a specific microservice/module."""
        if not microservice:
            return []
        return self.vector.search_by_microservice(microservice, query, k=k)

    # ==================== MULTI-STRATEGY SEARCH ====================

    def multi_strategy_search(self, class_name: str, method_name: str = "",
                               query: str = "", file_path: str = "") -> Dict:
        """Try MULTIPLE search strategies to find the right code. Returns combined results.
        Strategy order: 1) metadata exact match, 2) graph search, 3) semantic, 4) grep.
        This is the KEY improvement over single-strategy search."""
        results = {
            "code_chunks": [],
            "class_context": {},
            "call_chain": [],
            "strategies_used": [],
            "file_path": file_path,
        }
        seen_content = set()

        def add_chunks(chunks, strategy_name):
            added = 0
            for chunk in (chunks or []):
                content_key = chunk.page_content[:200] if hasattr(chunk, 'page_content') else str(chunk)[:200]
                if content_key not in seen_content:
                    seen_content.add(content_key)
                    results["code_chunks"].append(chunk)
                    added += 1
            if added > 0:
                results["strategies_used"].append(f"{strategy_name}({added})")

        # Strategy 1: Metadata exact match (fastest, most precise)
        if class_name:
            if method_name:
                chunks = self.search_by_method_name(class_name, method_name)
                add_chunks(chunks, "metadata_method")
            chunks = self.search_by_class_name(class_name, k=8)
            add_chunks(chunks, "metadata_class")

        # Strategy 2: File path retrieval
        if file_path and not results["code_chunks"]:
            chunks = self.get_file_code(file_path)
            add_chunks(chunks, "file_chunks")

        # Strategy 3: Graph context
        if class_name:
            results["class_context"] = self.get_class_context(class_name)
            if method_name:
                results["call_chain"] = self.get_call_chain(class_name, method_name)

        # Strategy 4: Semantic search (if metadata didn't find enough)
        if len(results["code_chunks"]) < 3 and (query or class_name):
            search_query = query or f"{class_name} {method_name}".strip()
            if file_path:
                chunks = self.search_in_files(search_query, [file_path], k=5)
            else:
                chunks = self.search_code(search_query, k=5)
            add_chunks(chunks, "semantic")

        # Strategy 5: Grep fallback (if semantic also weak)
        if len(results["code_chunks"]) < 2 and class_name:
            chunks = self.grep_code(class_name, k=5)
            add_chunks(chunks, "grep")

        return results

    # ==================== COMPOSITE TOOLS ====================

    def collect_evidence_for_location(self, file_path: str, class_name: str,
                                      method_name: str = None) -> Dict:
        """Collect all available evidence for a code location using multi-strategy search.
        Returns: {code_chunks, class_context, call_chain, related_files}"""
        evidence = {
            "file_path": file_path,
            "class_name": class_name,
            "method_name": method_name,
            "code_chunks": [],
            "class_context": {},
            "call_chain": [],
            "related_code": []
        }

        # Use multi-strategy search
        search_result = self.multi_strategy_search(
            class_name=class_name or "",
            method_name=method_name or "",
            file_path=file_path or ""
        )
        evidence["code_chunks"] = search_result["code_chunks"]
        evidence["class_context"] = search_result["class_context"]
        evidence["call_chain"] = search_result["call_chain"]

        if search_result["strategies_used"]:
            logger.info(f"Evidence for {class_name}: {', '.join(search_result['strategies_used'])}")

        # Get related code from dependencies
        if class_name:
            related_paths = self.get_related_files([class_name], depth=1)
            if file_path:
                related_paths.discard(file_path)
            for rp in list(related_paths)[:3]:
                related_chunks = self.get_file_code(rp)
                if related_chunks:
                    evidence["related_code"].append({
                        "file": rp,
                        "chunks": related_chunks[:2]
                    })

        return evidence

    def format_evidence_as_text(self, evidence: Dict) -> str:
        """Format collected evidence into readable text for the LLM."""
        parts = []

        fp = evidence.get("file_path", "unknown")
        cls = evidence.get("class_name", "unknown")
        method = evidence.get("method_name", "")
        parts.append(f"=== EVIDENCE: {cls}" + (f".{method}()" if method else "") + f" [{fp}] ===")

        chunks = evidence.get("code_chunks", [])
        if chunks:
            parts.append("\n--- SOURCE CODE ---")
            for chunk in chunks:
                m = chunk.metadata
                tag = m.get("method", m.get("class_name", ""))
                if tag:
                    parts.append(f"\n[{tag}]")
                parts.append(chunk.page_content)
        else:
            parts.append("\n(No source code chunks found for this file)")

        ctx = evidence.get("class_context", {})
        if ctx.get("qualified_name"):
            parts.append("\n--- CLASS CONTEXT ---")
            if ctx.get("feature"):
                parts.append(f"Feature: {ctx['feature']}")
            if ctx.get("layer_type"):
                parts.append(f"Layer: {ctx['layer_type']}")
            if ctx.get("extends"):
                parts.append(f"Extends: {ctx['extends']}")
            if ctx.get("implements"):
                parts.append(f"Implements: {', '.join(ctx['implements'])}")
            if ctx.get("methods"):
                method_names = [m["name"] for m in ctx["methods"][:20]]
                parts.append(f"Methods: {', '.join(method_names)}")
            if ctx.get("calls_out"):
                parts.append("Calls out:")
                for c in ctx["calls_out"][:10]:
                    target = f"{c.get('to_class', '?')}.{c['to_method']}()"
                    layer = f" [{c['to_layer']}]" if c.get("to_layer") else ""
                    parts.append(f"  → {target}{layer}")
            if ctx.get("called_by"):
                parts.append("Called by:")
                for c in ctx["called_by"][:10]:
                    caller = f"{c.get('from_class', '?')}.{c['from_method']}()"
                    layer = f" [{c['from_layer']}]" if c.get("from_layer") else ""
                    parts.append(f"  ← {caller}{layer}")

        chain = evidence.get("call_chain", [])
        if chain:
            parts.append("\n--- CALL CHAIN ---")
            for c in chain:
                arrow = "→" if c["direction"] == "outgoing" else "←"
                fl = f" [{c['from_layer']}]" if c.get("from_layer") else ""
                tl = f" [{c['to_layer']}]" if c.get("to_layer") else ""
                parts.append(f"  {c['from']}(){fl} {arrow} {c['to']}(){tl}")

        related = evidence.get("related_code", [])
        if related:
            parts.append("\n--- RELATED CODE ---")
            for r in related:
                parts.append(f"\n[File: {r['file']}]")
                for chunk in r.get("chunks", []):
                    tag = chunk.metadata.get("method", chunk.metadata.get("class_name", ""))
                    if tag:
                        parts.append(f"[{tag}]")
                    content = chunk.page_content
                    if len(content) > 600:
                        content = content[:600] + "\n... (truncated)"
                    parts.append(content)

        return "\n".join(parts)

    def format_call_chain_as_text(self, chains: List[Dict]) -> str:
        """Format call chain results into readable text."""
        if not chains:
            return "(No call chain found)"
        lines = []
        for c in chains:
            arrow = "→" if c["direction"] == "outgoing" else "←"
            fl = f" [{c['from_layer']}]" if c.get("from_layer") else ""
            tl = f" [{c['to_layer']}]" if c.get("to_layer") else ""
            lines.append(f"{c['from']}(){fl} {arrow} {c['to']}(){tl}")
        return "\n".join(lines)
