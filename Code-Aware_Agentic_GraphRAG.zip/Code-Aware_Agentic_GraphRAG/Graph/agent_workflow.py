"""
Code-Aware Agentic GraphRAG Workflow.

Structured 6-phase pipeline (Agentless-style):
  START → memory_check → investigation_planner → hierarchical_localizer →
  evidence_collector → root_cause_analyzer → (loop or fix_generator) →
  fix_verifier → developer_review → finalize → END

LangGraph controls flow. LLM makes decisions at each step.
Works with 24B models (devstral) on Ollama.
"""

from functools import partial
import sqlite3
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver
from Config.settings import CONFIG

from .state import AgentState
from .agent_tools import AgentToolkit
from .agent_nodes import (
    memory_check_node,
    investigation_planner_node,
    hierarchical_localizer_node,
    evidence_collector_node,
    root_cause_analyzer_node,
    fix_generator_node,
    fix_verifier_node,
    human_review_node,
    finalize_node,
    end_not_relevant_node,
)
from .agent_routing import (
    after_memory_check,
    after_root_cause_analysis,
    after_human_review,
    after_localization,
    after_fix_generation,
    after_fix_verification,
)


def cache_hit_node(state: AgentState):
    """Set final_report from cached response when memory cache hits."""
    return {
        "final_report": state.get("cached_response", ""),
        "generation": state.get("cached_response", "")
    }


def feedback_capture_node(state: AgentState):
    """Reset investigation state for re-investigation with feedback.
    feedback_count and feedback_history are already updated by the /resume endpoint."""
    human_value = state.get("human", "")

    return {
        "feedback": human_value if human_value != "approved" else None,
        "investigation_plan": None,
        "candidate_locations": [],
        "code_evidence": "",
        "call_chain_evidence": "",
        "root_cause": None,
        "generation": "",
        "investigation_round": 0,
    }


def create_agentic_workflow(vector_store, memory, graph_store):
    """Create the Code-Aware Agentic GraphRAG workflow.

    Flow:
        START → memory_check → (cache_hit → finalize → END)
                             → investigation_planner → localizer → (no candidates → end)
                             → evidence_collector → root_cause_analyzer
                               → (needs more → evidence_collector) [max 3 rounds]
                               → fix_generator → fix_verifier
                                 → (verified → developer_review)
                                 → (regenerate → fix_generator) [max 2 attempts]
                               → developer_review
                                 → (approved → finalize → END)
                                 → (feedback → feedback_capture → investigation_planner)
    """
    toolkit = AgentToolkit(graph_store, vector_store)

    memory_check = partial(memory_check_node, memory=memory)
    localizer = partial(hierarchical_localizer_node, toolkit=toolkit)
    evidence_collector = partial(evidence_collector_node, toolkit=toolkit)
    finalize = partial(finalize_node, memory=memory)

    workflow = StateGraph(AgentState)

    # === Nodes ===
    workflow.add_node("memory_check", memory_check)
    workflow.add_node("cache_hit", cache_hit_node)
    workflow.add_node("investigation_planner", investigation_planner_node)
    workflow.add_node("hierarchical_localizer", localizer)
    workflow.add_node("evidence_collector", evidence_collector)
    workflow.add_node("root_cause_analyzer", root_cause_analyzer_node)
    workflow.add_node("fix_generator", fix_generator_node)
    workflow.add_node("fix_verifier", fix_verifier_node)
    workflow.add_node("developer_review", human_review_node)
    workflow.add_node("feedback_capture", feedback_capture_node)
    workflow.add_node("finalize", finalize)
    workflow.add_node("end_not_relevant", end_not_relevant_node)

    # === Edges ===

    # START → memory_check
    workflow.add_edge(START, "memory_check")

    # memory_check → cache_hit or investigation_planner
    workflow.add_conditional_edges(
        "memory_check",
        after_memory_check,
        {
            "cache_hit": "cache_hit",
            "cache_miss": "investigation_planner"
        }
    )

    # cache_hit → finalize
    workflow.add_edge("cache_hit", "finalize")

    # investigation_planner → hierarchical_localizer
    workflow.add_edge("investigation_planner", "hierarchical_localizer")

    # hierarchical_localizer → evidence_collector or end
    workflow.add_conditional_edges(
        "hierarchical_localizer",
        after_localization,
        {
            "has_candidates": "evidence_collector",
            "no_candidates": "end_not_relevant"
        }
    )

    # evidence_collector → root_cause_analyzer
    workflow.add_edge("evidence_collector", "root_cause_analyzer")

    # root_cause_analyzer → fix or more_evidence (loop)
    workflow.add_conditional_edges(
        "root_cause_analyzer",
        after_root_cause_analysis,
        {
            "fix": "fix_generator",
            "more_evidence": "evidence_collector"
        }
    )

    # fix_generator → verify or skip_verify (conditional)
    workflow.add_conditional_edges(
        "fix_generator",
        after_fix_generation,
        {
            "verify": "fix_verifier",
            "skip_verify": "developer_review",
        }
    )

    # fix_verifier → developer_review or regenerate
    workflow.add_conditional_edges(
        "fix_verifier",
        after_fix_verification,
        {
            "verified": "developer_review",
            "regenerate": "fix_generator"
        }
    )

    # developer_review → finalize, reinvestigate
    workflow.add_conditional_edges(
        "developer_review",
        after_human_review,
        {
            "finalize": "finalize",
            "reinvestigate": "feedback_capture"
        }
    )

    # feedback_capture → investigation_planner (re-run with feedback)
    workflow.add_edge("feedback_capture", "investigation_planner")

    # Terminal nodes
    workflow.add_edge("finalize", END)
    workflow.add_edge("end_not_relevant", END)

    # === Compile with checkpointer ===
    conn = sqlite3.connect(CONFIG['checkpoint_db'], check_same_thread=False)
    checkpointer = SqliteSaver(conn)

    graph = workflow.compile(checkpointer=checkpointer)

    return graph, checkpointer
