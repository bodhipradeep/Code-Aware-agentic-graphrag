from typing import TypedDict, List, Optional, Set
from langchain_core.documents import Document


class AgentState(TypedDict):
    """State for Adaptive Code-Aware Agentic GraphRAG workflow."""

    # Query info
    original_query: str
    question: str
    user_id: str

    # Phase 1: Investigation Plan
    investigation_plan: Optional[dict]

    # Phase 2: Localization
    candidate_locations: list

    # Phase 3: Evidence Collection
    investigation_round: int
    code_evidence: str
    call_chain_evidence: str

    # Phase 4: Root Cause
    root_cause: Optional[dict]

    # Retrieved documents
    documents: List[Document]

    # Graph context
    graph_context: str
    guided_file_paths: List[str]

    # Generation
    generation: str
    generation_attempts: int
    query_transform_count: int

    # HITL state
    human: Optional[str]
    feedback: Optional[str]
    feedback_count: int
    feedback_history: List[str]

    # Memory state
    memory_hit: bool
    cached_response: Optional[str]

    # Final output
    final_report: Optional[str]
