"""
Builds the code knowledge graph in Neo4j from AST-parsed chunks.
Called during the ingestion pipeline — after AST chunking, before/alongside vector indexing.

Schema:
  Feature → Directory → SubDirectory → File → Class → Method
  Plus cross-cutting: CALLS, IMPORTS, EXTENDS, IMPLEMENTS, HANDLES
"""

import re
import logging
from typing import List, Dict, Optional
from langchain_core.documents import Document

logger = logging.getLogger(__name__)


# ==================== LAYER TYPE DETECTION ====================

JAVA_LAYERS = {
    "controller": "controller", "controllers": "controller",
    "rest": "controller", "api": "controller", "resource": "controller",
    "service": "service", "services": "service",
    "impl": "implementation",
    "repository": "repository", "repositories": "repository",
    "dao": "repository",
    "model": "model", "models": "model", "entity": "model", "entities": "model",
    "domain": "model",
    "dto": "dto", "dtos": "dto", "request": "dto", "response": "dto",
    "vo": "dto",
    "config": "config", "configuration": "config",
    "util": "utility", "utils": "utility", "helper": "utility", "helpers": "utility",
    "common": "utility",
    "filter": "filter", "filters": "filter",
    "interceptor": "interceptor", "interceptors": "interceptor",
    "exception": "exception", "exceptions": "exception",
    "mapper": "mapper", "mappers": "mapper", "converter": "mapper",
    "scheduler": "scheduler", "job": "scheduler", "jobs": "scheduler",
    "client": "client", "clients": "client", "feign": "client",
    "security": "security", "auth": "security",
    "aspect": "aspect", "aop": "aspect",
    "event": "event", "events": "event",
    "listener": "listener", "listeners": "listener",
    "producer": "messaging", "consumer": "messaging", "kafka": "messaging",
    "migration": "migration",
    "validator": "validation", "validation": "validation",
}

ANGULAR_LAYERS = {
    "components": "component", "component": "component",
    "services": "service", "service": "service",
    "guards": "guard", "guard": "guard",
    "interceptors": "interceptor", "interceptor": "interceptor",
    "pipes": "pipe", "pipe": "pipe",
    "directives": "directive", "directive": "directive",
    "modules": "module", "module": "module",
    "pages": "page", "page": "page",
    "shared": "shared",
    "layouts": "layout", "layout": "layout",
    "models": "model", "model": "model",
    "interfaces": "interface", "interface": "interface",
    "enums": "enum",
    "store": "state-management", "state": "state-management",
    "resolvers": "resolver", "resolver": "resolver",
    "account": "feature", "auth": "feature",
    "dashboard": "page",
    "admin": "feature",
}


JAVA_ANNOTATION_LAYERS = {
    "@RestController": "controller", "@Controller": "controller",
    "@Service": "service",
    "@Repository": "repository",
    "@Component": "component",
    "@Configuration": "config",
    "@ControllerAdvice": "exception",
    "@Aspect": "aspect",
    "@FeignClient": "client",
}

ANGULAR_DECORATOR_LAYERS = {
    "@Component": "component",
    "@Injectable": "service",
    "@Pipe": "pipe",
    "@Directive": "directive",
    "@NgModule": "module",
}


def _detect_layer_from_annotations(source_text: str, language: str) -> Optional[str]:
    """Detect layer type from Spring annotations or Angular decorators.
    This is MORE ACCURATE than directory-based detection."""
    if not source_text:
        return None
    if language == "java":
        for annotation, layer in JAVA_ANNOTATION_LAYERS.items():
            if annotation in source_text:
                return layer
    else:
        for decorator, layer in ANGULAR_DECORATOR_LAYERS.items():
            if decorator in source_text:
                return layer
    return None


def _detect_layer_type(dir_name: str) -> Optional[str]:
    lower = dir_name.lower()
    return JAVA_LAYERS.get(lower) or ANGULAR_LAYERS.get(lower)


# ==================== DIRECTORY HIERARCHY BUILDERS ====================

JAVA_PACKAGE_SKIP = {"com", "fci", "ccm", "org", "net", "io", "in", "java"}


def _build_java_hierarchy(dir_parts: List[str], graph_store) -> Optional[str]:
    """Build Feature → Dir → SubDir chain for a Java file path.
    Pattern: {microservice}/src/main/java/{com/fci/service/}{layer_dirs}/File.java
    Returns the path of the deepest directory."""

    feature_name = dir_parts[0]
    graph_store.merge_feature(feature_name, "microservice")

    if "java" in dir_parts:
        java_idx = dir_parts.index("java")
        after_java = dir_parts[java_idx + 1:]

        feat_lower = feature_name.lower()
        feat_variants = {
            feat_lower,
            feat_lower.replace("service", ""),
            feat_lower.replace("-service", ""),
            feat_lower.replace("_service", ""),
            feat_lower.replace("-", ""),
            feat_lower.replace("_", ""),
        }
        skip_set = JAVA_PACKAGE_SKIP | feat_variants

        meaningful = []
        skipping = True
        for p in after_java:
            if skipping and p.lower() in skip_set:
                continue
            skipping = False
            meaningful.append(p)
    else:
        meaningful = dir_parts[1:]

    if not meaningful:
        dir_path = "/".join(dir_parts)
        graph_store.merge_directory(
            feature_name, dir_path, _detect_layer_type(feature_name),
            feature_name=feature_name
        )
        return dir_path

    base_path = "/".join(dir_parts[:len(dir_parts) - len(meaningful)])
    prev_path = None

    for i, dir_name in enumerate(meaningful):
        current_path = base_path + "/" + "/".join(meaningful[:i + 1])
        layer = _detect_layer_type(dir_name)

        graph_store.merge_directory(
            name=dir_name,
            path=current_path,
            layer_type=layer,
            parent_path=prev_path if i > 0 else None,
            feature_name=feature_name if i == 0 else None,
        )
        prev_path = current_path

    return prev_path


def _build_angular_hierarchy(dir_parts: List[str], graph_store) -> Optional[str]:
    """Build Feature → Dir → SubDir chain for an Angular file path.
    Pattern: src/app/{feature}/{sub_dirs...}/file.ts
    Returns the path of the deepest directory."""

    if len(dir_parts) >= 2 and dir_parts[0] == "src" and dir_parts[1] == "app":
        after_app = dir_parts[2:]
        base_path = "src/app"
    else:
        after_app = dir_parts
        base_path = ""

    if not after_app:
        dir_path = "/".join(dir_parts) if dir_parts else None
        return dir_path

    feature_name = after_app[0]
    graph_store.merge_feature(feature_name, "frontend-module")

    prev_path = None

    for i, dir_name in enumerate(after_app):
        current_path = (base_path + "/" + "/".join(after_app[:i + 1])) if base_path else "/".join(after_app[:i + 1])
        layer = _detect_layer_type(dir_name)

        graph_store.merge_directory(
            name=dir_name,
            path=current_path,
            layer_type=layer,
            parent_path=prev_path if i > 0 else None,
            feature_name=feature_name if i == 0 else None,
        )
        prev_path = current_path

    return prev_path


def _build_directory_hierarchy(relative_path: str, language: str, graph_store) -> Optional[str]:
    """Parse a file path and create the full Feature → Directory hierarchy.
    Returns the path of the immediate parent directory (for linking the File node)."""

    parts = relative_path.replace("\\", "/").split("/")
    dir_parts = parts[:-1]

    if not dir_parts:
        return None

    if language == "java":
        return _build_java_hierarchy(dir_parts, graph_store)
    return _build_angular_hierarchy(dir_parts, graph_store)


# ==================== CALL / IMPORT EXTRACTION ====================

def _extract_java_calls(method_content: str, class_name: str) -> List[Dict]:
    """Extract method calls from Java method body."""
    calls = []
    seen = set()

    pattern = re.compile(r'(\w+)\.(\w+)\s*\(')
    for match in pattern.finditer(method_content):
        obj, method = match.group(1), match.group(2)
        if obj in ("this", "super"):
            key = (class_name, method)
            if key not in seen:
                seen.add(key)
                calls.append({"to_class": class_name, "to_method": method})
        elif obj[0].isupper():
            key = (obj, method)
            if key not in seen:
                seen.add(key)
                calls.append({"to_class": obj, "to_method": method})
        elif obj not in ("System", "Arrays", "Collections", "Objects", "String",
                         "Integer", "Long", "Boolean", "Math", "Optional",
                         "log", "logger", "LOG"):
            key = (None, method)
            if key not in seen:
                seen.add(key)
                calls.append({"to_class": None, "to_method": method})

    return calls


def _extract_ts_calls(method_content: str, class_name: str) -> List[Dict]:
    """Extract method calls from TypeScript method body."""
    calls = []
    seen = set()

    pattern = re.compile(r'this\.(\w+)\.(\w+)\s*\(')
    for match in pattern.finditer(method_content):
        service, method = match.group(1), match.group(2)
        if service not in ("router", "route", "fb", "el", "nativeElement"):
            key = (service, method)
            if key not in seen:
                seen.add(key)
                calls.append({"to_class": service, "to_method": method})

    pattern2 = re.compile(r'this\.(\w+)\s*\(')
    for match in pattern2.finditer(method_content):
        method = match.group(1)
        if (class_name, method) not in seen:
            seen.add((class_name, method))
            calls.append({"to_class": class_name, "to_method": method})

    return calls


def _extract_java_extends_implements(source_text: str, class_name: str) -> Dict:
    """Extract extends and implements from Java class declaration."""
    result = {"extends": None, "implements": []}

    pattern = re.compile(
        r'class\s+' + re.escape(class_name) + r'\s+'
        r'(?:extends\s+(\w+)\s*)?'
        r'(?:implements\s+([\w\s,]+))?'
        r'\s*\{',
        re.MULTILINE
    )
    match = pattern.search(source_text)
    if match:
        if match.group(1):
            result["extends"] = match.group(1).strip()
        if match.group(2):
            result["implements"] = [i.strip() for i in match.group(2).split(",") if i.strip()]
    return result


def _extract_java_imports(source_text: str) -> List[str]:
    """Extract imported class names from Java source."""
    imports = []
    for match in re.finditer(r'import\s+[\w.]+\.(\w+)\s*;', source_text):
        cls = match.group(1)
        if cls[0].isupper() and cls not in (
            "List", "Map", "Set", "HashMap", "ArrayList", "HashSet",
            "Optional", "Stream", "Collectors",
            "Override", "Autowired", "Service", "Component", "Repository",
            "Controller", "RestController", "RequestMapping", "Entity",
            "Getter", "Setter", "Data", "Builder", "NoArgsConstructor",
            "AllArgsConstructor", "Slf4j", "Log4j2",
            "Test", "Before", "After", "BeforeEach",
            "String", "Integer", "Long", "Boolean", "Object", "Exception",
            "IOException", "RuntimeException", "Serializable",
        ):
            imports.append(cls)
    return imports


def _extract_ts_imports(source_text: str) -> List[str]:
    """Extract imported class/service names from TypeScript source."""
    imports = []
    for match in re.finditer(r'import\s*\{([^}]+)\}\s*from\s*[\'"]([^\'"]+)[\'"]', source_text):
        names_part = match.group(1)
        from_path = match.group(2)
        if from_path.startswith('.') or from_path.startswith('@app'):
            for name in names_part.split(','):
                name = name.strip()
                if name and name[0].isupper() and name not in (
                    "Component", "Injectable", "OnInit", "OnDestroy",
                    "Input", "Output", "EventEmitter", "NgModule",
                    "ViewChild", "ElementRef", "TemplateRef",
                    "Observable", "Subject", "BehaviorSubject",
                    "Subscription", "Pipe", "PipeTransform",
                    "ActivatedRoute", "Router", "FormBuilder", "FormGroup",
                    "HttpClient", "HttpHeaders",
                ):
                    imports.append(name)
    return imports


def _extract_autowired_types(source_text: str) -> List[str]:
    """Extract @Autowired or constructor-injected field types from Java source.
    These represent DI dependencies that should become IMPORTS edges."""
    types = []
    for match in re.finditer(r'@Autowired\s+(?:private\s+)?(\w+)\s+\w+', source_text):
        types.append(match.group(1))
    for match in re.finditer(r'(?:private|final)\s+(?:final\s+)?(\w+)\s+\w+[;,)]', source_text):
        type_name = match.group(1)
        if type_name[0].isupper() and type_name not in (
            "String", "Integer", "Long", "Boolean", "List", "Map", "Set",
            "Optional", "Object", "Logger", "Date", "BigDecimal",
        ):
            types.append(type_name)
    return list(set(types))


def _extract_api_endpoints(method_content: str, annotations: str = "") -> List[Dict]:
    """Extract REST API endpoints from Java annotations."""
    endpoints = []
    combined = annotations + "\n" + method_content
    patterns = [
        (r'@GetMapping\s*\(\s*["\']([^"\']+)', "GET"),
        (r'@PostMapping\s*\(\s*["\']([^"\']+)', "POST"),
        (r'@PutMapping\s*\(\s*["\']([^"\']+)', "PUT"),
        (r'@DeleteMapping\s*\(\s*["\']([^"\']+)', "DELETE"),
        (r'@PatchMapping\s*\(\s*["\']([^"\']+)', "PATCH"),
        (r'@RequestMapping\s*\([^)]*value\s*=\s*["\']([^"\']+)', "REQUEST"),
    ]
    for pattern, http_method in patterns:
        for match in re.finditer(pattern, combined):
            endpoints.append({"path": match.group(1), "method": http_method})
    return endpoints


# ==================== MAIN BUILD FUNCTION ====================

def build_graph_from_chunks(chunks: List[Document], graph_store, source_texts: Dict[str, str] = None):
    """Build the knowledge graph from AST-parsed chunks.

    Creates the full hierarchy:
      Feature → Directory → SubDirectory → File → Class → Method
    Plus cross-cutting relationships: IMPORTS, CALLS, EXTENDS, IMPLEMENTS, HANDLES

    Args:
        chunks: Document objects from ast_chunker (with metadata)
        graph_store: CodeGraphStore instance
        source_texts: Optional {relative_path: full_source_text} for deeper analysis
    """
    source_texts = source_texts or {}

    files = {}
    for chunk in chunks:
        meta = chunk.metadata
        rpath = meta.get("relative_path", "")
        if rpath not in files:
            files[rpath] = {"chunks": [], "meta": meta}
        files[rpath]["chunks"].append(chunk)

    stats = {"features": set(), "directories": 0, "files": 0,
             "classes": 0, "methods": 0, "calls": 0}

    for rpath, file_data in files.items():
        meta = file_data["meta"]
        language = meta.get("language", "java")
        file_name = meta.get("file_name", "")

        # Build Feature → Directory hierarchy and get the leaf directory path
        dir_path = _build_directory_hierarchy(rpath, language, graph_store)

        # Create File node linked to its parent directory
        graph_store.merge_file(file_name, rpath, language, directory_path=dir_path)
        stats["files"] += 1

        class_name = meta.get("class_name", "")
        package = meta.get("package", "")

        if not class_name or class_name in ("UnknownClass",):
            continue

        qualified_name = f"{package}.{class_name}" if package else class_name
        source_text = source_texts.get(rpath, "")

        extends = None
        implements = []
        if language == "java" and source_text:
            ei = _extract_java_extends_implements(source_text, class_name)
            extends = ei["extends"]
            implements = ei["implements"]

        graph_store.merge_class(
            name=class_name,
            qualified_name=qualified_name,
            package=package,
            language=language,
            file_relative_path=rpath,
            extends=extends,
            implements=implements
        )
        stats["classes"] += 1

        if language == "java" and source_text:
            for imp_class in _extract_java_imports(source_text):
                graph_store.add_import(qualified_name, imp_class)
            for autowired_type in _extract_autowired_types(source_text):
                graph_store.add_import(qualified_name, autowired_type)
        elif language == "angular" and source_text:
            for imp_class in _extract_ts_imports(source_text):
                graph_store.add_import(qualified_name, imp_class)

        # Detect layer from annotations (more accurate than directory-based)
        annotation_layer = _detect_layer_from_annotations(source_text, language) if source_text else None
        if annotation_layer:
            graph_store._run("""
                MATCH (c:Class {qualified_name: $qn})
                SET c.layer_type = $layer
            """, {"qn": qualified_name, "layer": annotation_layer})
            # Also update the directory layer if it was unset
            graph_store._run("""
                MATCH (f:File {relative_path: $path})<-[:HAS_FILE]-(d:Directory)
                WHERE d.layer_type IS NULL
                SET d.layer_type = $layer
            """, {"path": rpath, "layer": annotation_layer})

        for chunk in file_data["chunks"]:
            cmeta = chunk.metadata
            if cmeta.get("chunk_type") not in ("method", "constructor"):
                continue

            method_name = cmeta.get("method", "")
            if not method_name:
                continue

            graph_store.merge_method(
                name=method_name,
                class_qualified_name=qualified_name,
                signature=cmeta.get("signature", ""),
                file_name=file_name,
                relative_path=rpath,
                start_line=cmeta.get("start_line"),
                end_line=cmeta.get("end_line"),
                language=language
            )
            stats["methods"] += 1

            method_qn = f"{qualified_name}.{method_name}"
            content = chunk.page_content
            if language == "java":
                calls = _extract_java_calls(content, class_name)
            else:
                calls = _extract_ts_calls(content, class_name)

            for call in calls:
                graph_store.add_call(method_qn, call["to_method"], call.get("to_class"))
                stats["calls"] += 1

            if language == "java":
                endpoints = _extract_api_endpoints(content)
                for ep in endpoints:
                    graph_store.add_api_endpoint(ep["path"], ep["method"], method_qn)

    logger.info(
        f"Graph built: {stats['files']} files, {stats['classes']} classes, "
        f"{stats['methods']} methods, {stats['calls']} calls"
    )
    return {
        "files": stats["files"],
        "classes": stats["classes"],
        "methods": stats["methods"],
        "calls": stats["calls"],
    }
