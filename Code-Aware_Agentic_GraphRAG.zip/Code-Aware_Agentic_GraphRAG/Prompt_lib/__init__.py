"""Prompt Library for Adaptive RAG."""

from .prompts import RAG_PROMPT, NOT_RELEVANT_REPORT

__all__ = [
    "RAG_PROMPT",
    "NOT_RELEVANT_REPORT"
]
