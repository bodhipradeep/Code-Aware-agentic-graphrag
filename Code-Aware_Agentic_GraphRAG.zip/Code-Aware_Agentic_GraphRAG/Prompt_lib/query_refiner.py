"""
Query Refinement for RAG Pipeline
Extracts focused technical queries from JIRA descriptions and error messages
Note: Log files are auto-processed to extract errors and file names
"""

ERROR_EXTRACTOR_PROMPT = """Extract the most critical error or exception from the log content below.

Include the file name and line number if present in the error.
Return ONLY the error in a single line. If multiple errors exist, return the most severe one.
If no error found, return: (none)

Log Content:
{log_content}

Extracted Error:"""


QUERY_REFINER_PROMPT = """Distill the bug info into a focused 1-2 sentence technical query for code search.

Rules:
- Skip navigation steps ("click Settings > Users > Add"). Focus on WHAT is broken.
- Keep class names, method names, file names, line numbers if mentioned.
- Prioritize specific errors/exceptions over vague descriptions.
- Return ONLY the query. No explanation, no notes, no preamble.

Examples:
Bug: "Steps: Click Settings > User Management > Add User. Enter invalid email. No error shown"
Error: (none)
→ User Management email validation missing error message for invalid email address

Bug: "Login fails when user enters credentials"
Error: "NullPointerException at UserService.getProfile()"
→ UserService getProfile method NullPointerException during login authentication

Bug: "Application crashes when generating reports"
Error: "ArrayIndexOutOfBoundsException at ReportGenerator.generatePDF(ReportGenerator.java:142)"
→ ReportGenerator.java generatePDF ArrayIndexOutOfBoundsException line 142

Now refine this:
Bug: {jira_description}
Error: {error_message}
→"""
