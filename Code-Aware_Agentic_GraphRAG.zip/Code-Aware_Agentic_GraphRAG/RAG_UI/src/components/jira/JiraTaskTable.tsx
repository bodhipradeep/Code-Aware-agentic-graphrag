import { useState, useMemo, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
  PaginationEllipsis,
} from "@/components/ui/pagination";
import { Search, ExternalLink, Sparkles, Bug, CheckCircle2, RefreshCw, AlertTriangle, Settings, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useJiraData, JiraTask } from "@/hooks/useJiraData";
import { Link } from "react-router-dom";

const TASKS_PER_PAGE = 50;

export type { JiraTask };

const typeConfig: Record<string, { variant: "bug" | "task" | "story" | "default"; icon: typeof Bug }> = {
  Bug: { variant: "bug", icon: Bug },
  Task: { variant: "task", icon: Sparkles },
  Story: { variant: "story", icon: Sparkles },
  Epic: { variant: "default", icon: Sparkles },
};

const priorityConfig: Record<string, string> = {
  Low: "text-muted-foreground",
  Medium: "text-warning",
  High: "text-warning",
  Critical: "text-destructive",
};

const statusConfig: Record<string, string> = {
  "To Do": "bg-muted text-muted-foreground",
  "In Progress": "bg-primary/20 text-primary",
  "Done": "bg-success/20 text-success",
};

interface JiraTaskTableProps {
  onSelectTask: (task: JiraTask) => void;
}

export function JiraTaskTable({ onSelectTask }: JiraTaskTableProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);

  const [typeFilter, setTypeFilter] = useState<string>("all");
  const { tasks, projects, selectedProject, changeProject, isLoading, error, isConnected, refreshTasks, refresh } = useJiraData();

  // Filter tasks based on search and filters - permanently filter for Bug type
  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      const matchesSearch = task.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
        task.key.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = typeFilter === "all" || task.type === typeFilter;
      const matchesStatus = statusFilter === "all" || task.status === statusFilter;
      return matchesSearch && matchesType && matchesStatus;
    });
  }, [tasks, searchQuery, typeFilter, statusFilter]);

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, typeFilter, statusFilter]);

  // Pagination calculations
  const totalPages = Math.ceil(filteredTasks.length / TASKS_PER_PAGE);
  const startIndex = (currentPage - 1) * TASKS_PER_PAGE;
  const endIndex = startIndex + TASKS_PER_PAGE;
  const paginatedTasks = filteredTasks.slice(startIndex, endIndex);

  // Generate page numbers to display
  const getPageNumbers = () => {
    const pages: (number | 'ellipsis')[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      pages.push(1);
      if (currentPage > 3) pages.push('ellipsis');
      for (let i = Math.max(2, currentPage - 1); i <= Math.min(totalPages - 1, currentPage + 1); i++) {
        pages.push(i);
      }
      if (currentPage < totalPages - 2) pages.push('ellipsis');
      pages.push(totalPages);
    }
    return pages;
  };

  if (isConnected === false) {
    return (
      <Alert className="bg-muted/50">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription className="flex items-center justify-between">
          <span>JIRA not configured. Set credentials in .env file (VITE_JIRA_BASE_URL, VITE_JIRA_EMAIL, VITE_JIRA_API_TOKEN).</span>
          <Button asChild variant="outline" size="sm">
            <Link to="/settings" className="gap-2">
              <Settings className="h-4 w-4" />
              Configure
            </Link>
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-bold tracking-tight">JIRA Board</h1>
          {projects.length > 0 && (
            <Select value={selectedProject || "all"} onValueChange={(val) => changeProject(val === "all" ? "" : val)}>
              <SelectTrigger className="h-8 w-[180px]">
                <SelectValue placeholder="All Projects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map((p) => (
                  <SelectItem key={p.key} value={p.key}>
                    {p.key} — {p.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <Button
            variant="outline"
            size="icon"
            onClick={() => refresh()}
            disabled={isLoading}
            title="Refresh tasks"
          >
            <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
          </Button>
        </div>

        <div className="relative w-64">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search tasks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="rounded-xl border border-border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50 hover:bg-muted/50">
              <TableHead className="w-28">Key</TableHead>
              <TableHead>Summary</TableHead>
              <TableHead className="w-32 p-0">
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="h-8 w-full border-0 bg-transparent font-medium text-muted-foreground hover:text-foreground focus:ring-0">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="Bug">Bug</SelectItem>
                    <SelectItem value="Task">Task</SelectItem>
                    <SelectItem value="Story">Story</SelectItem>
                    <SelectItem value="Epic">Epic</SelectItem>
                  </SelectContent>
                </Select>
              </TableHead>
              <TableHead className="w-36 p-0">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="h-8 w-full border-0 bg-transparent font-medium text-muted-foreground hover:text-foreground focus:ring-0">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="To Do">To Do</SelectItem>
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Done">Done</SelectItem>
                  </SelectContent>
                </Select>
              </TableHead>
              <TableHead className="w-24">Priority</TableHead>
              <TableHead className="w-36">Assignee</TableHead>
              <TableHead className="w-24 text-right">AI Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading && tasks.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-32 text-center">
                  <div className="flex items-center justify-center gap-2 text-muted-foreground">
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Loading tasks from JIRA...
                  </div>
                </TableCell>
              </TableRow>
            ) : paginatedTasks.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-32 text-center text-muted-foreground">
                  No tasks found
                </TableCell>
              </TableRow>
            ) : (
              paginatedTasks.map((task) => {
                const config = typeConfig[task.type] || typeConfig.Task;
                const TypeIcon = config.icon;
                return (
                  <TableRow
                    key={task.key}
                    className="cursor-pointer transition-colors hover:bg-accent/50"
                    onClick={() => onSelectTask(task)}
                  >
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-medium text-primary">{task.key}</span>
                        <ExternalLink className="h-3 w-3 text-muted-foreground" />
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="line-clamp-1">{task.summary}</span>
                    </TableCell>
                    <TableCell>
                      <Badge variant={config.variant} className="flex items-center gap-1 w-fit">
                        <TypeIcon className="h-3 w-3" />
                        {task.type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium", statusConfig[task.status] || statusConfig["To Do"])}>
                        {task.status}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={cn("text-sm font-medium", priorityConfig[task.priority] || priorityConfig.Medium)}>
                        {task.priority}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">{task.assignee}</span>
                    </TableCell>
                    <TableCell className="text-right">
                      {task.aiProcessed && (
                        <Badge variant="success" className="gap-1">
                          <CheckCircle2 className="h-3 w-3" />
                          Processed
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {filteredTasks.length > 0 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            Showing {startIndex + 1}-{Math.min(endIndex, filteredTasks.length)} of {filteredTasks.length} tasks
            {filteredTasks.length !== tasks.length && ` (filtered from ${tasks.length} total)`}
          </p>
          
          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    className={cn(currentPage === 1 && "pointer-events-none opacity-50")}
                  />
                </PaginationItem>
                
                {getPageNumbers().map((page, index) => (
                  <PaginationItem key={index}>
                    {page === 'ellipsis' ? (
                      <PaginationEllipsis />
                    ) : (
                      <PaginationLink
                        onClick={() => setCurrentPage(page)}
                        isActive={currentPage === page}
                      >
                        {page}
                      </PaginationLink>
                    )}
                  </PaginationItem>
                ))}
                
                <PaginationItem>
                  <PaginationNext 
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    className={cn(currentPage === totalPages && "pointer-events-none opacity-50")}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </div>
      )}
    </div>
  );
}
