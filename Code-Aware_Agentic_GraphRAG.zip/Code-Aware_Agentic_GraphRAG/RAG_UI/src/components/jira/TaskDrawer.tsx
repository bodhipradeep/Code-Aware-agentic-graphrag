import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Bug, ExternalLink, User, Tag, CheckCircle2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { JiraTask } from "./JiraTaskTable";

interface TaskDrawerProps {
  task: JiraTask | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function TaskDrawer({ task, open, onOpenChange }: TaskDrawerProps) {
  const navigate = useNavigate();

  if (!task) return null;

  const isBug = task.type === "Bug";

  const handleRunPipeline = () => {
    onOpenChange(false);
    navigate(`/bug-fixer?jira=${task.key}`);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
        <SheetHeader className="space-y-4">
          <div className="flex items-center gap-3">
            <Badge variant={isBug ? "bug" : "task"} className="gap-1">
              <Bug className="h-3 w-3" />
              {task.type}
            </Badge>
            <span className="font-mono text-sm text-muted-foreground">{task.key}</span>
            <Button variant="ghost" size="icon" className="h-6 w-6 ml-auto">
              <ExternalLink className="h-4 w-4" />
            </Button>
          </div>
          <SheetTitle className="text-xl text-left">{task.summary}</SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Status</p>
              <Badge variant="secondary">{task.status}</Badge>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Priority</p>
              <Badge variant={task.priority === "Critical" ? "destructive" : "secondary"}>
                {task.priority}
              </Badge>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <User className="h-3 w-3" /> Assignee
              </p>
              <p className="text-sm">{task.assignee}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Tag className="h-3 w-3" /> Labels
              </p>
              <p className="text-sm text-muted-foreground">backend, api</p>
            </div>
          </div>

          <Separator />

          <div className="space-y-2">
            <p className="text-sm font-medium">Description</p>
            <div className="rounded-lg bg-muted/50 p-4 text-sm text-muted-foreground">
              {task.description ? (
                <p className="whitespace-pre-wrap">{task.description}</p>
              ) : (
                <p className="italic">No description provided</p>
              )}
            </div>
          </div>

          <Separator />

          <div className="pt-4">
            <Button
              size="lg"
              variant="glow"
              className="w-full"
              onClick={() => handleRunPipeline()}
            >
              NEXT
            </Button>
          </div>

          {task.aiProcessed && (
            <div className="rounded-lg border border-success/30 bg-success/10 p-4">
              <div className="flex items-center gap-2 text-success">
                <CheckCircle2 className="h-4 w-4" />
                <p className="text-sm font-medium">AI Pipeline Completed</p>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                This task has been processed by AI. View results in Logs & History.
              </p>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
