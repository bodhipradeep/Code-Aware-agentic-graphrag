import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Copy, Check, ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "@/lib/utils";

interface CodeSnippetProps {
  code: string;
  language?: string;
  filename?: string;
  relevanceScore?: number;
  maxLines?: number;
}

export function CodeSnippet({ code, language = "java", filename, relevanceScore, maxLines = 10 }: CodeSnippetProps) {
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const lines = code.split("\n");
  const shouldTruncate = lines.length > maxLines;
  const displayCode = shouldTruncate && !expanded
    ? lines.slice(0, maxLines).join("\n") + "\n..."
    : code;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-lg border border-border overflow-hidden">
      {(filename || relevanceScore !== undefined) && (
        <div className="flex items-center justify-between border-b border-border bg-muted/50 px-4 py-2">
          <div className="flex items-center gap-3">
            {filename && (
              <span className="font-mono text-xs text-muted-foreground">{filename}</span>
            )}
            {relevanceScore !== undefined && (
              <span className={cn(
                "rounded-full px-2 py-0.5 text-xs font-medium",
                relevanceScore >= 80 ? "bg-success/20 text-success" :
                relevanceScore >= 60 ? "bg-warning/20 text-warning" :
                "bg-muted text-muted-foreground"
              )}>
                {relevanceScore}% match
              </span>
            )}
          </div>
          <Button variant="ghost" size="sm" className="h-7 gap-1.5" onClick={handleCopy}>
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5" />
                Copied
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" />
                Copy
              </>
            )}
          </Button>
        </div>
      )}
      <div className="relative">
        <pre className="overflow-x-auto bg-muted/30 p-4 font-mono text-sm">
          <code>{displayCode}</code>
        </pre>
        {shouldTruncate && (
          <Button
            variant="ghost"
            size="sm"
            className="absolute bottom-2 right-2 h-7 gap-1"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? (
              <>
                <ChevronUp className="h-3.5 w-3.5" />
                Show less
              </>
            ) : (
              <>
                <ChevronDown className="h-3.5 w-3.5" />
                Show more ({lines.length - maxLines} lines)
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}
