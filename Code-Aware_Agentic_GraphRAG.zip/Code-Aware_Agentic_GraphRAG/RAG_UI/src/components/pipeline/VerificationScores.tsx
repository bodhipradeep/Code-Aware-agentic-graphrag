import { cn } from "@/lib/utils";

interface Score {
  label: string;
  value: number;
  maxValue: number;
}

interface VerificationScoresProps {
  scores: Score[];
  className?: string;
}

export function VerificationScores({ scores, className }: VerificationScoresProps) {
  const getScoreColor = (percentage: number) => {
    if (percentage >= 80) return "bg-success";
    if (percentage >= 60) return "bg-warning";
    return "bg-destructive";
  };

  return (
    <div className={cn("space-y-4", className)}>
      {scores.map((score) => {
        const percentage = (score.value / score.maxValue) * 100;
        return (
          <div key={score.label} className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">{score.label}</span>
              <span className="text-muted-foreground">
                {score.value}/{score.maxValue}
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
              <div
                className={cn("h-full rounded-full transition-all duration-500", getScoreColor(percentage))}
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
