/**
 * Centralized application configuration.
 * Single source of truth for API URL and other settings.
 */

export const API_URL = import.meta.env.VITE_RAG_API_URL || 'http://localhost:8000';
