import { useState, useEffect, useCallback } from 'react';
import { 
  fetchJiraIssues, 
  fetchJiraProjects,
  getJiraProjectKeys,
  testJiraConnection,
  transformJiraIssue,
  JiraProject
} from '@/services/jiraApi';

export interface JiraTask {
  key: string;
  summary: string;
  type: 'Bug' | 'Task' | 'Story' | 'Epic';
  status: 'To Do' | 'In Progress' | 'Done';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  assignee: string;
  description?: string;
  aiProcessed?: boolean;
}

export function useJiraData() {
  const [tasks, setTasks] = useState<JiraTask[]>([]);
  const [projects, setProjects] = useState<JiraProject[]>([]);
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [isLoading, setIsLoading] = useState(true); // Start with loading true
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState<boolean | null>(null);

  // Internal function to check connection
  const doCheckConnection = useCallback(async () => {
    try {
      const result = await testJiraConnection();
      setIsConnected(result.success);
      if (!result.success) {
        setError(result.error || 'Connection failed');
      } else {
        setError(null);
      }
      return result.success;
    } catch (err: unknown) {
      setIsConnected(false);
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      return false;
    }
  }, []);

  // Internal function to fetch tasks
  const doFetchTasks = useCallback(async (projectKey?: string) => {
    try {
      const { issues } = await fetchJiraIssues(projectKey);
      const transformedTasks = issues.map(transformJiraIssue);
      setTasks(transformedTasks);
      setIsConnected(true);
      setError(null);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch tasks';
      setError(message);
      throw err;
    }
  }, []);

  const changeProject = useCallback(async (projectKey: string) => {
    setSelectedProject(projectKey);
    setIsLoading(true);
    setError(null);
    try {
      await doFetchTasks(projectKey || undefined);
    } catch {
      // Error already handled in doFetchTasks
    } finally {
      setIsLoading(false);
    }
  }, [doFetchTasks]);

  // Internal function to fetch projects
  const doFetchProjects = useCallback(async () => {
    try {
      const fetchedProjects = await fetchJiraProjects();
      setProjects(fetchedProjects);
    } catch (err) {
      console.error('Failed to fetch projects:', err);
    }
  }, []);

  // Public refresh tasks function
  const refreshTasks = useCallback(async (projectKey?: string) => {
    setIsLoading(true);
    setError(null);
    try {
      await doFetchTasks(projectKey);
    } catch {
      // Error already set in doFetchTasks
    } finally {
      setIsLoading(false);
    }
  }, [doFetchTasks]);

  // Public refresh projects function
  const refreshProjects = useCallback(async () => {
    await doFetchProjects();
  }, [doFetchProjects]);

  // Full refresh: check connection then fetch everything
  const refresh = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const connected = await doCheckConnection();
      if (connected) {
        const savedKeys = await getJiraProjectKeys();
        const firstKey = savedKeys ? savedKeys.split(',')[0]?.trim() : "";
        if (firstKey && !selectedProject) {
          setSelectedProject(firstKey);
        }
        const projectToUse = selectedProject || firstKey || undefined;
        await Promise.all([doFetchTasks(projectToUse), doFetchProjects()]);
      }
    } catch {
      // Errors handled by internal functions
    } finally {
      setIsLoading(false);
    }
  }, [doCheckConnection, doFetchTasks, doFetchProjects, selectedProject]);

  // Initial load
  useEffect(() => {
    refresh();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    tasks,
    projects,
    selectedProject,
    changeProject,
    isLoading,
    error,
    isConnected,
    refreshTasks,
    refreshProjects,
    refresh,
  };
}
