import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { PipelineProgress } from "@/components/pipeline/PipelineProgress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Sparkles, Play, CheckCircle2, XCircle, Copy, Download, Loader2, Terminal, FileCode, Brain, User, Tag, AlertCircle, Bug } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import ReactMarkdown from "react-markdown";
import { queryCode, resumeAnalysis, QueryResponse, ResumeResponse } from "@/services/ragApi";
import { fetchJiraIssue, transformJiraIssue } from "@/services/jiraApi";
import { useAuth } from "@/contexts/AuthContext";

// Pipeline steps matching backend workflow
const pipelineSteps = [
  { id: "retrieve", label: "RAG Context Retrieval", description: "Finding relevant code" },
  { id: "grade", label: "Grading Documents", description: "Filtering relevant snippets" },
  { id: "generate", label: "Code Generation", description: "AI generating implementation" },
  { id: "verify", label: "Verification", description: "Checking quality" },
  { id: "review", label: "Human Review", description: "Awaiting your approval" },
];

interface TaskDetails {
  key: string;
  summary: string;
  description: string | null;
  type: string;
  priority: string;
  status: string;
  assignee: string;
  labels?: string[];
}

const FeatureGenerator = () => {
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const jiraKey = searchParams.get("jira");
  
  // Task details (manual input or from URL param)
  const [taskDetails, setTaskDetails] = useState<TaskDetails | null>(null);
  const [isLoadingJira, setIsLoadingJira] = useState(false);
  const [featureQuery, setFeatureQuery] = useState("");
  const [contextHint, setContextHint] = useState("");
  const [fileHint, setFileHint] = useState("");
  
  // Pipeline state
  const [currentStep, setCurrentStep] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [pipelineStatus, setPipelineStatus] = useState<"idle" | "running" | "needs_review" | "approved" | "rejected" | "completed" | "error">("idle");
  
  // RAG API state
  const [threadId, setThreadId] = useState<string | null>(null);
  const [generatedAnswer, setGeneratedAnswer] = useState<string>("");
  const [queryTransforms, setQueryTransforms] = useState(0);
  const [workflowLogs, setWorkflowLogs] = useState<string[]>([]);
  
  // UI state
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [reviewedCode, setReviewedCode] = useState<string | null>(null);
  const [showRejectSection, setShowRejectSection] = useState(false);
  const [rejectFeedback, setRejectFeedback] = useState("");

  // If jiraKey is provided, fetch full JIRA details
  useEffect(() => {
    if (jiraKey) {
      const fetchDetails = async () => {
        setIsLoadingJira(true);
        try {
          const issue = await fetchJiraIssue(jiraKey);
          if (issue) {
            const transformed = transformJiraIssue(issue);
            setTaskDetails({
              key: transformed.key,
              summary: transformed.summary,
              description: transformed.description || null,
              type: transformed.type,
              priority: transformed.priority,
              status: transformed.status,
              assignee: transformed.assignee,
              labels: issue.fields.labels || [],
            });
            // Build a comprehensive query from JIRA details
            const queryParts: string[] = [];
            queryParts.push(`Feature ${jiraKey}: ${transformed.summary}`);
            if (transformed.description) {
              queryParts.push(`\n\nRequirements:\n${transformed.description}`);
            }
            setFeatureQuery(queryParts.join(""));
          } else {
            // Fallback if fetch fails
            setTaskDetails({
              key: jiraKey,
              summary: `Feature from JIRA: ${jiraKey}`,
              description: null,
              type: "Story",
              priority: "Medium",
              status: "To Do",
              assignee: "Unassigned",
            });
            setFeatureQuery(`Implement feature ${jiraKey}`);
          }
        } catch (error) {
          console.error("Failed to fetch JIRA issue:", error);
          setTaskDetails({
            key: jiraKey,
            summary: `Feature from JIRA: ${jiraKey}`,
            description: null,
            type: "Story",
            priority: "Medium",
            status: "To Do",
            assignee: "Unassigned",
          });
          setFeatureQuery(`Implement feature ${jiraKey}`);
        } finally {
          setIsLoadingJira(false);
        }
      };
      fetchDetails();
    }
  }, [jiraKey]);

  // Start the RAG pipeline
  const handleStartPipeline = async () => {
    const query = featureQuery.trim();
    if (!query) {
      toast({
        title: "Query required",
        description: "Please enter a feature description or requirements",
        variant: "destructive",
      });
      return;
    }

    setCurrentStep(0);
    setIsRunning(true);
    setPipelineStatus("running");
    setGeneratedAnswer("");
    setWorkflowLogs([]);
    setShowRejectSection(false);
    setRejectFeedback("");

    try {
      // Step 1: Retrieval
      setCurrentStep(0);
      setWorkflowLogs(prev => [...prev, `📚 Querying: ${query}`]);
      
      const response: QueryResponse = await queryCode({
        query: query,
        user_id: user.employeeId,
        jira_key: taskDetails?.key,
        error: contextHint || undefined,
        file_hint: fileHint || undefined,
      });

      setThreadId(response.thread_id);
      setQueryTransforms(response.query_transforms);
      
      // Add logs from response
      if (response.logs) {
        setWorkflowLogs(prev => [...prev, ...response.logs!]);
      }

      // Handle cache hit immediately — no need to step through pipeline
      if (response.status === "cache_hit") {
        setCurrentStep(4);
        setPipelineStatus("completed");
        setGeneratedAnswer(response.answer || "Generation complete");
        setWorkflowLogs(prev => [...prev, "⚡ Result served from memory cache"]);
        return;
      }

      // Progress through steps based on response
      setCurrentStep(1); // Grading
      await new Promise(r => setTimeout(r, 500));
      setCurrentStep(2); // Generating
      await new Promise(r => setTimeout(r, 500));
      setCurrentStep(3); // Verification
      await new Promise(r => setTimeout(r, 500));

      if (response.status === "needs_review") {
        setCurrentStep(4); // Human Review
        setPipelineStatus("needs_review");
        setGeneratedAnswer(response.answer || "No answer generated");
        setWorkflowLogs(prev => [...prev, "👤 Awaiting human review..."]);
      } else if (response.status === "completed") {
        setCurrentStep(4);
        setPipelineStatus("completed");
        setGeneratedAnswer(response.answer || "Generation complete");
        setWorkflowLogs(prev => [...prev, "✅ Workflow completed (no HITL needed)"]);
      }

    } catch (error) {
      console.error("Pipeline error:", error);
      setPipelineStatus("error");
      setWorkflowLogs(prev => [...prev, `❌ Error: ${error instanceof Error ? error.message : 'Unknown error'}`]);
      toast({
        title: "Pipeline Error",
        description: error instanceof Error ? error.message : "Failed to run pipeline",
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
    }
  };

  // Approve the generation
  const handleConfirmApproval = async () => {
    if (!threadId) return;

    setShowApprovalModal(false);
    setIsRunning(true);
    setWorkflowLogs(prev => [...prev, "✅ Approving generation..."]);

    try {
      const response: ResumeResponse = await resumeAnalysis({
        thread_id: threadId,
        human: "approved",
        user_id: user.employeeId,
        jira_key: taskDetails?.key,
      });

      setPipelineStatus("approved");
      setGeneratedAnswer(response.answer);
      
      if (response.logs) {
        setWorkflowLogs(prev => [...prev, ...response.logs!]);
      }
      setWorkflowLogs(prev => [...prev, "✅ Feature approved and saved!"]);

      toast({
        title: "Approved successfully!",
        description: "The feature code has been approved and saved.",
      });

    } catch (error) {
      console.error("Approval error:", error);
      toast({
        title: "Approval Failed",
        description: error instanceof Error ? error.message : "Failed to approve",
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
    }
  };

  // Reject and provide feedback
  const handleSubmitFeedback = async () => {
    if (!threadId || !rejectFeedback.trim()) return;

    setShowRejectSection(false);
    setPipelineStatus("rejected");
    setIsRunning(true);
    setWorkflowLogs(prev => [...prev, `🔄 Re-generating with feedback: ${rejectFeedback}`]);

    try {
      const response: ResumeResponse = await resumeAnalysis({
        thread_id: threadId,
        human: "feedback",
        feedback: rejectFeedback,
        user_id: user.employeeId,
        jira_key: taskDetails?.key,
      });

      if (response.logs) {
        setWorkflowLogs(prev => [...prev, ...response.logs!]);
      }

      if (response.status === "reanalyzed") {
        setPipelineStatus("needs_review");
        setGeneratedAnswer(response.answer);
        setWorkflowLogs(prev => [...prev, `🔄 Retry attempt ${response.attempt}/3 complete`]);
        
        toast({
          title: "Re-generation complete",
          description: `Attempt ${response.attempt}/3 - Please review the new code`,
        });
      } else if (response.status === "max_attempts") {
        setPipelineStatus("completed");
        setGeneratedAnswer(response.answer);
        setWorkflowLogs(prev => [...prev, "⚠️ Maximum retry attempts reached"]);
        
        toast({
          title: "Max attempts reached",
          description: "The pipeline has reached maximum feedback iterations",
          variant: "destructive",
        });
      }

      setRejectFeedback("");

    } catch (error) {
      console.error("Feedback error:", error);
      setPipelineStatus("error");
      toast({
        title: "Feedback Failed",
        description: error instanceof Error ? error.message : "Failed to submit feedback",
        variant: "destructive",
      });
    } finally {
      setIsRunning(false);
    }
  };

  const handleCopyAnswer = () => {
    navigator.clipboard.writeText(generatedAnswer);
    toast({
      title: "Copied!",
      description: "Code copied to clipboard",
    });
  };

  const handleDownloadAnswer = () => {
    const blob = new Blob([generatedAnswer], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `feature-${threadId || 'generation'}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({
      title: "Downloaded!",
      description: "Feature code saved as markdown",
    });
  };

  const showDecisionButtons = pipelineStatus === "needs_review" && !showRejectSection && !isRunning;

  return (
    <Layout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Sparkles className="h-5 w-5" />
              </div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight">Feature Generation Pipeline</h1>
                <p className="text-muted-foreground">Generate production-ready code using RAG</p>
              </div>
            </div>
          </div>
          {threadId && (
            <Badge variant="outline" className="font-mono">
              Thread: {threadId}
            </Badge>
          )}
        </div>

        {/* JIRA Task Details Card */}
        {jiraKey && (
          <Card className="border-primary/30 bg-primary/5">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  JIRA Task Details
                </CardTitle>
                {taskDetails && (
                  <Badge variant={taskDetails.type === "Bug" ? "bug" : taskDetails.type === "Story" ? "story" : "task"}>
                    {taskDetails.type}
                  </Badge>
                )}
              </div>
              {taskDetails && (
                <CardDescription className="font-mono">
                  {taskDetails.key}
                </CardDescription>
              )}
            </CardHeader>
            <CardContent>
              {isLoadingJira ? (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Loading JIRA details...
                </div>
              ) : taskDetails ? (
                <div className="space-y-4">
                  {/* Summary */}
                  <div>
                    <h3 className="text-lg font-semibold">{taskDetails.summary}</h3>
                  </div>

                  {/* Meta Info Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Status</p>
                      <Badge variant="secondary">{taskDetails.status}</Badge>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Priority</p>
                      <Badge variant={taskDetails.priority === "Critical" || taskDetails.priority === "High" ? "destructive" : "secondary"}>
                        {taskDetails.priority}
                      </Badge>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <User className="h-3 w-3" /> Assignee
                      </p>
                      <p className="text-sm">{taskDetails.assignee}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Tag className="h-3 w-3" /> Labels
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {taskDetails.labels && taskDetails.labels.length > 0 
                          ? taskDetails.labels.join(", ") 
                          : "No labels"}
                      </p>
                    </div>
                  </div>

                  <Separator />

                  {/* Description */}
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Description</p>
                    <div className="rounded-lg bg-muted/50 p-4 text-sm">
                      {taskDetails.description ? (
                        <pre className="whitespace-pre-wrap font-sans">{taskDetails.description}</pre>
                      ) : (
                        <p className="text-muted-foreground italic">No description provided</p>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <AlertCircle className="h-4 w-4" />
                  Failed to load JIRA details
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Query Input Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Feature Requirements
            </CardTitle>
            <CardDescription>
              {jiraKey ? "Requirements auto-populated from JIRA. You can edit before generating." : "Describe the feature you want to implement"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="query">Feature Description / Requirements *</Label>
              <Textarea
                id="query"
                placeholder={jiraKey ? "Loading JIRA details..." : "e.g., Implement JWT authentication for the REST API with refresh token support..."}
                value={featureQuery}
                onChange={(e) => setFeatureQuery(e.target.value)}
                rows={6}
                disabled={isRunning || isLoadingJira}
              />
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="context">Additional Context (optional)</Label>
                <Input
                  id="context"
                  placeholder="e.g., Use Spring Security, follow existing patterns"
                  value={contextHint}
                  onChange={(e) => setContextHint(e.target.value)}
                  disabled={isRunning}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="file">Reference File (optional)</Label>
                <Input
                  id="file"
                  placeholder="e.g., AuthController.java"
                  value={fileHint}
                  onChange={(e) => setFileHint(e.target.value)}
                  disabled={isRunning}
                />
              </div>
            </div>
            <Button 
              size="lg" 
              variant="glow" 
              onClick={handleStartPipeline} 
              className="gap-2"
              disabled={isRunning || isLoadingJira || !featureQuery.trim()}
            >
              {isRunning ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Play className="h-5 w-5" />
                  Generate Feature
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <div className="grid gap-6 lg:grid-cols-4">
          {/* Pipeline Progress Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Pipeline Progress</CardTitle>
                {queryTransforms > 0 && (
                  <CardDescription>
                    Query transforms: {queryTransforms}
                  </CardDescription>
                )}
              </CardHeader>
              <CardContent>
                <PipelineProgress steps={pipelineSteps} currentStep={currentStep} />
              </CardContent>
            </Card>

            {/* Workflow Logs */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Terminal className="h-4 w-4" />
                  Logs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-48">
                  {workflowLogs.length > 0 ? (
                    <div className="space-y-1 font-mono text-xs">
                      {workflowLogs.map((log, i) => (
                        <p key={i} className="text-muted-foreground">{log}</p>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground text-sm">No logs yet. Start the pipeline to see progress.</p>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Generated Code Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileCode className="h-5 w-5 text-primary" />
                  Generated Code
                </CardTitle>
                <CardDescription>
                  AI-generated feature implementation
                </CardDescription>
              </CardHeader>
              <CardContent>
                {generatedAnswer ? (
                  <div className="space-y-4">
                    <div className="rounded-lg border border-border overflow-hidden">
                      <div className="flex items-center justify-between border-b border-border bg-muted/50 px-4 py-2">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">Generated Code</span>
                          <Badge variant={pipelineStatus === "approved" ? "success" : pipelineStatus === "needs_review" ? "secondary" : "default"}>
                            {pipelineStatus === "needs_review" ? "Needs Review" : 
                             pipelineStatus === "approved" ? "Approved" :
                             pipelineStatus === "completed" ? "Completed" : pipelineStatus}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm" onClick={handleCopyAnswer} className="gap-1.5 h-8">
                            <Copy className="h-4 w-4" />
                            Copy
                          </Button>
                          <Button variant="ghost" size="sm" onClick={handleDownloadAnswer} className="gap-1.5 h-8">
                            <Download className="h-4 w-4" />
                            Download
                          </Button>
                        </div>
                      </div>
                      <ScrollArea className="h-[800px] p-4">
                        <div className="prose prose-sm prose-invert max-w-none
                          prose-headings:text-foreground prose-headings:font-semibold prose-headings:mt-4 prose-headings:mb-2
                          prose-p:text-muted-foreground prose-p:my-1.5 prose-p:leading-relaxed
                          prose-strong:text-foreground
                          prose-code:text-primary prose-code:bg-muted prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-xs prose-code:before:content-none prose-code:after:content-none
                          prose-pre:bg-muted/50 prose-pre:border prose-pre:border-border prose-pre:rounded-lg prose-pre:my-3
                          prose-li:text-muted-foreground prose-li:my-0.5
                          prose-ul:my-2 prose-ol:my-2
                          prose-hr:border-border prose-hr:my-4
                          prose-a:text-primary prose-a:no-underline hover:prose-a:underline">
                          <ReactMarkdown>{generatedAnswer}</ReactMarkdown>
                        </div>
                      </ScrollArea>
                    </div>

                    {/* Decision Actions */}
                    {showDecisionButtons && (
                      <div className="flex gap-3 pt-2">
                        <Button variant="success" size="lg" className="gap-2" onClick={() => setShowApprovalModal(true)}>
                          <CheckCircle2 className="h-4 w-4" />
                          Approve Code
                        </Button>
                        <Button variant="destructive" size="lg" className="gap-2" onClick={() => setShowRejectSection(true)}>
                          <XCircle className="h-4 w-4" />
                          Request Changes
                        </Button>
                      </div>
                    )}

                    {/* Inline Rejection Section */}
                    <div
                      className={cn(
                        "overflow-hidden transition-all duration-300 ease-in-out",
                        showRejectSection ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0"
                      )}
                    >
                      <div className="rounded-lg border border-border bg-muted/30 p-4 mt-4 space-y-4">
                        <div>
                          <h4 className="font-semibold text-base">Request Changes</h4>
                          <p className="text-sm text-muted-foreground">
                            Explain what changes you need. The AI will regenerate with your feedback.
                          </p>
                        </div>
                        <Textarea
                          placeholder="e.g., Add input validation, use async/await pattern, include unit tests..."
                          value={rejectFeedback}
                          onChange={(e) => setRejectFeedback(e.target.value)}
                          rows={4}
                          className="resize-none"
                        />
                        <div className="flex gap-3">
                          <Button
                            variant="default"
                            onClick={handleSubmitFeedback}
                            disabled={!rejectFeedback.trim() || isRunning}
                          >
                            {isRunning ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                            Submit Feedback
                          </Button>
                          <Button variant="outline" onClick={() => setShowRejectSection(false)}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Status Badges */}
                    {pipelineStatus === "approved" && (
                      <div className="flex items-center gap-2 p-4 rounded-lg bg-success/10 border border-success/30">
                        <CheckCircle2 className="h-5 w-5 text-success" />
                        <span className="font-medium text-success">Feature Approved & Saved</span>
                      </div>
                    )}
                    {pipelineStatus === "error" && (
                      <div className="flex items-center gap-2 p-4 rounded-lg bg-destructive/10 border border-destructive/30">
                        <XCircle className="h-5 w-5 text-destructive" />
                        <span className="font-medium text-destructive">Pipeline Error</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-40 text-muted-foreground">
                    {isRunning ? (
                      <>
                        <Loader2 className="h-8 w-8 animate-spin mb-2" />
                        <p>Generating feature code...</p>
                      </>
                    ) : (
                      <p>Enter feature requirements above and click "Generate Feature" to start</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Approval Confirmation Modal */}
      <Dialog open={showApprovalModal} onOpenChange={setShowApprovalModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Approval</DialogTitle>
            <DialogDescription>
              Have you reviewed the generated code and are you sure you want to approve it?
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label className="text-sm font-medium">Did you review the code?</Label>
            <RadioGroup
              value={reviewedCode ?? ""}
              onValueChange={setReviewedCode}
              className="mt-3 space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="yes" id="review-yes" />
                <Label htmlFor="review-yes" className="font-normal cursor-pointer">Yes, I reviewed it</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="no" id="review-no" />
                <Label htmlFor="review-no" className="font-normal cursor-pointer">No, not yet</Label>
              </div>
            </RadioGroup>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowApprovalModal(false)}>
              Cancel
            </Button>
            <Button
              variant="success"
              onClick={handleConfirmApproval}
              disabled={reviewedCode !== "yes" || isRunning}
            >
              {isRunning ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Confirm Approval
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default FeatureGenerator;
