import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { JiraTaskTable, JiraTask } from "@/components/jira/JiraTaskTable";
import { TaskDrawer } from "@/components/jira/TaskDrawer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Bug, Sparkles, BookOpen, Settings } from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

const Index = () => {
  const [selectedTask, setSelectedTask] = useState<JiraTask | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const { user } = useAuth();

  const handleSelectTask = (task: JiraTask) => {
    setSelectedTask(task);
    setDrawerOpen(true);
  };

  return (
    <Layout>
      {/* JIRA Tasks Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-semibold">Your JIRA Tasks</h2>
        </div>
        <JiraTaskTable onSelectTask={handleSelectTask} />
      </section>

      {/* Task Drawer */}
      <TaskDrawer
        task={selectedTask}
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
      />
    </Layout>
  );
};

export default Index;
