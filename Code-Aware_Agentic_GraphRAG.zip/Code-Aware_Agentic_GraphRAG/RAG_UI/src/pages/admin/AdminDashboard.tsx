import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import {
  Activity,
  CheckCircle2,
  XCircle,
  Clock,
  Zap,
  Bug,
  Sparkles,
  Database,
  Link2,
  TrendingUp,
  AlertTriangle,
  Search,
  ChevronDown,
  ChevronUp,
  FileText,
} from "lucide-react";
import { API_URL } from "@/config";

const statusConfig = {
  healthy: { color: "bg-success", label: "Healthy", icon: CheckCircle2 },
  degraded: { color: "bg-warning", label: "Degraded", icon: AlertTriangle },
  paused: { color: "bg-destructive", label: "Paused", icon: XCircle },
};

const activityStatusConfig = {
  completed: { color: "success", label: "Completed" },
  in_progress: { color: "default", label: "In Progress" },
  needs_review: { color: "warning", label: "Needs Review" },
  reanalyzed: { color: "default", label: "Reanalyzed" },
  failed: { color: "destructive", label: "Failed" },
};

export default function AdminDashboard() {
  const [systemStatus, setSystemStatus] = useState({
    health: "healthy" as const,
    activePipelines: 0,
    failedPipelines: 0,
    jiraConnected: true,
    ragConnected: true,
  });
  
  const [kpiData, setKpiData] = useState({
    totalRuns: 0,
    bugsFixed: 0,
    avgVerifierScore: 0,
    avgIterations: 0,
  });
  
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [expandedRows, setExpandedRows] = useState<Set<number>>(new Set());
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    loadDashboardData();
  }, [statusFilter, typeFilter, searchQuery]);
  
  useEffect(() => {
    const interval = setInterval(loadDashboardData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadDashboardData = async () => {
    try {
      const statsResponse = await fetch(`${API_URL}/pipeline-logs/dashboard-stats`);
      if (!statsResponse.ok) throw new Error("Failed to fetch dashboard stats");
      const statsData = await statsResponse.json();
      setSystemStatus(statsData.systemStatus);
      setKpiData(statsData.kpiData);
      
      const params = new URLSearchParams();
      if (statusFilter !== "all") params.append("status", statusFilter);
      if (typeFilter !== "all") params.append("type", typeFilter);
      if (searchQuery) params.append("search", searchQuery);
      
      const logsResponse = await fetch(`${API_URL}/pipeline-logs/list?${params}`);
      if (!logsResponse.ok) throw new Error("Failed to fetch logs");
      const logsData = await logsResponse.json();
      setRecentActivity(logsData);
    } catch (error) {
      toast.error("Failed to load dashboard data");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };
  const status = statusConfig[systemStatus.health];
  const StatusIcon = status.icon;

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Command Center</h1>
          <p className="text-muted-foreground">System overview and real-time monitoring</p>
        </div>

        {/* System Health */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Activity className="h-5 w-5" />
              System Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="flex items-center gap-3">
                <div className={`h-3 w-3 rounded-full ${status.color} animate-pulse`} />
                <div>
                  <p className="text-sm font-medium">{status.label}</p>
                  <p className="text-xs text-muted-foreground">System Health</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Zap className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm font-medium">{systemStatus.activePipelines}</p>
                  <p className="text-xs text-muted-foreground">Active Pipelines</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <XCircle className="h-5 w-5 text-destructive" />
                <div>
                  <p className="text-sm font-medium">{systemStatus.failedPipelines}</p>
                  <p className="text-xs text-muted-foreground">Failed Pipelines</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Link2 className={`h-5 w-5 ${systemStatus.jiraConnected ? "text-success" : "text-destructive"}`} />
                <div>
                  <p className="text-sm font-medium">{systemStatus.jiraConnected ? "Connected" : "Disconnected"}</p>
                  <p className="text-xs text-muted-foreground">JIRA Status</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Database className={`h-5 w-5 ${systemStatus.ragConnected ? "text-success" : "text-destructive"}`} />
                <div>
                  <p className="text-sm font-medium">{systemStatus.ragConnected ? "Connected" : "Disconnected"}</p>
                  <p className="text-xs text-muted-foreground">RAG Vector DB</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{kpiData.totalRuns.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground">Total AI Runs</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-success/20 flex items-center justify-center">
                  <Sparkles className="h-5 w-5 text-success" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{kpiData.featuresGenerated}</p>
                  <p className="text-xs text-muted-foreground">Features Generated</p>
                </div>
              </div>
            </CardContent>
          </Card> */}

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-warning/20 flex items-center justify-center">
                  <Bug className="h-5 w-5 text-warning" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{kpiData.bugsFixed}</p>
                  <p className="text-xs text-muted-foreground">Bugs Fixed</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                  <CheckCircle2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{kpiData.avgVerifierScore}%</p>
                  <p className="text-xs text-muted-foreground">Avg Verifier Score</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{kpiData.avgIterations}</p>
                  <p className="text-xs text-muted-foreground">Avg Iterations</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pipeline Execution History */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Pipeline Execution History
                </CardTitle>
                <CardDescription>Complete history of all pipeline runs</CardDescription>
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by JIRA key or user..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="pending_review">Pending Review</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="query">Query</SelectItem>
                  <SelectItem value="resume">Resume</SelectItem>
                  <SelectItem value="bug">Bug Fix</SelectItem>
                  <SelectItem value="feature">Feature</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-3">
                {recentActivity.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <FileText className="h-12 w-12 mx-auto mb-4 opacity-20" />
                    <p>No records found</p>
                  </div>
                ) : (
                  (showAll ? recentActivity : recentActivity.slice(0, 10)).map((log) => {
                    const isExpanded = expandedRows.has(log.id);
                    const statusInfo = activityStatusConfig[log.status as keyof typeof activityStatusConfig] || { color: "default", label: log.status };
                    
                    return (
                      <div key={log.id} className="border rounded-lg overflow-hidden">
                        <div
                          className="flex items-center justify-between p-4 bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                          onClick={() => {
                            const newExpanded = new Set(expandedRows);
                            if (isExpanded) {
                              newExpanded.delete(log.id);
                            } else {
                              newExpanded.add(log.id);
                            }
                            setExpandedRows(newExpanded);
                          }}
                        >
                          <div className="flex items-center gap-4 flex-1">
                            <div className="flex items-center gap-2">
                              {log.type === "feature" ? (
                                <Sparkles className="h-4 w-4 text-primary" />
                              ) : log.type === "bug" ? (
                                <Bug className="h-4 w-4 text-warning" />
                              ) : (
                                <FileText className="h-4 w-4 text-muted-foreground" />
                              )}
                              <span className="text-sm font-mono text-muted-foreground">#{log.id}</span>
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                {log.jiraKey ? (
                                  <>
                                    <span className="text-sm font-medium">{log.jiraKey}</span>
                                    <Badge variant="outline" className="text-xs capitalize">{log.type}</Badge>
                                  </>
                                ) : (
                                  <>
                                    <span className="text-sm font-medium">No Ticket</span>
                                    <Badge variant="outline" className="text-xs capitalize">{log.type}</Badge>
                                  </>
                                )}
                              </div>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <span className="font-medium">Run by:</span>
                                <span>{log.user}</span>
                                <span>•</span>
                                <span>{log.model}</span>
                                {log.queryRefined && (
                                  <>
                                    <span>•</span>
                                    <span className="text-primary font-medium">Query refined with {log.refinerModel}</span>
                                  </>
                                )}
                                <span>•</span>
                                <span>{log.timestamp}</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              {isExpanded ? (
                                <ChevronUp className="h-4 w-4 text-muted-foreground" />
                              ) : (
                                <ChevronDown className="h-4 w-4 text-muted-foreground" />
                              )}
                            </div>
                          </div>
                        </div>
                        
                        {isExpanded && (
                          <div className="p-4 border-t space-y-3">
                            <div className="grid grid-cols-2 gap-3 p-3 bg-muted/30 rounded-lg">
                              <div>
                                <p className="text-xs text-muted-foreground">Ticket ID</p>
                                <p className="text-sm font-medium">{log.jiraKey || "N/A"}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Executed By</p>
                                <p className="text-sm font-medium">{log.user}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Generation Model</p>
                                <p className="text-sm font-medium">{log.model}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Query Refiner Model</p>
                                <p className="text-sm font-medium">
                                  {log.queryRefined ? (
                                    <span className="text-primary">{log.refinerModel} ✓</span>
                                  ) : (
                                    <span className="text-muted-foreground">Not used</span>
                                  )}
                                </p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Timestamp</p>
                                <p className="text-sm font-medium">{log.timestamp}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Status</p>
                                <Badge variant={statusInfo.color as any} className="text-xs">{statusInfo.label}</Badge>
                              </div>
                            </div>
                            
                            <div>
                              <p className="text-xs font-medium text-muted-foreground mb-1">Input Query</p>
                              <p className="text-sm bg-muted/30 p-2 rounded">{log.input}</p>
                            </div>
                            
                            {/* Two Column Layout: Logs on Left (1/3), Output on Right (2/3) */}
                            <div className="grid grid-cols-3 gap-4">
                              <div>
                                <p className="text-xs font-medium text-muted-foreground mb-2">Logs</p>
                                <ScrollArea className="h-[300px] bg-muted/30 p-3 rounded">
                                  <div className="space-y-1 text-xs font-mono">
                                    {log.logs ? (
                                      log.logs.split('\n').map((line: string, idx: number) => (
                                        <div key={idx} className={
                                          line.includes('ERROR') ? 'text-destructive' :
                                          line.includes('WARN') ? 'text-warning' :
                                          line.includes('SUCCESS') ? 'text-success' :
                                          'text-muted-foreground'
                                        }>
                                          {line}
                                        </div>
                                      ))
                                    ) : (
                                      <p className="text-muted-foreground">No logs available</p>
                                    )}
                                  </div>
                                </ScrollArea>
                              </div>
                              
                              <div className="col-span-2">
                                <p className="text-xs font-medium text-muted-foreground mb-2">Output Result</p>
                                <ScrollArea className="h-[300px] bg-muted/30 p-3 rounded">
                                  <p className="text-sm whitespace-pre-wrap">{log.output || 'No output available'}</p>
                                </ScrollArea>
                              </div>
                            </div>
                            
                            <div className="flex flex-wrap gap-4 text-xs p-3 bg-muted/30 rounded-lg">
                              {log.verifierScore !== null && (
                                <div>
                                  <span className="text-muted-foreground">Verifier Score:</span>
                                  <span className="ml-2 font-medium">{log.verifierScore}%</span>
                                </div>
                              )}
                              {log.humanApproved !== null && (
                                <div>
                                  <span className="text-muted-foreground">Human Approved:</span>
                                  <span className="ml-2 font-medium">{log.humanApproved ? "Yes" : "No"}</span>
                                </div>
                              )}
                            </div>
                            {log.feedback && (
                              <div>
                                <p className="text-xs font-medium text-muted-foreground mb-1">Feedback</p>
                                <p className="text-sm bg-warning/10 p-2 rounded">{log.feedback}</p>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
                {!showAll && recentActivity.length > 10 && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setShowAll(true)}
                  >
                    Show All ({recentActivity.length} records)
                  </Button>
                )}
                {showAll && recentActivity.length > 10 && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setShowAll(false)}
                  >
                    Show Less
                  </Button>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
