import React, { useState, useEffect } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { FileText, Download, Search, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import { API_URL } from "@/config";

interface PipelineLog {
  id: string;
  timestamp: string;
  type: string;
  jiraKey: string | null;
  user: string;
  model: string;
  status: string;
  verifierScore: number | null;
  humanApproved: boolean | null;
  input: string;
  output: string;
  snippets: string[];
  feedback: string | null;
  reasoning: string | null;
}

export default function AdminLogs() {
  const [logs, setLogs] = useState<PipelineLog[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [selectedLog, setSelectedLog] = useState<PipelineLog | null>(null);
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadLogs();
  }, [statusFilter, typeFilter, searchQuery]);

  const loadLogs = async () => {
    try {
      setIsLoading(true);
      const params = new URLSearchParams();
      if (statusFilter !== "all") params.append("status", statusFilter);
      if (typeFilter !== "all") params.append("type", typeFilter);
      if (searchQuery) params.append("search", searchQuery);
      
      const response = await fetch(`${API_URL}/pipeline-logs/list?${params}`);
      if (!response.ok) throw new Error("Failed to fetch logs");
      const data = await response.json();
      setLogs(data);
    } catch (error) {
      toast.error("Failed to load pipeline logs");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredLogs = logs;

  const handleExport = (format: string) => {
    toast.success(`Exporting logs as ${format.toUpperCase()}`);
  };

  const toggleRowExpand = (id: string) => {
    setExpandedRows((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const statusColors = {
    completed: "success",
    needs_review: "warning",
    failed: "destructive",
    in_progress: "default",
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">History (Logs)</h1>
            <p className="text-muted-foreground">Complete history of all pipeline runs</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => handleExport("csv")}>
              <Download className="h-4 w-4 mr-2" />
              CSV
            </Button>
            <Button variant="outline" onClick={() => handleExport("pdf")}>
              <Download className="h-4 w-4 mr-2" />
              PDF
            </Button>
            <Button variant="outline" onClick={() => handleExport("json")}>
              <Download className="h-4 w-4 mr-2" />
              JSON
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by JIRA key or user..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="needs_review">Needs Review</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="feature">Feature</SelectItem>
                  <SelectItem value="bug">Bug Fix</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Logs Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Audit Records
            </CardTitle>
            <CardDescription>{filteredLogs.length} records found</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8" />
                  <TableHead>Timestamp</TableHead>
                  <TableHead>JIRA Key</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Model</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => (
                  <React.Fragment key={log.id}>
                    <TableRow className="cursor-pointer" onClick={() => toggleRowExpand(log.id)}>
                      <TableCell>
                        {expandedRows.has(log.id) ? (
                          <ChevronUp className="h-4 w-4" />
                        ) : (
                          <ChevronDown className="h-4 w-4" />
                        )}
                      </TableCell>
                      <TableCell className="font-mono text-xs">{log.timestamp}</TableCell>
                      <TableCell className="font-medium">{log.jiraKey}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {log.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{log.user}</TableCell>
                      <TableCell>{log.model}</TableCell>
                      <TableCell>
                        <span className={log.verifierScore >= 70 ? "text-success" : "text-warning"}>
                          {log.verifierScore}%
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge variant={statusColors[log.status as keyof typeof statusColors] as any}>
                          {log.status.replace("_", " ")}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedLog(log);
                          }}
                        >
                          View More
                        </Button>
                      </TableCell>
                    </TableRow>
                    {expandedRows.has(log.id) && (
                      <TableRow>
                        <TableCell colSpan={9} className="bg-muted/30">
                          <div className="p-4 space-y-3">
                            <div>
                              <p className="text-xs font-medium text-muted-foreground mb-1">Input</p>
                              <p className="text-sm">{log.input}</p>
                            </div>
                            <div>
                              <p className="text-xs font-medium text-muted-foreground mb-1">Output Summary</p>
                              <p className="text-sm">{log.output}</p>
                            </div>
                            {log.feedback && (
                              <div>
                                <p className="text-xs font-medium text-muted-foreground mb-1">Human Feedback</p>
                                <p className="text-sm">{log.feedback}</p>
                              </div>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </React.Fragment>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Detail Dialog */}
        <Dialog open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Run Details - {selectedLog?.jiraKey}</DialogTitle>
              <DialogDescription>{selectedLog?.timestamp}</DialogDescription>
            </DialogHeader>
            {selectedLog && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Type</p>
                    <p className="font-medium capitalize">{selectedLog.type}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Model</p>
                    <p className="font-medium">{selectedLog.model}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Verifier Score</p>
                    <p className="font-medium">{selectedLog.verifierScore}%</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Human Approved</p>
                    <p className="font-medium">
                      {selectedLog.humanApproved === null
                        ? "Pending"
                        : selectedLog.humanApproved
                        ? "Yes"
                        : "No"}
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium">Input</p>
                  <pre className="p-3 rounded-lg bg-muted/50 text-sm overflow-x-auto whitespace-pre-wrap">
                    {selectedLog.input}
                  </pre>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium">Retrieved Snippets</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedLog.snippets.length > 0 ? (
                      selectedLog.snippets.map((s) => (
                        <Badge key={s} variant="outline">
                          {s}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-sm text-muted-foreground">No snippets retrieved</span>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium">Output Summary</p>
                  <pre className="p-3 rounded-lg bg-muted/50 text-sm overflow-x-auto whitespace-pre-wrap">
                    {selectedLog.output}
                  </pre>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-medium">Reasoning Trace</p>
                  <pre className="p-3 rounded-lg bg-muted/50 text-sm overflow-x-auto whitespace-pre-wrap">
                    {selectedLog.reasoning}
                  </pre>
                </div>

                {selectedLog.feedback && (
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Human Feedback</p>
                    <pre className="p-3 rounded-lg bg-muted/50 text-sm overflow-x-auto whitespace-pre-wrap">
                      {selectedLog.feedback}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
