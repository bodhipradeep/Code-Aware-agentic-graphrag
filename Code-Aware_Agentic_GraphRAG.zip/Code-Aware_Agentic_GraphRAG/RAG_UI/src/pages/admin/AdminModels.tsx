import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Brain, Cpu, AlertTriangle, Save, RotateCcw, Database, Server, Layers, GitBranch, Zap, CheckCircle2, XCircle, Loader2, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { getLLMConfig, saveLLMConfig, testLLMConnection, getGitLabConfig, saveGitLabConfig } from "@/services/ragApi";
import type { LLMConfigResponse } from "@/services/ragApi";

interface LLMConfig {
  llmProvider: string;
  llmApiKey: string;
  llmModel: string;
  embedModel: string;
  refinerModel: string;
  ollamaBaseUrl: string;
  temperature: number;
}

interface PipelineConfig {
  maxIterations: number;
  retrievalTopK: number;
  indexPath: string;
  memoryPath: string;
  checkpointDb: string;
  sessionTtlHours: number;
}

interface AgentConfig {
  maxQueryTransforms: number;
  maxFeedbackAttempts: number;
}

interface ServerConfig {
  host: string;
  port: number;
}

interface PgVectorConfig {
  host: string;
  port: number;
  db: string;
  user: string;
  password: string;
  collectionName: string;
  tableName: string;
  poolSize: number;
  maxOverflow: number;
}

interface RedisConfig {
  host: string;
  port: number;
  ttl: number;
}

interface GitLabConfig {
  gitlabUrl: string;
  gitlabToken: string;
  gitlabUsername: string;
  backendProject: string;
  backendBranch: string;
  frontendProject: string;
  frontendBranch: string;
  frontendGitDir: string;
}
export default function AdminModels() {
  const [llmConfig, setLlmConfig] = useState<LLMConfig>({
    llmProvider: "ollama",
    llmApiKey: "",
    llmModel: "devstral:24b",
    embedModel: "qwen3-embedding:8b",
    refinerModel: "llama3.1:8b",
    ollamaBaseUrl: "http://localhost:11434",
    temperature: 0,
  });
  const [providerMeta, setProviderMeta] = useState<Pick<LLMConfigResponse, "supported_providers" | "provider_models" | "llm_api_key_set" | "llm_api_key_masked">>({
    supported_providers: ["ollama"],
    provider_models: {},
    llm_api_key_set: false,
    llm_api_key_masked: "",
  });
  const [showApiKey, setShowApiKey] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; msg: string } | null>(null);

  const [pipelineConfig, setPipelineConfig] = useState<PipelineConfig>({
    maxIterations: 10,
    retrievalTopK: 10,
    indexPath: "Vector_Store/faiss_index",
    memoryPath: "agent_memory.pkl",
    checkpointDb: "checkpoints.db",
    sessionTtlHours: 2,
  });

  const [agentConfig, setAgentConfig] = useState<AgentConfig>({
    maxQueryTransforms: 3,
    maxFeedbackAttempts: 3,
  });

  const [serverConfig, setServerConfig] = useState<ServerConfig>({
    host: "0.0.0.0",
    port: 8000,
  });

  const [pgVectorConfig, setPgVectorConfig] = useState<PgVectorConfig>({
    host: "localhost",
    port: 5432,
    db: "rag",
    user: "postgres",
    password: "admin",
    collectionName: "code_chunks",
    tableName: "langchain_pg_embedding",
    poolSize: 20,
    maxOverflow: 10,
  });

  const [redisConfig, setRedisConfig] = useState<RedisConfig>({
    host: "localhost",
    port: 6379,
    ttl: 7200,
  });

  const [gitlabConfig, setGitlabConfig] = useState<GitLabConfig>({
    gitlabUrl: "https://git.smartbox.in",
    gitlabToken: "",
    gitlabUsername: "oauth2",
    backendProject: "",
    backendBranch: "main",
    frontendProject: "",
    frontendBranch: "main",
    frontendGitDir: "src",
  });

  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showGitlabToken, setShowGitlabToken] = useState(false);
  const [saving, setSaving] = useState(false);

  // Load config from backend on mount
  useEffect(() => {
    getLLMConfig()
      .then((data) => {
        setLlmConfig({
          llmProvider: data.llm_provider || "ollama",
          llmApiKey: "",
          llmModel: data.llm_model,
          embedModel: data.embed_model,
          refinerModel: data.refiner_model,
          ollamaBaseUrl: data.ollama_base_url,
          temperature: data.temperature,
        });
        setProviderMeta({
          supported_providers: data.supported_providers || ["ollama"],
          provider_models: data.provider_models || {},
          llm_api_key_set: data.llm_api_key_set,
          llm_api_key_masked: data.llm_api_key_masked,
        });
      })
      .catch(() => {});

    getGitLabConfig()
      .then((data) => {
        setGitlabConfig({
          gitlabUrl: data.gitlab_url,
          gitlabToken: data.gitlab_token,
          gitlabUsername: data.gitlab_username,
          backendProject: data.backend_project,
          backendBranch: data.backend_branch,
          frontendProject: data.frontend_project,
          frontendBranch: data.frontend_branch,
          frontendGitDir: data.frontend_git_dir,
        });
      })
      .catch(() => {});
  }, []);

  const handleSaveConfig = async () => {
    setSaving(true);
    try {
      const llmResult = await saveLLMConfig({
        llm_provider: llmConfig.llmProvider,
        llm_api_key: llmConfig.llmApiKey,
        llm_model: llmConfig.llmModel,
        embed_model: llmConfig.embedModel,
        refiner_model: llmConfig.refinerModel,
        ollama_base_url: llmConfig.ollamaBaseUrl,
        temperature: llmConfig.temperature,
      });
      await Promise.all([
        saveGitLabConfig({
          gitlab_url: gitlabConfig.gitlabUrl,
          gitlab_token: gitlabConfig.gitlabToken,
          gitlab_username: gitlabConfig.gitlabUsername,
          backend_project: gitlabConfig.backendProject,
          backend_branch: gitlabConfig.backendBranch,
          frontend_project: gitlabConfig.frontendProject,
          frontend_branch: gitlabConfig.frontendBranch,
          frontend_git_dir: gitlabConfig.frontendGitDir,
        }),
      ]);
      if (llmResult.warning) {
        toast.warning(`Config saved but LLM reload failed: ${llmResult.warning}`);
      } else {
        toast.success("All configuration saved successfully");
      }
    } catch (e: any) {
      toast.error(e.message || "Failed to save configuration");
    } finally {
      setSaving(false);
    }
  };

  const handleResetDefaults = () => {
    setLlmConfig({
      llmProvider: "ollama",
      llmApiKey: "",
      llmModel: "devstral:24b",
      embedModel: "qwen3-embedding:8b",
      refinerModel: "llama3.1:8b",
      ollamaBaseUrl: "http://localhost:11434",
      temperature: 0,
    });
    setTestResult(null);
    setPipelineConfig({
      maxIterations: 10,
      retrievalTopK: 10,
      indexPath: "Vector_Store/faiss_index",
      memoryPath: "agent_memory.pkl",
      checkpointDb: "checkpoints.db",
      sessionTtlHours: 2,
    });
    setAgentConfig({
      maxQueryTransforms: 3,
      maxFeedbackAttempts: 3,
    });
    setServerConfig({
      host: "0.0.0.0",
      port: 8000,
    });
    setPgVectorConfig({
      host: "localhost",
      port: 5432,
      db: "rag",
      user: "postgres",
      password: "admin",
      collectionName: "code_chunks",
      tableName: "langchain_pg_embedding",
      poolSize: 20,
      maxOverflow: 10,
    });
    setRedisConfig({
      host: "localhost",
      port: 6379,
      ttl: 7200,
    });
    setGitlabConfig({
      gitlabUrl: "https://git.smartbox.in",
      gitlabToken: "",
      gitlabUsername: "oauth2",
      backendProject: "",
      backendBranch: "main",
      frontendProject: "",
      frontendBranch: "main",
      frontendGitDir: "src",
    });
    toast.success("Reset to default configuration");
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">AI Models & Configuration</h1>
            <p className="text-muted-foreground">Manage LLM, RAG, and infrastructure settings</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleResetDefaults}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset Defaults
            </Button>
            <Button onClick={handleSaveConfig} disabled={saving}>
              <Save className="h-4 w-4 mr-2" />
              {saving ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </div>

        <Tabs defaultValue="llm" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="llm">LLM & Embeddings</TabsTrigger>
            <TabsTrigger value="pipeline">Pipeline & Agent</TabsTrigger>
            <TabsTrigger value="database">Database (PgVector)</TabsTrigger>
            <TabsTrigger value="cache">Cache & Server</TabsTrigger>
            <TabsTrigger value="gitlab">GitLab</TabsTrigger>
          </TabsList>

          {/* LLM & RAG Tab */}
          <TabsContent value="llm" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-primary" />
                    LLM Configuration
                  </CardTitle>
                  <CardDescription>Configure the language model provider and settings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>LLM Provider</Label>
                    <Select
                      value={llmConfig.llmProvider}
                      onValueChange={(value) => {
                        const models = providerMeta.provider_models[value] || [];
                        setLlmConfig({
                          ...llmConfig,
                          llmProvider: value,
                          llmModel: models[0] || llmConfig.llmModel,
                          llmApiKey: "",
                        });
                        setTestResult(null);
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select provider" />
                      </SelectTrigger>
                      <SelectContent>
                        {providerMeta.supported_providers.map((p) => (
                          <SelectItem key={p} value={p}>
                            {p === "ollama" ? "Ollama (Local)" :
                             p === "openai" ? "OpenAI" :
                             p === "anthropic" ? "Anthropic (Claude)" :
                             p === "groq" ? "Groq" :
                             p === "deepseek" ? "DeepSeek" :
                             p === "google" ? "Google (Gemini)" : p}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {llmConfig.llmProvider !== "ollama" && (
                    <div className="space-y-2">
                      <Label>API Key</Label>
                      <div className="relative">
                        <Input
                          type={showApiKey ? "text" : "password"}
                          value={llmConfig.llmApiKey}
                          onChange={(e) => setLlmConfig({ ...llmConfig, llmApiKey: e.target.value })}
                          placeholder={providerMeta.llm_api_key_set ? `Current: ${providerMeta.llm_api_key_masked}` : "Enter API key..."}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-0 top-0 h-full px-3"
                          onClick={() => setShowApiKey(!showApiKey)}
                        >
                          {showApiKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                      {providerMeta.llm_api_key_set && !llmConfig.llmApiKey && (
                        <p className="text-xs text-muted-foreground">Leave empty to keep existing key</p>
                      )}
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label>LLM Model</Label>
                    <div className="flex gap-2">
                      <Input
                        value={llmConfig.llmModel}
                        onChange={(e) => setLlmConfig({ ...llmConfig, llmModel: e.target.value })}
                        placeholder="Enter model name"
                        className="flex-1"
                      />
                    </div>
                    {(providerMeta.provider_models[llmConfig.llmProvider] || []).length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {providerMeta.provider_models[llmConfig.llmProvider].map((m) => (
                          <Badge
                            key={m}
                            variant={llmConfig.llmModel === m ? "default" : "outline"}
                            className="cursor-pointer text-xs"
                            onClick={() => setLlmConfig({ ...llmConfig, llmModel: m })}
                          >
                            {m}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>

                  {llmConfig.llmProvider === "ollama" && (
                    <div className="space-y-2">
                      <Label>Ollama Base URL</Label>
                      <Input
                        value={llmConfig.ollamaBaseUrl}
                        onChange={(e) => setLlmConfig({ ...llmConfig, ollamaBaseUrl: e.target.value })}
                        placeholder="http://localhost:11434"
                      />
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label>Temperature: {llmConfig.temperature}</Label>
                    <Slider
                      value={[llmConfig.temperature]}
                      onValueChange={([value]) => setLlmConfig({ ...llmConfig, temperature: value })}
                      min={0}
                      max={2}
                      step={0.1}
                    />
                    <p className="text-xs text-muted-foreground">
                      Lower = more deterministic, Higher = more creative
                    </p>
                  </div>

                  <Separator />

                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={testing}
                      onClick={async () => {
                        setTesting(true);
                        setTestResult(null);
                        try {
                          const res = await testLLMConnection({
                            provider: llmConfig.llmProvider,
                            model: llmConfig.llmModel,
                            api_key: llmConfig.llmApiKey || undefined,
                            base_url: llmConfig.llmProvider === "ollama" ? llmConfig.ollamaBaseUrl : undefined,
                            temperature: llmConfig.temperature,
                          });
                          setTestResult({ ok: true, msg: res.message });
                        } catch (e: any) {
                          setTestResult({ ok: false, msg: e.message });
                        } finally {
                          setTesting(false);
                        }
                      }}
                    >
                      {testing ? (
                        <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Testing...</>
                      ) : (
                        <><Zap className="h-4 w-4 mr-1" /> Test Connection</>
                      )}
                    </Button>
                    {testResult && (
                      <span className={`text-sm flex items-center gap-1 ${testResult.ok ? "text-green-600" : "text-destructive"}`}>
                        {testResult.ok ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                        {testResult.msg.length > 80 ? testResult.msg.slice(0, 80) + "..." : testResult.msg}
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Layers className="h-5 w-5 text-success" />
                    Embedding & Query Refinement
                  </CardTitle>
                  <CardDescription>Configure embedding and query processing models</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Embedding Model</Label>
                    <Input
                      value={llmConfig.embedModel}
                      onChange={(e) => setLlmConfig({ ...llmConfig, embedModel: e.target.value })}
                      placeholder="qwen3-embedding:8b"
                    />
                    <p className="text-xs text-muted-foreground">Model for generating embeddings</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Query Refiner Model</Label>
                    <Input
                      value={llmConfig.refinerModel}
                      onChange={(e) => setLlmConfig({ ...llmConfig, refinerModel: e.target.value })}
                      placeholder="llama3.1:8b"
                    />
                    <p className="text-xs text-muted-foreground">Fast model for refining JIRA queries and extracting errors</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Pipeline & Agent Tab */}
          <TabsContent value="pipeline" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Cpu className="h-5 w-5 text-primary" />
                    Pipeline Configuration
                  </CardTitle>
                  <CardDescription>Configure RAG pipeline behavior</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Max Iterations: {pipelineConfig.maxIterations}</Label>
                    <Slider
                      value={[pipelineConfig.maxIterations]}
                      onValueChange={([value]) => setPipelineConfig({ ...pipelineConfig, maxIterations: value })}
                      min={1}
                      max={50}
                      step={1}
                    />
                    <p className="text-xs text-muted-foreground">Maximum iterations for generation</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Top K Retrieval: {pipelineConfig.retrievalTopK}</Label>
                    <Slider
                      value={[pipelineConfig.retrievalTopK]}
                      onValueChange={([value]) => setPipelineConfig({ ...pipelineConfig, retrievalTopK: value })}
                      min={1}
                      max={50}
                      step={1}
                    />
                    <p className="text-xs text-muted-foreground">Number of relevant code snippets to retrieve</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Session TTL (hours): {pipelineConfig.sessionTtlHours}</Label>
                    <Slider
                      value={[pipelineConfig.sessionTtlHours]}
                      onValueChange={([value]) => setPipelineConfig({ ...pipelineConfig, sessionTtlHours: value })}
                      min={1}
                      max={48}
                      step={1}
                    />
                    <p className="text-xs text-muted-foreground">Session timeout in hours</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Cpu className="h-5 w-5 text-success" />
                    Agent Configuration
                  </CardTitle>
                  <CardDescription>Configure agent behavior and limits</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Max Query Transforms: {agentConfig.maxQueryTransforms}</Label>
                    <Slider
                      value={[agentConfig.maxQueryTransforms]}
                      onValueChange={([value]) => setAgentConfig({ ...agentConfig, maxQueryTransforms: value })}
                      min={1}
                      max={10}
                      step={1}
                    />
                    <p className="text-xs text-muted-foreground">Maximum number of query transformations</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Max Feedback Attempts: {agentConfig.maxFeedbackAttempts}</Label>
                    <Slider
                      value={[agentConfig.maxFeedbackAttempts]}
                      onValueChange={([value]) => setAgentConfig({ ...agentConfig, maxFeedbackAttempts: value })}
                      min={1}
                      max={10}
                      step={1}
                    />
                    <p className="text-xs text-muted-foreground">Maximum feedback loop attempts</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-warning" />
                  Storage Paths
                </CardTitle>
                <CardDescription>Configure file paths for vector store, memory, and checkpoints</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Index Path</Label>
                  <Input
                    value={pipelineConfig.indexPath}
                    onChange={(e) => setPipelineConfig({ ...pipelineConfig, indexPath: e.target.value })}
                    placeholder="Vector_Store/faiss_index"
                  />
                  <p className="text-xs text-muted-foreground">Path to FAISS vector index</p>
                </div>

                <div className="space-y-2">
                  <Label>Memory Path</Label>
                  <Input
                    value={pipelineConfig.memoryPath}
                    onChange={(e) => setPipelineConfig({ ...pipelineConfig, memoryPath: e.target.value })}
                    placeholder="agent_memory.pkl"
                  />
                  <p className="text-xs text-muted-foreground">Agent memory persistence file</p>
                </div>

                <div className="space-y-2">
                  <Label>Checkpoint Database</Label>
                  <Input
                    value={pipelineConfig.checkpointDb}
                    onChange={(e) => setPipelineConfig({ ...pipelineConfig, checkpointDb: e.target.value })}
                    placeholder="checkpoints.db"
                  />
                  <p className="text-xs text-muted-foreground">SQLite database for agent checkpoints</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Database Tab */}
          <TabsContent value="database" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-primary" />
                  PGVector Configuration
                </CardTitle>
                <CardDescription>PostgreSQL vector database settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Host</Label>
                    <Input
                      value={pgVectorConfig.host}
                      onChange={(e) => setPgVectorConfig({ ...pgVectorConfig, host: e.target.value })}
                      placeholder="localhost"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Port</Label>
                    <Input
                      type="number"
                      value={pgVectorConfig.port}
                      onChange={(e) => setPgVectorConfig({ ...pgVectorConfig, port: parseInt(e.target.value) })}
                      placeholder="5432"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Database</Label>
                    <Input
                      value={pgVectorConfig.db}
                      onChange={(e) => setPgVectorConfig({ ...pgVectorConfig, db: e.target.value })}
                      placeholder="vectordb"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>User</Label>
                    <Input
                      value={pgVectorConfig.user}
                      onChange={(e) => setPgVectorConfig({ ...pgVectorConfig, user: e.target.value })}
                      placeholder="postgres"
                    />
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label>Password</Label>
                    <div className="relative">
                      <Input
                        type={showPassword ? "text" : "password"}
                        value={pgVectorConfig.password}
                        onChange={(e) => setPgVectorConfig({ ...pgVectorConfig, password: e.target.value })}
                        placeholder="••••••••"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? "Hide" : "Show"}
                      </Button>
                    </div>
                  </div>
                </div>

                <Separator className="my-4" />

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Collection Name</Label>
                    <Input
                      value={pgVectorConfig.collectionName}
                      onChange={(e) => setPgVectorConfig({ ...pgVectorConfig, collectionName: e.target.value })}
                      placeholder="code_chunks"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Table Name</Label>
                    <Input
                      value={pgVectorConfig.tableName}
                      onChange={(e) => setPgVectorConfig({ ...pgVectorConfig, tableName: e.target.value })}
                      placeholder="langchain_pg_embedding"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Pool Size</Label>
                    <Input
                      type="number"
                      value={pgVectorConfig.poolSize}
                      onChange={(e) => setPgVectorConfig({ ...pgVectorConfig, poolSize: parseInt(e.target.value) })}
                      placeholder="20"
                    />
                    <p className="text-xs text-muted-foreground">Connection pool size</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Max Overflow</Label>
                    <Input
                      type="number"
                      value={pgVectorConfig.maxOverflow}
                      onChange={(e) => setPgVectorConfig({ ...pgVectorConfig, maxOverflow: parseInt(e.target.value) })}
                      placeholder="10"
                    />
                    <p className="text-xs text-muted-foreground">Maximum overflow connections</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cache & Server Tab */}
          <TabsContent value="cache" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Server className="h-5 w-5 text-primary" />
                    Server Configuration
                  </CardTitle>
                  <CardDescription>API server settings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Host</Label>
                    <Input
                      value={serverConfig.host}
                      onChange={(e) => setServerConfig({ ...serverConfig, host: e.target.value })}
                      placeholder="0.0.0.0"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Port</Label>
                    <Input
                      type="number"
                      value={serverConfig.port}
                      onChange={(e) => setServerConfig({ ...serverConfig, port: parseInt(e.target.value) })}
                      placeholder="8000"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5 text-destructive" />
                    Redis Configuration
                  </CardTitle>
                  <CardDescription>Cache server settings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Host</Label>
                    <Input
                      value={redisConfig.host}
                      onChange={(e) => setRedisConfig({ ...redisConfig, host: e.target.value })}
                      placeholder="localhost"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Port</Label>
                    <Input
                      type="number"
                      value={redisConfig.port}
                      onChange={(e) => setRedisConfig({ ...redisConfig, port: parseInt(e.target.value) })}
                      placeholder="6379"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>TTL (seconds): {redisConfig.ttl}</Label>
                    <Slider
                      value={[redisConfig.ttl]}
                      onValueChange={([value]) => setRedisConfig({ ...redisConfig, ttl: value })}
                      min={300}
                      max={86400}
                      step={300}
                    />
                    <p className="text-xs text-muted-foreground">
                      Cache time-to-live ({Math.floor(redisConfig.ttl / 3600)}h {Math.floor((redisConfig.ttl % 3600) / 60)}m)
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* GitLab Tab */}
          <TabsContent value="gitlab" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GitBranch className="h-5 w-5 text-primary" />
                    GitLab Connection
                  </CardTitle>
                  <CardDescription>GitLab server URL and credentials</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>GitLab URL</Label>
                    <Input
                      value={gitlabConfig.gitlabUrl}
                      onChange={(e) => setGitlabConfig({ ...gitlabConfig, gitlabUrl: e.target.value })}
                      placeholder="https://gitlab.example.com"
                    />
                    <p className="text-xs text-muted-foreground">Base URL of your GitLab instance</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Access Token</Label>
                    <div className="relative">
                      <Input
                        type={showGitlabToken ? "text" : "password"}
                        value={gitlabConfig.gitlabToken}
                        onChange={(e) => setGitlabConfig({ ...gitlabConfig, gitlabToken: e.target.value })}
                        placeholder="glpat-xxxxxxxxxxxxxxxxxxxx"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => setShowGitlabToken(!showGitlabToken)}
                      >
                        {showGitlabToken ? "Hide" : "Show"}
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">Personal access token with repo read access</p>
                  </div>

                  <div className="space-y-2">
                    <Label>Username</Label>
                    <Input
                      value={gitlabConfig.gitlabUsername}
                      onChange={(e) => setGitlabConfig({ ...gitlabConfig, gitlabUsername: e.target.value })}
                      placeholder="oauth2"
                    />
                    <p className="text-xs text-muted-foreground">Git username (usually oauth2 for token auth)</p>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Server className="h-5 w-5 text-success" />
                      Backend Repository
                    </CardTitle>
                    <CardDescription>Java backend project configuration</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Project Path</Label>
                      <Input
                        value={gitlabConfig.backendProject}
                        onChange={(e) => setGitlabConfig({ ...gitlabConfig, backendProject: e.target.value })}
                        placeholder="group/project-backend"
                      />
                      <p className="text-xs text-muted-foreground">GitLab project path (e.g. group/repo-name)</p>
                    </div>

                    <div className="space-y-2">
                      <Label>Branch</Label>
                      <Input
                        value={gitlabConfig.backendBranch}
                        onChange={(e) => setGitlabConfig({ ...gitlabConfig, backendBranch: e.target.value })}
                        placeholder="main"
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Layers className="h-5 w-5 text-warning" />
                      Frontend Repository
                    </CardTitle>
                    <CardDescription>Angular frontend project configuration</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>Project Path</Label>
                      <Input
                        value={gitlabConfig.frontendProject}
                        onChange={(e) => setGitlabConfig({ ...gitlabConfig, frontendProject: e.target.value })}
                        placeholder="group/project-frontend"
                      />
                      <p className="text-xs text-muted-foreground">GitLab project path (e.g. group/repo-name)</p>
                    </div>

                    <div className="space-y-2">
                      <Label>Branch</Label>
                      <Input
                        value={gitlabConfig.frontendBranch}
                        onChange={(e) => setGitlabConfig({ ...gitlabConfig, frontendBranch: e.target.value })}
                        placeholder="main"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Source Directory (Sparse Checkout)</Label>
                      <Input
                        value={gitlabConfig.frontendGitDir}
                        onChange={(e) => setGitlabConfig({ ...gitlabConfig, frontendGitDir: e.target.value })}
                        placeholder="src"
                      />
                      <p className="text-xs text-muted-foreground">Subdirectory to checkout (leave empty for full repo)</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirm Configuration Change</AlertDialogTitle>
              <AlertDialogDescription>
                This change affects all future pipeline runs. Are you sure you want to proceed?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={() => setShowConfirmDialog(false)}>
                Confirm Change
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AdminLayout>
  );
}
