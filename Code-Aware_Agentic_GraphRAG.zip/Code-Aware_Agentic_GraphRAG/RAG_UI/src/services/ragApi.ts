/**
 * RAG API Service
 * Connects to FastAPI backend for RAG pipeline operations
 */

import { API_URL as RAG_API_URL } from '@/config';

// Types matching backend Pydantic models
export interface QueryRequest {
  query: string;
  user_id?: string;
  jira_key?: string;
  error?: string;  // Deprecated - use error_message
  error_message?: string;
  log_content?: string;
  file_hint?: string;
}

export interface QueryResponse {
  thread_id: string;
  query: string;
  answer: string | null;
  status: 'completed' | 'pending_review';
  query_transforms: number;
  logs?: string[];
}

export interface ResumeRequest {
  thread_id: string;
  human: 'approved' | 'feedback';
  feedback?: string;
  user_id?: string;
  jira_key?: string;
}

export interface ResumeResponse {
  thread_id: string;
  answer: string;
  status: 'completed' | 'reanalyzed' | 'max_attempts';
  attempt?: number;
  logs?: string[];
}

export interface IndexRequest {
  path: string;
}

export interface IndexResponse {
  message: string;
  stats: {
    total: number;
    java: number;
    angular: number;
  };
}

export interface HealthResponse {
  status: string;
  index_stats: {
    total: number;
    java: number;
    angular: number;
  };
  model: string;
  redis: {
    status: string;
    used_memory_human?: string;
    connected_clients?: number;
  };
  checkpointer: string;
  active_sessions: number;
}

export interface ThreadState {
  thread_id: string;
  original_query: string;
  current_question: string;
  query_transforms: number;
  feedback_count: number;
  final_report: string;
  human: string | null;
  is_approved: boolean | null;
  next_nodes: string[];
}

export interface ClassListResponse {
  classes: string[];
  count: number;
}

export interface RefineQueryRequest {
  query: string;
  error_message?: string;
  log_content?: string;
}

export interface RefineQueryResponse {
  original_query: string;
  refined_query: string;
  extracted_error?: string;  // Auto-extracted error from logs
  status: string;
}

// API Functions

/**
 * Refine a raw JIRA bug description into a focused query
 */
export async function refineQuery(request: RefineQueryRequest): Promise<RefineQueryResponse> {
  const response = await fetch(`${RAG_API_URL}/refine-query`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to refine query');
  }

  return response.json();
}

/**
 * Submit a query to the RAG pipeline
 */
export async function queryCode(request: QueryRequest): Promise<QueryResponse> {
  const response = await fetch(`${RAG_API_URL}/query`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
    throw new Error(error.detail || `HTTP ${response.status}`);
  }

  return response.json();
}

export interface StreamEvent {
  type: 'start' | 'phase' | 'cache_hit' | 'not_relevant' | 'complete' | 'error';
  thread_id?: string;
  node?: string;
  step?: number;
  logs?: string[];
  answer?: string;
  status?: string;
  query_transforms?: number;
  message?: string;
}

/**
 * Submit a query with SSE streaming — yields progress events as each phase completes
 */
export async function queryCodeStream(
  request: QueryRequest,
  onEvent: (event: StreamEvent) => void,
): Promise<void> {
  const response = await fetch(`${RAG_API_URL}/query/stream`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
    throw new Error(error.detail || `HTTP ${response.status}`);
  }

  const reader = response.body?.getReader();
  if (!reader) throw new Error('No response body');

  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          const event: StreamEvent = JSON.parse(line.slice(6));
          onEvent(event);
        } catch {
          // skip malformed events
        }
      }
    }
  }
}

/**
 * Resume a workflow (approve or provide feedback)
 */
export async function resumeAnalysis(request: ResumeRequest): Promise<ResumeResponse> {
  const response = await fetch(`${RAG_API_URL}/resume`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(request),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
    throw new Error(error.detail || `HTTP ${response.status}`);
  }

  return response.json();
}

/**
 * Index files from a directory or file path
 */
export async function indexFiles(path: string): Promise<IndexResponse> {
  const response = await fetch(`${RAG_API_URL}/index`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ path }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
    throw new Error(error.detail || `HTTP ${response.status}`);
  }

  return response.json();
}

/**
 * Get health status and index stats
 */
export async function getHealth(): Promise<HealthResponse> {
  const response = await fetch(`${RAG_API_URL}/health`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`Health check failed: HTTP ${response.status}`);
  }

  return response.json();
}

/**
 * Get current state of a thread
 */
export async function getThreadState(threadId: string): Promise<ThreadState> {
  const response = await fetch(`${RAG_API_URL}/state/${threadId}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Unknown error' }));
    throw new Error(error.detail || `HTTP ${response.status}`);
  }

  return response.json();
}

/**
 * List all indexed class names
 */
export async function getClasses(): Promise<ClassListResponse> {
  const response = await fetch(`${RAG_API_URL}/classes`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to get classes: HTTP ${response.status}`);
  }

  return response.json();
}

/**
 * Clear the vector store index
 */
export async function clearIndex(): Promise<{ message: string; stats: object }> {
  const response = await fetch(`${RAG_API_URL}/index`, {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to clear index: HTTP ${response.status}`);
  }

  return response.json();
}

/**
 * Clear entire vector store (delete all documents)
 */
export async function clearVectorStore(): Promise<{ message: string; success: boolean; stats: object }> {
  const response = await fetch(`${RAG_API_URL}/clear`, {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to clear vector store: HTTP ${response.status}`);
  }

  return response.json();
}

// ─── Knowledge Graph API ────────────────────────────────────────────

export interface GraphStats {
  features: number;
  directorys: number;
  files: number;
  classs: number;
  interfaces: number;
  methods: number;
  apiendpoints: number;
  total_relationships: number;
  relationships: Record<string, number>;
}

export async function getGraphStats(): Promise<GraphStats> {
  const res = await fetch(`${RAG_API_URL}/admin/graph-stats`);
  if (!res.ok) throw new Error('Failed to load graph stats');
  return res.json();
}

export async function rebuildGraph(): Promise<{ message: string; stats: Record<string, number> }> {
  const res = await fetch(`${RAG_API_URL}/admin/graph-rebuild`, {
    method: 'DELETE',
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({ detail: 'Unknown error' }));
    throw new Error(error.detail || 'Failed to rebuild graph');
  }
  return res.json();
}

// ─── Configuration API ───────────────────────────────────────────────

export interface LLMConfigData {
  llm_provider: string;
  llm_api_key: string;
  llm_model: string;
  embed_model: string;
  refiner_model: string;
  ollama_base_url: string;
  temperature: number;
}

export interface LLMConfigResponse extends Omit<LLMConfigData, 'llm_api_key'> {
  llm_api_key_set: boolean;
  llm_api_key_masked: string;
  supported_providers: string[];
  provider_models: Record<string, string[]>;
}

export interface LLMTestRequest {
  provider: string;
  model: string;
  api_key?: string;
  base_url?: string;
  temperature?: number;
}

export interface GitLabConfigData {
  gitlab_url: string;
  gitlab_token: string;
  gitlab_username: string;
  backend_project: string;
  backend_branch: string;
  frontend_project: string;
  frontend_branch: string;
  frontend_git_dir: string;
}

export async function getLLMConfig(): Promise<LLMConfigResponse> {
  const res = await fetch(`${RAG_API_URL}/config/llm`);
  if (!res.ok) throw new Error('Failed to load LLM config');
  return res.json();
}

export async function saveLLMConfig(data: LLMConfigData): Promise<{ success: boolean; message: string; warning?: string }> {
  const res = await fetch(`${RAG_API_URL}/config/llm`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Failed to save LLM config' }));
    throw new Error(err.detail || 'Failed to save LLM config');
  }
  return res.json();
}

export async function testLLMConnection(data: LLMTestRequest): Promise<{ success: boolean; message: string }> {
  const res = await fetch(`${RAG_API_URL}/config/llm/test`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Connection test failed' }));
    throw new Error(err.detail || 'Connection test failed');
  }
  return res.json();
}

export async function getGitLabConfig(): Promise<GitLabConfigData> {
  const res = await fetch(`${RAG_API_URL}/config/gitlab`);
  if (!res.ok) throw new Error('Failed to load GitLab config');
  return res.json();
}

export async function saveGitLabConfig(data: GitLabConfigData): Promise<{ success: boolean; message: string }> {
  const res = await fetch(`${RAG_API_URL}/config/gitlab`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to save GitLab config');
  return res.json();
}

// ─── Agent Memory API ───────────────────────────────────────────────

export interface MemoryStats {
  total_records: number;
  approved: number;
  unique_users: number;
  oldest_record: string | null;
  newest_record: string | null;
  expired_pending_cleanup: number;
  ttl_days: number;
  vector_table_size: string;
  response_table_size: string;
  per_user: Array<{ user_id: string; count: number }>;
  error?: string;
}

export interface MemoryTTLRequest {
  ttl_years?: number;
  ttl_days?: number;
  delete_before?: string;
}

export async function getMemoryStats(): Promise<MemoryStats> {
  const res = await fetch(`${RAG_API_URL}/admin/memory-stats`);
  if (!res.ok) throw new Error('Failed to load memory stats');
  return res.json();
}

export async function setMemoryTTL(data: MemoryTTLRequest): Promise<any> {
  const res = await fetch(`${RAG_API_URL}/admin/memory-ttl`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({ detail: 'Unknown error' }));
    throw new Error(error.detail || 'Failed to set memory TTL');
  }
  return res.json();
}

export async function cleanupMemory(): Promise<{ message: string; deleted: number }> {
  const res = await fetch(`${RAG_API_URL}/admin/memory-cleanup`, {
    method: 'DELETE',
  });
  if (!res.ok) throw new Error('Failed to cleanup memory');
  return res.json();
}

export async function clearMemory(): Promise<{ message: string }> {
  const res = await fetch(`${RAG_API_URL}/admin/clear-memory`, {
    method: 'DELETE',
  });
  if (!res.ok) throw new Error('Failed to clear memory');
  return res.json();
}
