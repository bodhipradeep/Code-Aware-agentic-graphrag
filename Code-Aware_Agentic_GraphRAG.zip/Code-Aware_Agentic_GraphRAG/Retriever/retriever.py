from typing import List
from langchain_core.documents import Document
from Config.settings import CONFIG


class CodeRetriever:
    """Retriever for searching code in the vector store."""
    
    def __init__(self, store):
        self.store = store
    
    def retrieve(self, query: str, k: int = None, language: str = None) -> str:
        """
        Retrieve relevant code snippets.
        
        Args:
            query: Search query
            k: Number of results (default from CONFIG)
            language: Filter by language ('java' or 'angular')
            
        Returns:
            Formatted string of code snippets
        """
        if k is None:
            k = CONFIG["retrieval_top_k"]
            
        docs = self.store.search(query, k=k, language=language)
        if not docs:
            return "No relevant code found."
        
        output = []
        for i, doc in enumerate(docs, 1):
            m = doc.metadata
            lang = m.get('language', 'java')
            code_lang = 'typescript' if lang == 'angular' else 'java'
            output.append(
                f"[{i}] {m.get('file_name', 'unknown')} ({lang})\n"
                f"```{code_lang}\n{doc.page_content}\n```"
            )
        return "\n\n".join(output)
    
    def retrieve_docs(self, query: str, k: int = None, language: str = None) -> List[Document]:
        """
        Retrieve documents directly.
        
        Args:
            query: Search query
            k: Number of results
            language: Filter by language
            
        Returns:
            List of Document objects
        """
        if k is None:
            k = CONFIG["retrieval_top_k"]
        return self.store.search(query, k=k, language=language)
