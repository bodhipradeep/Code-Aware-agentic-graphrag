"""
Utility to save and load chunks to/from JSON files.
"""

import json
import os
import logging
from datetime import datetime
from typing import List, Dict, Any, Set
from langchain_core.documents import Document

logger = logging.getLogger(__name__)


def save_chunks_to_json(
    chunks: List[Document],
    output_dir: str = None,
    filename: str = None
) -> str:
    """
    Save chunks to a JSON file with content and metadata.
    Uses relative_path as the key to replace existing chunks for the same file.
    """
    if output_dir is None:
        base_dir = os.path.dirname(os.path.dirname(__file__))
        output_dir = os.path.join(base_dir, "Output", "chunks")

    os.makedirs(output_dir, exist_ok=True)

    if filename is None:
        filename = "chunks_latest.json"

    filepath = os.path.join(output_dir, filename)

    # Get relative_paths from new chunks
    new_paths: Set[str] = set()
    for chunk in chunks:
        rp = chunk.metadata.get("relative_path") if hasattr(chunk, 'metadata') else None
        if rp:
            new_paths.add(rp)

    # Load existing chunks if file exists
    existing_chunks = []
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                existing_data = json.load(f)
                existing_chunks = existing_data.get("chunks", [])
        except Exception as e:
            logger.warning(f"Could not load existing chunks: {e}")
            existing_chunks = []

    # Keep only chunks whose relative_path is NOT in the new set
    chunks_to_keep = [
        chunk for chunk in existing_chunks
        if chunk.get("metadata", {}).get("relative_path") not in new_paths
    ]
    removed_count = len(existing_chunks) - len(chunks_to_keep)

    if removed_count > 0:
        logger.info(f"Replacing {removed_count} existing chunks from {len(new_paths)} file(s)")

    # Convert new Document objects to serializable dicts
    new_serializable_chunks = []
    for chunk in chunks:
        chunk_data = {
            "content": chunk.page_content if hasattr(chunk, 'page_content') else str(chunk),
            "metadata": chunk.metadata if hasattr(chunk, 'metadata') else {}
        }
        new_serializable_chunks.append(chunk_data)

    # Combine: existing (filtered) + new chunks
    all_chunks = chunks_to_keep + new_serializable_chunks

    # Re-assign IDs
    for i, chunk in enumerate(all_chunks):
        chunk["id"] = i + 1

    data = {
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "total_chunks": len(all_chunks),
        "chunks": all_chunks
    }

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    logger.info(f"Chunks saved to: {filepath} (Total: {len(all_chunks)})")
    return filepath


def delete_chunks_by_paths(
    paths: Set[str],
    output_dir: str = None,
    filename: str = None
) -> int:
    """
    Remove chunks from the JSON file whose relative_path is in *paths*.

    Returns the number of chunks removed.
    """
    # Normalize to forward slashes
    paths = {p.replace("\\", "/") for p in paths}
    if output_dir is None:
        base_dir = os.path.dirname(os.path.dirname(__file__))
        output_dir = os.path.join(base_dir, "Output", "chunks")

    if filename is None:
        filename = "chunks_latest.json"

    filepath = os.path.join(output_dir, filename)

    if not os.path.exists(filepath):
        return 0

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        return 0

    existing = data.get("chunks", [])
    kept = [c for c in existing if c.get("metadata", {}).get("relative_path") not in paths]
    removed = len(existing) - len(kept)

    if removed > 0:
        for i, chunk in enumerate(kept):
            chunk["id"] = i + 1
        data["chunks"] = kept
        data["total_chunks"] = len(kept)
        data["updated_at"] = datetime.now().isoformat()
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        logger.info(f"Deleted {removed} chunks for {len(paths)} deleted file(s)")

    return removed


def load_chunks_from_json(filepath: str) -> List[Document]:
    """
    Load chunks from a JSON file and convert back to Document objects.
    
    Args:
        filepath: Path to the JSON file
    
    Returns:
        List of Document objects
    """
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    documents = []
    for chunk in data.get("chunks", []):
        doc = Document(
            page_content=chunk.get("content", ""),
            metadata=chunk.get("metadata", {})
        )
        documents.append(doc)
    
    logger.info(f"Loaded {len(documents)} chunks from: {filepath}")
    return documents


def get_latest_chunks_file(output_dir: str = None) -> str:
    """
    Get the path to the most recent chunks JSON file.
    
    Args:
        output_dir: Directory where chunks are stored
    
    Returns:
        Path to the latest JSON file or None if no files exist
    """
    if output_dir is None:
        base_dir = os.path.dirname(os.path.dirname(__file__))
        output_dir = os.path.join(base_dir, "Output", "chunks")
    
    if not os.path.exists(output_dir):
        return None
    
    json_files = [f for f in os.listdir(output_dir) if f.endswith('.json')]
    if not json_files:
        return None
    
    # Sort by modification time and get the latest
    json_files.sort(key=lambda x: os.path.getmtime(os.path.join(output_dir, x)), reverse=True)
    return os.path.join(output_dir, json_files[0])
