import logging
from Config.settings import CONFIG

logger = logging.getLogger(__name__)

_llm_instance = None
_embed_instance = None

SUPPORTED_PROVIDERS = ["ollama", "openai", "anthropic", "groq", "deepseek", "google"]

PROVIDER_MODELS = {
    "ollama": ["devstral:24b", "llama3.1:8b", "gemma3:4b", "qwen3:8b", "mistral:7b"],
    "openai": ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo", "o3-mini"],
    "anthropic": ["claude-sonnet-4-20250514", "claude-3-5-haiku-20241022", "claude-opus-4-20250514"],
    "groq": ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "gemma2-9b-it", "mixtral-8x7b-32768"],
    "deepseek": ["deepseek-chat", "deepseek-reasoner"],
    "google": ["gemini-2.0-flash", "gemini-1.5-pro", "gemini-1.5-flash"],
}


def create_llm(provider=None, model=None, api_key=None, base_url=None, temperature=None):
    """Create an LLM instance for the given provider."""
    provider = provider or CONFIG.get("llm_provider", "ollama")
    model = model or CONFIG.get("llm_model", "devstral:24b")
    api_key = api_key or CONFIG.get("llm_api_key", "")
    temperature = temperature if temperature is not None else float(CONFIG.get("temperature", 0))

    logger.info(f"Creating LLM: provider={provider}, model={model}")

    if provider not in SUPPORTED_PROVIDERS:
        raise ValueError(f"Unsupported LLM provider: {provider}. Supported: {', '.join(SUPPORTED_PROVIDERS)}")

    if provider == "ollama":
        from langchain_ollama import ChatOllama
        base_url = base_url or CONFIG.get("ollama_base_url", "http://localhost:11434")
        return ChatOllama(model=model, base_url=base_url, temperature=temperature)

    if not api_key:
        raise ValueError(f"API key required for provider '{provider}'")

    if provider == "openai":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=model, api_key=api_key, temperature=temperature)

    if provider == "anthropic":
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(model=model, api_key=api_key, temperature=temperature)

    if provider == "groq":
        from langchain_groq import ChatGroq
        return ChatGroq(model=model, api_key=api_key, temperature=temperature)

    if provider == "deepseek":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(
            model=model, api_key=api_key,
            base_url="https://api.deepseek.com/v1", temperature=temperature,
        )

    if provider == "google":
        from langchain_google_genai import ChatGoogleGenerativeAI
        return ChatGoogleGenerativeAI(model=model, google_api_key=api_key, temperature=temperature)


def get_llm():
    """Get the current LLM singleton. Lazily created on first call."""
    global _llm_instance
    if _llm_instance is None:
        _llm_instance = create_llm()
    return _llm_instance


def reload_llm():
    """Recreate the LLM after a config change."""
    global _llm_instance
    _llm_instance = None
    return get_llm()


def get_embed_model():
    """Get the embedding model singleton (always Ollama)."""
    global _embed_instance
    if _embed_instance is None:
        from langchain_ollama import OllamaEmbeddings
        _embed_instance = OllamaEmbeddings(
            model=CONFIG["embed_model"],
            base_url=CONFIG["ollama_base_url"],
        )
    return _embed_instance


def reload_embed_model():
    """Recreate the embedding model after a config change."""
    global _embed_instance
    _embed_instance = None
    return get_embed_model()


def test_llm_connection(provider, model, api_key="", base_url="", temperature=0):
    """Test an LLM connection by sending a trivial prompt. Returns (ok, message)."""
    try:
        test_llm = create_llm(
            provider=provider, model=model,
            api_key=api_key, base_url=base_url, temperature=temperature,
        )
        response = test_llm.invoke([{"role": "user", "content": "Say OK"}])
        text = str(response.content).strip()[:200]
        return True, f"Connected — response: {text}"
    except Exception as e:
        return False, str(e)
