"""
Code-Aware Agentic GraphRAG — FastAPI Application.

Slim orchestrator: mounts routers, configures middleware, provides health check.
All endpoint logic lives in API/ routers.
"""

import logging

from fastapi import FastAPI, Depends, Security
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from prometheus_fastapi_instrumentator import Instrumentator

from Config.settings import CONFIG

# Import shared state (triggers initialization of vector_store, graph, etc.)
from API.dependencies import (
    vector_store, redis_client, query_sessions, cleanup_expired_sessions,
)

# Import routers
from API.auth_api import router as auth_router
from API.pipeline_logs_api import router as pipeline_logs_router
from API.config_api import router as config_router
from API.query_api import router as query_router
from API.admin_api import router as admin_router
from API.sync_api import router as sync_router
from API.jira_proxy_api import router as jira_router
from API.index_api import router as index_router

logger = logging.getLogger(__name__)

# === API Key security ===

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


async def verify_api_key(api_key: str = Security(api_key_header)):
    if not CONFIG["api_keys"]:
        return "dev-mode"
    if not api_key or api_key not in CONFIG["api_keys"]:
        from fastapi import HTTPException
        raise HTTPException(status_code=403, detail="Invalid API Key")
    return api_key


# === App creation ===

app = FastAPI(
    title="Code-Aware Agentic GraphRAG",
    version="3.0",
    description="AI-powered bug fixing with 6-phase agentic pipeline and Human-in-the-Loop",
)

Instrumentator().instrument(app).expose(app)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === Mount routers ===

app.include_router(auth_router)
app.include_router(pipeline_logs_router)
app.include_router(config_router)
app.include_router(query_router)
app.include_router(admin_router)
app.include_router(sync_router)
app.include_router(jira_router)
app.include_router(index_router)

# === Initialize database tables on startup ===

try:
    from API.auth_api import init_users_table
    from API.pipeline_logs_api import init_pipeline_logs_table
    from API.config_api import init_config_table

    init_users_table()
    init_pipeline_logs_table()
    init_config_table()
    logger.info("Database tables initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize database tables: {e}")


# === Health check (only endpoint that stays in app.py) ===

@app.get("/health")
def health_check():
    """Health check endpoint."""
    cleanup_expired_sessions()

    redis_status = "connected"
    redis_info = {}
    if redis_client:
        try:
            redis_client.ping()
            info_memory = redis_client.info("memory")
            info_clients = redis_client.info("clients")
            redis_info = {
                "used_memory_human": info_memory.get("used_memory_human", "N/A")
                if isinstance(info_memory, dict) else "N/A",
                "connected_clients": info_clients.get("connected_clients", 0)
                if isinstance(info_clients, dict) else 0,
            }
        except Exception as e:
            redis_status = f"error: {str(e)}"
    else:
        redis_status = "disabled"

    return {
        "status": "healthy",
        "index_stats": vector_store.get_stats(),
        "model": CONFIG["llm_model"],
        "redis": {"status": redis_status, **redis_info},
        "checkpointer": "SqliteSaver",
        "active_sessions": len(query_sessions),
    }


# === Run server ===

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
