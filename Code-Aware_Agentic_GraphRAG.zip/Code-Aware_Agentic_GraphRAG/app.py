"""
Code-Aware Agentic GraphRAG — FastAPI Application.

Slim orchestrator: mounts routers, configures middleware, provides health check.
All endpoint logic lives in API/ routers.
"""

import os
import logging

from fastapi import FastAPI, Depends, Security, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from prometheus_fastapi_instrumentator import Instrumentator
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from Config.settings import CONFIG

# Import shared state (triggers initialization of vector_store, graph, etc.)
from API.dependencies import (
    vector_store, redis_client, query_sessions, cleanup_expired_sessions,
)

# Import routers
from API.auth_api import router as auth_router
from API.pipeline_logs_api import router as pipeline_logs_router
from API.config_api import router as config_router
from API.query_api import router as query_router
from API.admin_api import router as admin_router
from API.sync_api import router as sync_router
from API.jira_proxy_api import router as jira_router
from API.index_api import router as index_router

logger = logging.getLogger(__name__)

# === API Key security ===

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


async def verify_api_key(api_key: str = Security(api_key_header)):
    if not CONFIG["api_keys"]:
        return "dev-mode"
    if not api_key or api_key not in CONFIG["api_keys"]:
        from fastapi import HTTPException
        raise HTTPException(status_code=403, detail="Invalid API Key")
    return api_key


# === Rate limiter ===

limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["60/minute"],
    application_limits=["200/minute"],
)

# === App creation ===

app = FastAPI(
    title="Code-Aware Agentic GraphRAG",
    version="3.0",
    description="AI-powered bug fixing with 6-phase agentic pipeline and Human-in-the-Loop",
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

Instrumentator().instrument(app).expose(app)

ALLOWED_ORIGINS = os.getenv(
    "CORS_ORIGINS",
    "http://localhost:5173,http://localhost:3000",
).split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in ALLOWED_ORIGINS],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# === Mount routers ===

app.include_router(auth_router)
app.include_router(pipeline_logs_router)
app.include_router(config_router)
app.include_router(query_router)
app.include_router(admin_router)
app.include_router(sync_router)
app.include_router(jira_router)
app.include_router(index_router)

# === Initialize database tables on startup ===

try:
    from API.auth_api import init_users_table
    from API.pipeline_logs_api import init_pipeline_logs_table
    from API.config_api import init_config_table

    init_users_table()
    init_pipeline_logs_table()
    init_config_table()
    logger.info("Database tables initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize database tables: {e}")


# === Health check (only endpoint that stays in app.py) ===

@app.get("/health")
def health_check():
    """Health check endpoint."""
    cleanup_expired_sessions()

    redis_status = "connected"
    redis_info = {}
    if redis_client:
        try:
            redis_client.ping()
            info_memory = redis_client.info("memory")
            info_clients = redis_client.info("clients")
            redis_info = {
                "used_memory_human": info_memory.get("used_memory_human", "N/A")
                if isinstance(info_memory, dict) else "N/A",
                "connected_clients": info_clients.get("connected_clients", 0)
                if isinstance(info_clients, dict) else 0,
            }
        except Exception as e:
            redis_status = f"error: {str(e)}"
    else:
        redis_status = "disabled"

    return {
        "status": "healthy",
        "index_stats": vector_store.get_stats(),
        "model": CONFIG["llm_model"],
        "redis": {"status": redis_status, **redis_info},
        "checkpointer": "SqliteSaver",
        "active_sessions": len(query_sessions),
    }


# === Checkpoint cleanup ===

@app.post("/admin/cleanup-checkpoints")
@limiter.limit("2/hour")
def cleanup_checkpoints(request: Request):
    """Delete old checkpoint data to prevent unbounded DB growth."""
    import sqlite3
    db_path = CONFIG.get("checkpoint_db", "checkpoints.db")
    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM checkpoints")
        before = cur.fetchone()[0]
        cur.execute("""
            DELETE FROM checkpoints
            WHERE thread_id NOT IN (
                SELECT DISTINCT thread_id FROM checkpoints
                ORDER BY thread_id DESC LIMIT 100
            )
        """)
        conn.execute("VACUUM")
        conn.commit()
        cur.execute("SELECT COUNT(*) FROM checkpoints")
        after = cur.fetchone()[0]
        conn.close()
        return {"deleted": before - after, "remaining": after}
    except Exception as e:
        return {"error": str(e)}
