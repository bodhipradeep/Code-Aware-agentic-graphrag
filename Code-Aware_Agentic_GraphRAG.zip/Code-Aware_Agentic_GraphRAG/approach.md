# Code-Aware Agentic GraphRAG -- Approach

## Problem Statement

The current GraphRAG system finds code through **similarity search** (vector) + **graph traversal** (Neo4j). It retrieves chunks that *look similar* to the query -- but it does NOT **reason** about where a bug actually exists.

**Example failure**: Query "submit button gives error"
- Current system: Searches for chunks containing "submit", "button", "error" -- finds random matches
- What it SHOULD do: Understand this could be frontend (Angular component) OR backend (API) -- plan an investigation -- trace the call chain: `button click -> Angular service -> HTTP call -> Java controller -> service -> repository` -- find the root cause

Modern IDE AI assistants (Cursor, GitHub Copilot, Windsurf) do this naturally -- they **plan**, **search**, **trace**, and **reason** before suggesting fixes. Our system needs the same capability.

## Research Foundation

| System | Approach | Result |
|--------|----------|--------|
| **Agentless** (UIUC, 2024) | Hierarchical localization: File -> Class -> Method, then repair | 32% SWE-bench at $0.70/issue |
| **SWE-Agent** (Princeton) | ReAct agent with file/search tools | 6.7x better than RAG-only |
| **AutoCodeRover** (NUS) | AST search APIs + iterative context retrieval | 22% SWE-bench |
| **LLM4FL** | Call graph traversal tools for fault localization | Outperforms all spectrum-based FL |
| **SWE-Adept** | Multi-agent: localizer + fixer + verifier | 87.8% file-level localization |
| **LogicLens** | Knowledge graph + logical reasoning for code | 69.5% vs 0% for vector-only |

**Key insight**: The **Agentless** approach works best for smaller models (24B). It uses a **structured pipeline** where the orchestrator controls flow and the LLM makes decisions at each step -- no free-form ReAct required.

## Architecture: 6-Phase Structured Agentic Pipeline

```
                    +--------------------------------------------------+
                    |           LangGraph Orchestrator                  |
                    |  (Controls flow, LLM decides at each step)       |
                    +--------------------------------------------------+

START -> memory_check --> cache_hit -> finalize -> END
              |
              v (cache miss)
   +------------------------+
   | 1. INVESTIGATION       |  LLM reads bug report -> outputs structured plan
   |    PLANNER             |  {symptom, likely_layers, search_entities, flow}
   |    (CoT: 5-step)       |
   +----------+-------------+
              v
   +------------------------+
   | 2. HIERARCHICAL        |  Graph queries -> candidate locations
   |    LOCALIZER           |  LLM ranks: most -> least likely to contain bug
   +----------+-------------+
              |
         has_candidates / no_candidates -> end_not_relevant -> END
              v
   +------------------------+
   | 3. EVIDENCE            |  For top N candidates:
   |    COLLECTOR           |  * Code chunks from pgvector
   |                        |  * Call chains from Neo4j
   |                        |  * Related classes from graph
   +----------+-------------+
              v
   +------------------------+     needs more context
   | 4. ROOT CAUSE          |-----------------------------+
   |    ANALYZER            |                             v
   |    (CoT: 5-step trace) |<---- evidence_collector (max 3 rounds)
   |    (Rubric confidence) |
   +----------+-------------+
              v (root cause found)
   +------------------------+
   | 5. FIX GENERATOR       |  Full fix report with code
   |    (CoT: 4-step THINK) |
   +----------+-------------+
              |
         rubric >= 3/5 -> skip_verify --+
              v                          |
   +------------------------+           |
   | 6. FIX VERIFIER        |           |
   |    (Adversarial review) |           |
   +----------+-------------+           |
         |         |                     |
      verified   regenerate              |
         |     (max 2 attempts)          |
         v                               |
   +------------------------+ <----------+
   |    DEVELOPER REVIEW    |  HITL checkpoint (interrupt)
   |    (approve/feedback)  |
   +----------+-------------+
         v         v
      finalize   feedback -> back to PLANNER (max 3)
         v
        END (save to memory)
```

## Why Structured Pipeline > ReAct for Smaller Models

| Aspect | Free-form ReAct | Structured Pipeline (Ours) |
|--------|-----------------|---------------------------|
| Model requirement | GPT-4 / 70B+ | Works with 24B (devstral) and cloud APIs |
| Tool calling | Model decides tools freely | LangGraph provides tools at each step |
| Reliability | Can loop forever / hallucinate tools | Bounded loops, guaranteed termination |
| Cost | $3-30 per query (API) | $0 (Ollama self-hosted) or low-cost API |
| Debuggability | Black box agent loop | Each phase logged + SSE streamed to UI |

## Prompt Engineering

All prompts use **Chain-of-Thought (CoT)** reasoning with mandatory multi-step analysis:

### 1. INVESTIGATION_PLANNER_PROMPT (CoT: 5-step)
- Step 1: Decompose symptom (what is broken, where might it be)
- Step 2: Layer analysis (component/service/controller/repository/config)
- Step 3: Entity extraction with naming variants (e.g., UserService -> UserServiceImpl, UamUserService)
- Step 4: Flow hypothesis (user action -> frontend -> API -> backend -> DB)
- Step 5: Investigation priority ordering

### 2. HIERARCHICAL_LOCALIZER_PROMPT
- Ranks candidate locations from graph queries
- Output: `{ranked_locations: [{file, class, method, confidence, reason}]}`

### 3. ROOT_CAUSE_ANALYZER_PROMPT (CoT: 5-step trace + Rubric)
- Step 1: Identify entry point
- Step 2: Forward trace through code
- Step 3: Pinpoint the bug
- Step 4: Cross-file impact analysis
- Step 5: Evidence quality check
- **Rubric-based confidence**: 5 yes/no questions computed by Python (not LLM):
  - `exact_line_found`, `code_quoted`, `all_flow_files_found`, `explains_all_symptoms`, `fix_is_clear`
  - Score map: {5: 95%, 4: 88%, 3: 78%, 2: 65%, 1: 50%, 0: 30%}

### 4. FIX_GENERATOR_PROMPT (CoT: 4-step THINK)
- THINK Step 1: Locate EXACT code from evidence (no placeholders)
- THINK Step 2: Design minimal fix
- THINK Step 3: Check all affected files
- THINK Step 4: Adjust confidence from rubric input

### 5. FIX_VERIFIER_PROMPT (Adversarial Skeptic)
- 6 checks: root cause match, code reality, CURRENT_CODE accuracy, execution flow, new bugs, confidence calibration
- Output: `{verdict, issues[], placeholder_code[], missing_files[], suggested_confidence, hint}`

## Rubric-Based Confidence Scoring

Eliminates LLM anchoring bias (all bugs returning 85%) by computing confidence deterministically:

```python
rubric_score = sum([
    eq.get("exact_line_found", False),      # Did LLM find the exact buggy line?
    eq.get("code_quoted", False),            # Did it quote actual code?
    eq.get("all_flow_files_found", False),   # Did it trace the full flow?
    eq.get("explains_all_symptoms", False),  # Does RCA explain all symptoms?
    eq.get("fix_is_clear", False),           # Is the fix actionable?
])
confidence = {5: 95, 4: 88, 3: 78, 2: 65, 1: 50, 0: 30}[rubric_score]
```

## Conditional Verification Skip

When rubric score >= 3/5 (confidence >= 78%), Phase 6 (Fix Verifier) is skipped to save ~12-15s per query. The verifier only runs on low-confidence fixes where adversarial review adds value.

## SSE Streaming (Real-Time Progress)

The `/query/stream` endpoint uses **Server-Sent Events** via `graph.stream(state, stream_mode="updates")`:

```
Frontend (React)                    Backend (FastAPI)
     |                                    |
     |--- POST /query/stream ------------>|
     |                                    |-- graph.stream() starts
     |<-- data: {type: "start"}  ---------|
     |<-- data: {type: "phase",           |-- Phase 1 completes
     |          node: "investigation_...", |
     |          step: 0, logs: [...]} ----|
     |<-- data: {type: "phase",           |-- Phase 2 completes
     |          step: 1, ...} ------------|
     |    ... (each phase streamed) ...   |
     |<-- data: {type: "complete",        |-- Pipeline done (interrupt at HITL)
     |          answer: "...",            |
     |          status: "needs_review"} --|
     |                                    |
     |--- POST /resume {human:"approved"}->|-- Resumes from interrupt
     |<-- {answer, status: "completed"} --|-- finalize -> save to memory
```

This replaces the old blocking `graph.invoke()` call. The UI progress bar animates step-by-step instead of jumping from start to end.

## Agent Memory (pgvector)

2-table split for performance:
- **agent_memory**: Lean vector table (id, user_id, query, embedding, expires_at) with HNSW halfvec index
- **agent_memory_responses**: Heavy text table (memory_id, full response)

Key behaviors:
- **Write**: Only stores approved responses. Deduplication: if similarity > 0.95 to existing entry, UPDATE instead of INSERT
- **Read**: Global search across all users. Embedding uses query-only text (`"Query: {query}"`) for consistent write/read matching
- **TTL**: Configurable expiry (default 1095 days), with admin cleanup endpoint
- **Cache hit flow**: `memory_check -> cache_hit -> finalize -> END` (skips entire pipeline)

## Agent Tools

The agent doesn't call tools freely. Instead, **each LangGraph node** uses specific tools programmatically:

### Graph Tools (Neo4j)
| Tool | Used By | Purpose |
|------|---------|---------|
| `search_classes(names)` | Localizer | Find classes matching investigation plan |
| `search_methods(names)` | Localizer | Find methods matching plan |
| `get_call_chain(class, method)` | Evidence Collector | Trace execution path |
| `get_class_context(name)` | Evidence Collector | Full class with imports, methods, callers |
| `get_feature_tree(name)` | Localizer | Browse microservice structure |
| `get_directory_contents(path)` | Localizer | List files in a directory |
| `search_by_layer(feature, layer)` | Localizer | Find classes by architecture layer |
| `find_api_endpoints(pattern)` | Localizer | Match REST endpoints |
| `get_all_features()` | Localizer | List all microservices/modules |

### Vector Tools (pgvector)
| Tool | Used By | Purpose |
|------|---------|---------|
| `search(query, k)` | Evidence Collector | Semantic similarity search |
| `search_by_paths(query, paths, k)` | Evidence Collector | Search within specific files |
| `grep_code(pattern, k)` | Evidence Collector | Text search in code chunks |
| `get_file_chunks(path)` | Evidence Collector | Get all code from a file |

## State Design

```python
class AgentState(TypedDict):
    # Query
    original_query: str
    question: str
    user_id: str

    # Phase 1: Investigation Plan
    investigation_plan: Optional[dict]

    # Phase 2: Localization
    candidate_locations: list

    # Phase 3: Evidence
    investigation_round: int          # Current round (max 3)
    code_evidence: str                # Accumulated code from investigation
    call_chain_evidence: str          # Call chain context

    # Phase 4: Root Cause
    root_cause: Optional[dict]        # Includes evidence_quality rubric

    # Phase 5: Fix
    generation: str
    generation_attempts: int

    # HITL
    human: Optional[str]
    feedback: Optional[str]
    feedback_count: int
    feedback_history: list

    # Memory
    memory_hit: bool
    cached_response: Optional[str]

    # Existing fields
    documents: list
    graph_context: str
    guided_file_paths: list
    final_report: Optional[str]
    query_transform_count: int
```

## Stack

- **LLM**: Multi-provider -- Ollama (devstral:24b), OpenAI (gpt-4o/gpt-4o-mini), Anthropic (claude-sonnet/opus), Groq, DeepSeek, Google Gemini
- **Embeddings**: Ollama (qwen3-embedding:8b) -- always local
- **Query Refiner**: Ollama (llama3.1:8b) -- always local, fast model for JIRA query cleanup
- **Orchestrator**: LangGraph -- structured pipeline with state management + SQLite checkpointing
- **Knowledge Graph**: Neo4j Community Edition -- code relationships (5,999 classes, 28,120 methods, 275 API endpoints)
- **Vector Store**: pgvector -- code chunk embeddings (32,023 docs, 4,640 unique files)
- **Agent Memory**: pgvector -- approved response cache with HNSW halfvec index
- **Cache**: Redis -- session persistence
- **Parsing**: tree-sitter -- AST-based code chunking
- **Backend**: FastAPI with 7 routers (query, admin, auth, config, index, sync, pipeline_logs)
- **Frontend**: React + TypeScript + shadcn/ui + Tailwind + ReactMarkdown

## Backend API Structure

```
app.py (FastAPI main)
  +-- API/query_api.py      -> /query, /query/stream (SSE), /resume, /state, /refine-query
  +-- API/index_api.py       -> /index, /clear, /classes
  +-- API/admin_api.py       -> /admin/graph-stats, /admin/memory-stats, ...
  +-- API/config_api.py      -> /config/llm, /config/gitlab
  +-- API/auth_api.py        -> /auth/login, /auth/me
  +-- API/sync_api.py        -> /sync/gitlab
  +-- API/pipeline_logs_api.py -> /pipeline-logs
  +-- API/jira_proxy_api.py  -> /jira-proxy
  +-- API/dependencies.py    -> Shared state: graph, memory, sessions, Redis
  +-- API/models.py          -> Pydantic request/response models
```

## File Structure

### Core Pipeline
- `Graph/state.py` -- AgentState TypedDict
- `Graph/agent_nodes.py` -- 10 LangGraph nodes (memory_check, investigation_planner, hierarchical_localizer, evidence_collector, root_cause_analyzer, fix_generator, fix_verifier, human_review, finalize, end_not_relevant)
- `Graph/agent_routing.py` -- 7 routing functions (after_memory_check, after_root_cause_analysis, after_human_review, after_localization, after_fix_generation, after_fix_verification, should_skip_verification)
- `Graph/agent_workflow.py` -- LangGraph StateGraph with conditional edges
- `Graph/agent_tools.py` -- AgentToolkit wrapping graph + vector queries

### Prompts
- `Prompt_lib/prompts.py` -- 6 prompts (RAG_PROMPT, INVESTIGATION_PLANNER, HIERARCHICAL_LOCALIZER, ROOT_CAUSE_ANALYZER, FIX_GENERATOR, FIX_VERIFIER)
- `Prompt_lib/query_refiner.py` -- QUERY_REFINER_PROMPT, ERROR_EXTRACTOR_PROMPT

### Infrastructure
- `Memory/agent_memory.py` -- AgentMemory class (pgvector, 2-table, dedup, HNSW)
- `Utils/model_loader.py` -- Multi-provider LLM factory (create_llm, get_llm, get_embed_model)
- `Config/settings.py` -- Central configuration with DB persistence
- `Knowledge_Graph/graph_store.py` -- Neo4j query methods
- `Vector_Store/store.py` -- pgvector search methods

### Frontend
- `RAG_UI/src/pages/BugFixer.tsx` -- Main bug fixing page with SSE streaming progress
- `RAG_UI/src/pages/FeatureGenerator.tsx` -- Feature suggestion page
- `RAG_UI/src/services/ragApi.ts` -- API client with queryCodeStream() for SSE
- `RAG_UI/src/components/pipeline/PipelineProgress.tsx` -- 7-step progress indicator

## How It Differs from Current System

| Current GraphRAG | Agentic Code-Aware GraphRAG |
|-----------------|----------------------------|
| Query -> extract entities -> graph lookup -> vector search -> generate | Query -> PLAN -> LOCATE -> COLLECT EVIDENCE -> ANALYZE ROOT CAUSE -> GENERATE FIX -> VERIFY |
| One-shot: single LLM call | Multi-step: 5-6 LLM calls with CoT reasoning |
| Finds similar code | Finds the actual bug |
| No call chain tracing | Traces full execution path |
| No architectural reasoning | Understands controller -> service -> repository |
| No investigation loop | Can loop 3 times to gather more evidence |
| No root cause analysis | Explicit root cause identification with rubric scoring |
| LLM picks confidence (anchoring bias) | Rubric-based confidence (5 yes/no questions, Python computes) |
| No fix verification | Adversarial skeptic verifier catches hallucinations |
| Blocking request (no progress) | SSE streaming with real-time step-by-step progress |
| Single provider (Ollama) | Multi-provider: Ollama, OpenAI, Anthropic, Groq, DeepSeek, Google |
| No memory | Agent memory with pgvector (cache approved responses) |

## Example: How It Handles "Submit Button Gives Error"

### Phase 1: Investigation Planner
```json
{
  "symptom": "Submit button produces an error",
  "symptom_type": "ui_issue",
  "likely_layers": ["component", "service", "controller"],
  "search_entities": {
    "class_names": ["SubmitComponent", "FormComponent"],
    "method_names": ["onSubmit", "submit", "handleSubmit", "save"],
    "api_paths": ["/api/submit", "/api/save"],
    "keywords": ["submit", "form", "save", "post"]
  },
  "likely_flow": "User clicks submit -> Angular component.onSubmit() -> Angular service.save() -> HTTP POST -> Java Controller -> Service -> Repository",
  "investigation_priority": ["Find Angular components with submit handlers", "Find API controllers handling form submission"]
}
```

### Phase 2: Hierarchical Localizer
Graph query finds:
- Feature "pages" -> component layer -> `SubmitFormComponent` (confidence: 0.85)
- Feature "api-gateway" -> controller layer -> `FormController` (confidence: 0.70)
- Feature "form-service" -> service layer -> `FormService` (confidence: 0.65)

### Phase 3: Evidence Collector
For top 3 candidates, collects:
- Full code of `SubmitFormComponent.onSubmit()`
- Call chain: `onSubmit() -> formService.save() -> HTTP POST /api/forms -> FormController.create() -> FormService.save() -> FormRepository.save()`
- Code of `FormService.save()` method

### Phase 4: Root Cause Analyzer
"The `onSubmit()` method calls `formService.save()` but doesn't handle the Observable error callback. When the backend returns a 400 validation error, the error propagates unhandled."

Rubric: exact_line_found=true, code_quoted=true, all_flow_files_found=true, explains_all_symptoms=true, fix_is_clear=true -> Score 5/5 -> Confidence 95%

### Phase 5: Fix Generator
Full fix with corrected code for both Angular component (error handler) and Java controller (validation response).

### Phase 6: Fix Verifier (skipped -- rubric 5/5 >= 3)
High confidence -> skip directly to Developer Review, saving ~12-15s.

### Developer Review
Developer approves -> saved to agent memory -> next time same query returns instantly from cache.
