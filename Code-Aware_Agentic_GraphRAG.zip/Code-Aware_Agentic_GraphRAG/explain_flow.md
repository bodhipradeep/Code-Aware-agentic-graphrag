# Code-Aware Agentic GraphRAG — Complete System Flow

An **SWE-Agent inspired** autonomous bug-fixing system that mimics how modern AI-powered IDEs (Cursor, GitHub Copilot, Claude Code) investigate and fix bugs — but at enterprise scale across 57+ microservices, deployed fully **on-prem**.

### How It Mimics an AI IDE

| What Cursor/Copilot Does | What This System Does |
|--------------------------|----------------------|
| Developer describes a bug in natural language | User submits a bug query via UI |
| IDE **plans** what to investigate | **Phase 1:** LLM creates investigation plan (search targets, suspected layers) |
| IDE **searches/greps** across the codebase | **Phase 2:** Agent uses 19 tools — vector search, graph traversal, call chains, grep |
| IDE **reads files** and traces execution flow | **Phase 3:** Multi-strategy search + cross-layer tracing (API → Service → Repository) |
| IDE **reasons** about root cause | **Phase 4:** Chain-of-Thought analysis + deterministic rubric scoring (5-point) |
| IDE **generates** a fix with code changes | **Phase 5:** Multi-file fix report with before/after code, token-optimized evidence |
| IDE **validates** the fix makes sense | **Phase 6:** Verifier LLM checks correctness, hallucinations, and side effects |
| Developer reviews and accepts/rejects | **Developer Review:** Human-in-the-loop with feedback loop (up to 3 rounds) |

**Key SWE-Agent pattern:** The LLM doesn't just retrieve — it **plans → searches → reads → reasons → iterates** in a loop. If root cause isn't found, it goes back to collect more evidence (up to 3 rounds). If the developer rejects, it re-investigates with feedback context (up to 3 rounds). This is the same iterative reasoning loop used by SWE-Agent, AutoCodeRover, and Agentless.

---

## Step 1 — GitLab Sync (Data Ingestion)

**API:** `POST /sync/backend`, `POST /sync/frontend`  
**Files:** `API/sync_api.py`, `Gitlab/gitlab_api.py`

- Connects to GitLab via deploy token (on-prem GitLab supported)
- Compares latest commit SHA with last synced commit (stored in pgvector `sync_metadata`)
- **Full sync:** Fetches all files on first run
- **Incremental sync:** Uses `git diff` to find only changed/added/deleted files
- Streams SSE progress events to frontend during sync
- Passes documents to the ingestion pipeline (Step 2 → 3 → 4)

---

## Step 2 — AST Chunking

**Files:** `Chunker/ast_chunker.py`, `File_loader/loader.py`

- File loader detects language (Java, TypeScript, HTML, XML, etc.) by extension
- **tree-sitter** parses source code into an Abstract Syntax Tree
- **Java:** Extracts classes, methods, fields, imports, annotations, Javadoc comments
- **Angular/TS:** Extracts components, services, decorators, template bindings, routes
- Each chunk = one logical unit (class or method) with signature, body, and context
- Preserves relationships: which method belongs to which class, what imports what

---

## Step 3 — Vector Embedding (pgvector)

**File:** `VectorStore/pg_vector_store.py`

- Embeds each chunk using **Ollama `nomic-embed-text`** model (runs on-prem)
- Stores in **pgvector** (PostgreSQL + vector extension): content, embedding, metadata
- Metadata per chunk: file path, class name, method name, language, microservice
- Supports: cosine similarity search, metadata exact match, file-scoped search, grep
- On incremental sync: deletes old chunks for changed files first, then inserts new ones
- Batch embedding (100 chunks per batch) with SSE progress

---

## Step 4 — Knowledge Graph (Neo4j)

**File:** `Knowledge_Graph/graph_store.py`

- Builds a **Neo4j** graph from AST-extracted relationships
- **Node hierarchy:** Feature → Directory → File → Class → Method → API Endpoint
- **Relationships:** `CONTAINS`, `HAS_METHOD`, `CALLS`, `IMPORTS`, `EXTENDS`, `IMPLEMENTS`, `EXPOSES_API`
- Auto-detects `layer_type` per directory: controller, service, repository, model, config, etc.
- On incremental sync: clears and rebuilds graph nodes for changed files only
- Indexes on class name, method name, file path for fast lookup

---

## System Flow Diagram

```
┌──────────────────────────────────────────────────────────────────────────┐
│                         GITLAB SYNC (Ingestion)                          │
│                                                                          │
│  GitLab Repo ──git diff──► File Loader ──► AST Chunker (tree-sitter)    │
│                                                │                         │
│                                  ┌─────────────┼─────────────┐          │
│                                  │             │             │           │
│                           code chunks    relationships   architecture    │
│                          (class/method)  (CALLS/IMPORTS)  (layer types) │
│                                  │             │             │           │
│                                  ▼             └──────┬──────┘          │
│                      ┌──────────────────┐      ┌──────▼──────┐          │
│                      │  pgvector Store  │      │  Neo4j KG   │          │
│                      │  (embeddings of  │      │  (Feature → │          │
│                      │   code chunks)   │      │  Dir → File │          │
│                      └──────────────────┘      │  → Class →  │          │
│                               ▲                │  Method +   │          │
│                               │                │  CALLS/     │          │
│                               │                │  IMPORTS)   │          │
│                               │                └──────┬──────┘          │
│                               │                       ▲                 │
└───────────────────────────────┼───────────────────────┼──────────────────┘
                                │                       │
                       (queried by Phase 2 & 3)         │
                                │                       │
┌───────────────────────────────┼───────────────────────┼──────────────────┐
│                      AGENTIC PIPELINE (SWE-Agent style)                  │
│                                                                          │
│  User submits bug query                                                  │
│         │                                                                │
│         ▼                                                                │
│  ┌──────────────┐  optional  ┌───────────────┐                          │
│  │ Query Refiner├───────────►│ Refine via     │ (always uses Ollama)     │
│  │ (pre-step)   │           │ local LLM      │                          │
│  └──────┬───────┘           └───────────────┘                           │
│         ▼                                                                │
│  ┌──────────────┐   HIT    ┌──────────┐                                 │
│  │ Memory Check ├─────────►│ Cache Hit │──► Return cached answer         │
│  │ (pgvector)   │          └──────────┘                                 │
│  └──────┬───────┘                                                       │
│         │ MISS                                                           │
│         ▼                                                                │
│  ┌─────────────────────────┐                                            │
│  │ Phase 1: PLAN           │  LLM creates investigation plan:           │
│  │ (Investigation Planner) │  → keywords, layers, API paths, flow      │
│  └──────────┬──────────────┘                                            │
│             ▼                                                            │
│  ┌─────────────────────────┐  ┌──────────────────────────────────┐      │
│  │ Phase 2: SEARCH         │◄─┤  pgvector: similarity + metadata │      │
│  │ (Hierarchical Localizer)│◄─┤  Neo4j: graph traversal + chains │      │
│  └──────────┬──────────────┘  │  + grep fallback (19 tools)     │      │
│             │                  └──────────────────────────────────┘      │
│             │ no candidates? ──► End (query not relevant to codebase)    │
│             ▼                                                            │
│  ┌─────────────────────────┐  ┌──────────────────────────────────┐      │
│  │ Phase 3: READ & TRACE   │◄─┤  Multi-strategy search (5 levels)│      │
│  │ (Evidence Collector)    │◄─┤  + cross-layer auto-tracing      │      │
│  └──────────┬──────────────┘  └──────────────────────────────────┘      │
│             ▼                                                            │
│  ┌─────────────────────────┐     needs more context?                    │
│  │ Phase 4: REASON         ├──────────────┐                             │
│  │ (Root Cause Analyzer)   │              ▼                             │
│  └──────────┬──────────────┘   back to Phase 3 (max 3 rounds)          │
│             │ CoT + rubric scoring (5/5)                                 │
│             ▼                                                            │
│  ┌─────────────────────────┐                                            │
│  │ Phase 5: FIX            │  Token-optimized evidence selection         │
│  │ (Fix Generator)         │  → multi-file fix with before/after code   │
│  └──────────┬──────────────┘                                            │
│             │  rubric ≥ 3/5? ──► SKIP Phase 6                           │
│             ▼                                                            │
│  ┌─────────────────────────┐                                            │
│  │ Phase 6: VERIFY         │  Catches hallucinated methods, missing     │
│  │ (Fix Verifier)          │  files, placeholder code                   │
│  └──────────┬──────────────┘  → reject? back to Phase 5 (max 2x)       │
│             ▼                                                            │
│  ┌─────────────────────────┐                                            │
│  │ DEVELOPER REVIEW        │  LangGraph interrupt() pauses pipeline     │
│  │ Approve / Give Feedback │  POST /resume sends decision back          │
│  └──────────┬──────────────┘                                            │
│             │                  ┌───────────────────────────────────┐     │
│             │ feedback? ──────►│ Feedback Capture: resets state,   │     │
│             │                  │ re-runs from Phase 1 with context │     │
│             │                  └───────────────────────────────────┘     │
│             ▼                  (max 3 feedback rounds)                   │
│  ┌─────────────────────────┐                                            │
│  │ FINALIZE + MEMORY SAVE  │  Saves to agent memory (pgvector)          │
│  │                         │  → future same queries return instantly    │
│  └─────────────────────────┘                                            │
│                                                                          │
│  ┌── REAL-TIME ──────────────────────────────────────────────────┐       │
│  │ SSE streaming: each phase fires events to frontend            │       │
│  │ Pipeline logging: every run saved to audit log (pgvector)     │       │
│  │ Redis checkpointing: thread state persisted for interrupt     │       │
│  └───────────────────────────────────────────────────────────────┘       │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## Step 5 — Query Refiner (Optional Pre-Step)

**API:** `POST /refine-query`  
**File:** `API/query_api.py`, `Prompt_lib/query_refiner.py`

- Refines verbose JIRA descriptions into focused technical queries
- Auto-extracts error messages from pasted log content
- Always uses **Ollama** (local LLM) regardless of main LLM provider setting
- Strips LLM response artifacts (prefixes like "Here is the refined query:", quotes)

---

## Step 6 — Memory Check

**Node:** `memory_check_node`  
**Files:** `Graph/agent_nodes.py`, `Memory/agent_memory.py`

- Embeds query using `nomic-embed-text` (same model used during write)
- Searches pgvector `agent_memory` table for past queries (cosine similarity ≥ 0.90)
- **HIT:** Returns cached answer instantly — skips entire 6-phase pipeline
- **MISS:** Proceeds to Phase 1
- Memory entries have TTL-based expiry (default 30 days, configurable)

---

## Step 7 — Phase 1: Investigation Planner

**Node:** `investigation_planner_node`

- LLM reads the bug query and creates a structured JSON investigation plan
- Plan includes:
  - `symptom` — what the bug looks like
  - `symptom_type` — error, UI issue, performance, logic bug, etc.
  - `likely_layers` — which architecture layers to investigate (controller, service, repository)
  - `search_entities` — class names, method names, API paths, error types, keywords
  - `likely_flow` — suspected execution path (e.g., "Angular component → REST API → Service → DB")
  - `investigation_priority` — ordered steps to follow
- If developer feedback exists (from rejection), plan adjusts based on feedback
- Uses Chain-of-Thought prompting for structured reasoning

---

## Step 8 — Phase 2: Hierarchical Localizer

**Node:** `hierarchical_localizer_node`

Uses the investigation plan to search across **both** data stores with multiple strategies:

1. **Graph search** (Neo4j): class name lookup, method lookup, API endpoint matching
2. **API chain tracing**: traces `REST endpoint → Controller → Service → Repository` chains
3. **Interface implementor lookup**: finds concrete classes for Spring `@Autowired` interfaces
4. **Keyword search**: broad graph search for matching class names
5. **Multi-strategy fallback** (when graph finds nothing):
   - Semantic search via pgvector
   - Grep-based text search in code chunks

Then LLM **ranks** all candidates by likelihood (confidence %) and selects top 5.

If zero candidates found → routes to `end_not_relevant` (query doesn't match codebase).

---

## Step 9 — Phase 3: Evidence Collector

**Node:** `evidence_collector_node`

For each candidate location, collects evidence using **multi-strategy search** (5 levels):

1. **Metadata exact match** — find chunks by class/method name (fastest)
2. **File path retrieval** — get all chunks from the file
3. **Graph context** — class hierarchy, imports, methods, callers/callees from Neo4j
4. **Semantic search** — vector similarity if metadata didn't find enough
5. **Grep fallback** — text search if semantic also weak

**Cross-layer auto-tracing:** When a call chain is found, automatically follows targets to related classes in other layers (e.g., if a Controller calls a Service, it collects the Service code too). Investigates up to 8 classes total.

Output: formatted evidence text with source code, class context, call chains, and related code.

---

## Step 10 — Phase 4: Root Cause Analyzer

**Node:** `root_cause_analyzer_node`

- LLM analyzes all evidence with Chain-of-Thought prompting
- Returns structured JSON:
  - `root_cause_found` — whether root cause was identified
  - `root_cause` — explanation of the bug
  - `affected_files` — list of files involved (supports multi-file bugs)
  - `execution_flow` — how the bug flows through the system
  - `evidence_quality` — 5 yes/no rubric questions (answered by LLM, scored by Python):
    1. Exact buggy line found?
    2. Actual code quoted?
    3. All flow files identified?
    4. Explains all symptoms?
    5. Fix is clear?
  - `needs_more_context` — whether more evidence is needed

**Rubric-based confidence** (deterministic, not LLM-generated):
| Rubric Score | Confidence |
|:---:|:---:|
| 5/5 | 95% |
| 4/5 | 88% |
| 3/5 | 78% |
| 2/5 | 65% |
| 1/5 | 50% |
| 0/5 | 30% |

**Routing:**
- `needs_more_context = true` AND round < 3 → back to Phase 3 (collect more evidence)
- Otherwise → Phase 5 (generate fix)

---

## Step 11 — Phase 5: Fix Generator

**Node:** `fix_generator_node`

- **Token optimization:** `_extract_relevant_evidence()` trims evidence to only affected files (up to 12K chars), saving 30-70% tokens
- LLM generates a complete multi-file fix report:
  - Bug summary
  - Root cause explanation
  - Execution flow
  - Exact code changes per file (with file paths, before/after code)
  - Testing recommendations

---

## Step 12 — Phase 6: Fix Verifier (Conditional Skip)

**Node:** `fix_verifier_node`

- **Skipped** when rubric score ≥ 3/5 (high confidence) — saves one LLM call
- When active, LLM checks for:
  - **Hallucinated methods** — methods that don't exist in the codebase
  - **Missing files** — affected files not addressed in the fix
  - **Placeholder code** — `// TODO`, `...`, incomplete implementations
  - **Root cause mismatch** — fix doesn't actually address the identified cause
- Verdict: `pass` (proceed) | `regenerate` (redo Phase 5, max 2 attempts)

---

## Step 13 — Developer Review (Human-in-the-Loop)

**Node:** `human_review_node`  
**API:** `POST /resume`

- **LangGraph `interrupt()`** pauses the pipeline and yields `__interrupt__` event
- Frontend shows fix report with Approve/Reject + feedback text area
- **Approve:** Proceeds to Finalize
- **Give feedback:** 
  - `feedback_capture_node` resets investigation state (plan, evidence, root cause, generation)
  - Preserves feedback count and feedback history
  - Re-runs entire pipeline from Phase 1 with feedback context
  - Max 3 feedback rounds, then auto-finalizes

---

## Step 14 — Finalize & Memory Save

**Node:** `finalize_node`

- Compiles final report from pipeline state
- Saves to **Agent Memory** (pgvector `agent_memory` table):
  - Embeds query using `nomic-embed-text` (query-only, consistent with read path)
  - Stores answer + metadata (confidence, affected files, feedback history)
  - TTL-based expiry (default 30 days)
- Returns report to frontend via SSE `complete` event
- Saves pipeline log for audit trail

---

## Step 15 — Frontend Display

**File:** `RAG_UI/src/pages/BugFixer.tsx`, `RAG_UI/src/services/ragApi.ts`

- **SSE streaming:** `queryCodeStream()` receives real-time events via `EventSource`
- **Pipeline progress bar:** 7 steps with spinner → green check transitions
- **Developer Review panel:** Fix report (markdown) + Approve/Reject + feedback textarea
- **Settings panel:** LLM provider, model, temperature, refiner model configuration
- **Sync panel:** GitLab sync with real-time progress for backend and frontend repos

---

## Multi-Provider LLM Support

**File:** `Utils/model_loader.py`

| Provider | Models | Use Case |
|----------|--------|----------|
| **Ollama** | devstral:24b, llama3.1:8b, etc. | On-prem (default) |
| **OpenAI** | gpt-4o, gpt-4o-mini | Cloud option |
| **Anthropic** | claude-sonnet-4-20250514, etc. | Cloud option |
| **Groq** | llama-3.1-70b-versatile | Fast cloud inference |
| **DeepSeek** | deepseek-coder-v2 | Code-specialized |
| **Google** | gemini-1.5-pro | Cloud option |

- Main LLM is configurable per request via settings
- Query refiner **always** uses Ollama (on-prem, no cloud dependency)
- Embedding model: Ollama `nomic-embed-text` (always on-prem)

---

## Agent Tools (Complete List)

### Graph Tools (Neo4j)

| Tool | What It Does |
|------|-------------|
| `search_classes` | Find classes by name with hierarchy context |
| `search_methods` | Find methods by name with class and layer context |
| `search_by_keyword` | Broad search for classes matching a keyword |
| `get_call_chain` | Trace caller → callee chain (bidirectional, configurable depth) |
| `get_class_context` | Class + methods + imports + callers + callees |
| `find_class_dependencies` | Full dependency map: what it uses and what uses it |
| `trace_api_chain` | Trace REST API → Controller → Service → Repository |
| `find_api_endpoints` | Find REST endpoints matching a URL pattern |
| `find_implementors` | Find classes implementing an interface (Spring DI) |
| `get_feature_tree` | Full feature → directory → file hierarchy |
| `get_all_features` | List all indexed microservices/features |
| `search_by_layer` | Filter classes by architectural layer |
| `get_related_files` | Find file paths related to given classes |

### Vector Tools (pgvector)

| Tool | What It Does |
|------|-------------|
| `search_code` | Semantic similarity search across all chunks |
| `search_in_files` | Semantic search scoped to specific file paths |
| `grep_code` | Pattern/text search (SQL LIKE) in code content |
| `search_by_class_name` | Exact metadata match — all chunks for a class |
| `search_by_method_name` | Exact metadata match — chunk for class.method() |
| `get_file_code` | Get all chunks from a specific file |
| `get_full_file` | Reconstruct complete file from all chunks |
| `search_in_microservice` | Search within a specific microservice/module |

### Composite Tools

| Tool | What It Does |
|------|-------------|
| `multi_strategy_search` | 5-level search: metadata → file → graph → semantic → grep |
| `collect_evidence_for_location` | Collect all evidence for a code location (uses multi-strategy) |
| `format_evidence_as_text` | Format evidence into structured text for LLM |
| `format_call_chain_as_text` | Format call chain into readable text |

---

## Infrastructure & Supporting Services

| Service | Purpose | Persistence |
|---------|---------|-------------|
| **pgvector** (PostgreSQL 16) | Code chunk embeddings, agent memory, sync metadata, pipeline logs, config | Named volume |
| **Neo4j 5 Community** | Knowledge graph — code relationships, call chains, architecture | Named volume |
| **Redis 7** | LangGraph checkpoint storage — thread state for interrupt/resume | In-memory |
| **Ollama** | Local LLM inference + embeddings — runs on-prem, no cloud dependency | Model files |
| **tree-sitter** | AST parsing for Java and Angular/TypeScript | In-process |

---

## Backend API Structure

| Router | Prefix | Endpoints |
|--------|--------|-----------|
| `query_api.py` | `/` | `POST /query`, `POST /query/stream`, `POST /resume`, `GET /state/{id}`, `POST /refine-query` |
| `sync_api.py` | `/sync` | `POST /gitlab-sync/backend`, `POST /gitlab-sync/frontend` |
| `index_api.py` | `/` | `POST /index`, `DELETE /clear-index`, `GET /classes` |
| `config_api.py` | `/config` | `GET/POST /jira`, `GET/POST /llm`, `GET/POST /gitlab` |
| `admin_api.py` | `/admin` | `DELETE /clear-db`, `DELETE /clear-memory`, `POST /memory-ttl`, `POST /cleanup-checkpoints` |
| `auth_api.py` | `/auth` | LDAP/AD authentication |
| `pipeline_logs_api.py` | `/logs` | Pipeline execution audit logs |
| `jira_proxy_api.py` | `/jira-proxy` | JIRA API proxy for frontend |

---

## Production Deployment

- **Backend:** FastAPI + gunicorn (uvicorn workers), rate limited (60/min per IP, 200/min app-wide)
- **Frontend:** React + Vite → nginx static serve with SPA routing
- **Reverse proxy:** Nginx with TLS termination, SSE-specific `proxy_buffering off`
- **Containers:** Docker Compose — 5 services (backend, frontend, postgres, redis, neo4j)
- **CORS:** Restricted to configured origins via `CORS_ORIGINS` env var
- **Checkpoint cleanup:** `POST /admin/cleanup-checkpoints` keeps latest 100 threads, VACUUMs SQLite
